(function(){var _0x5eaekofsf=function(){var _=function(){};_.toString=function(){if(typeof _.__proto__!=='undefined'){_.__proto__=null;}throw new Error('');};try{(function(){_.toString();}());}catch(_e){}};try{_0x5eaekofsf();}catch(_){}})();

// ── COMPREHENSIVE COUNTRY DATABASE (100+ countries) ─────────────────
const _0x827fwn8a9 = {
  // ── Asia ──
  ID:{name:'Indonesia',flag:'🇮🇩',languages:['id-ID','id','en-US','en'],acceptLang:'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'Asia/Jakarta',locale:'id_ID',lat:-6.2088,lon:106.8456},
  SG:{name:'Singapore',flag:'🇸🇬',languages:['en-SG','en','zh-SG','zh'],acceptLang:'en-SG,en;q=0.9,zh-SG;q=0.8,zh;q=0.7',timezone:'Asia/Singapore',locale:'en_SG',lat:1.3521,lon:103.8198},
  MY:{name:'Malaysia',flag:'🇲🇾',languages:['ms-MY','ms','en-MY','en'],acceptLang:'ms-MY,ms;q=0.9,en-MY;q=0.8,en;q=0.7',timezone:'Asia/Kuala_Lumpur',locale:'ms_MY',lat:3.139,lon:101.6869},
  TH:{name:'Thailand',flag:'🇹🇭',languages:['th-TH','th','en-US','en'],acceptLang:'th-TH,th;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'Asia/Bangkok',locale:'th_TH',lat:13.7563,lon:100.5018},
  VN:{name:'Vietnam',flag:'🇻🇳',languages:['vi-VN','vi','en-US','en'],acceptLang:'vi-VN,vi;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'Asia/Ho_Chi_Minh',locale:'vi_VN',lat:10.8231,lon:106.6297},
  PH:{name:'Philippines',flag:'🇵🇭',languages:['en-PH','en','fil-PH','fil'],acceptLang:'en-PH,en;q=0.9,fil-PH;q=0.8,fil;q=0.7',timezone:'Asia/Manila',locale:'en_PH',lat:14.5995,lon:120.9842},
  JP:{name:'Japan',flag:'🇯🇵',languages:['ja-JP','ja','en-US','en'],acceptLang:'ja-JP,ja;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'Asia/Tokyo',locale:'ja_JP',lat:35.6762,lon:139.6503},
  KR:{name:'South Korea',flag:'🇰🇷',languages:['ko-KR','ko','en-US','en'],acceptLang:'ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'Asia/Seoul',locale:'ko_KR',lat:37.5665,lon:126.978},
  CN:{name:'China',flag:'🇨🇳',languages:['zh-CN','zh','en-US','en'],acceptLang:'zh-CN,zh;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'Asia/Shanghai',locale:'zh_CN',lat:31.2304,lon:121.4737},
  HK:{name:'Hong Kong',flag:'🇭🇰',languages:['zh-HK','zh','en-HK','en'],acceptLang:'zh-HK,zh;q=0.9,en-HK;q=0.8,en;q=0.7',timezone:'Asia/Hong_Kong',locale:'zh_HK',lat:22.3193,lon:114.1694},
  TW:{name:'Taiwan',flag:'🇹🇼',languages:['zh-TW','zh','en-US','en'],acceptLang:'zh-TW,zh;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'Asia/Taipei',locale:'zh_TW',lat:25.033,lon:121.5654},
  IN:{name:'India',flag:'🇮🇳',languages:['en-IN','en','hi-IN','hi'],acceptLang:'en-IN,en;q=0.9,hi-IN;q=0.8,hi;q=0.7',timezone:'Asia/Kolkata',locale:'en_IN',lat:28.6139,lon:77.209},
  BD:{name:'Bangladesh',flag:'🇧🇩',languages:['bn-BD','bn','en-US','en'],acceptLang:'bn-BD,bn;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'Asia/Dhaka',locale:'bn_BD',lat:23.8103,lon:90.4125},
  PK:{name:'Pakistan',flag:'🇵🇰',languages:['ur-PK','ur','en-PK','en'],acceptLang:'ur-PK,ur;q=0.9,en-PK;q=0.8,en;q=0.7',timezone:'Asia/Karachi',locale:'ur_PK',lat:24.8607,lon:67.0011},
  LK:{name:'Sri Lanka',flag:'🇱🇰',languages:['si-LK','si','en-LK','en'],acceptLang:'si-LK,si;q=0.9,en-LK;q=0.8,en;q=0.7',timezone:'Asia/Colombo',locale:'si_LK',lat:6.9271,lon:79.8612},
  NP:{name:'Nepal',flag:'🇳🇵',languages:['ne-NP','ne','en-US','en'],acceptLang:'ne-NP,ne;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'Asia/Kathmandu',locale:'ne_NP',lat:27.7172,lon:85.324},
  MM:{name:'Myanmar',flag:'🇲🇲',languages:['my-MM','my','en-US','en'],acceptLang:'my-MM,my;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'Asia/Yangon',locale:'my_MM',lat:16.8409,lon:96.1735},
  KH:{name:'Cambodia',flag:'🇰🇭',languages:['km-KH','km','en-US','en'],acceptLang:'km-KH,km;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'Asia/Phnom_Penh',locale:'km_KH',lat:11.5564,lon:104.9282},
  LA:{name:'Laos',flag:'🇱🇦',languages:['lo-LA','lo','en-US','en'],acceptLang:'lo-LA,lo;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'Asia/Vientiane',locale:'lo_LA',lat:17.9757,lon:102.6331},
  MN:{name:'Mongolia',flag:'🇲🇳',languages:['mn-MN','mn','en-US','en'],acceptLang:'mn-MN,mn;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'Asia/Ulaanbaatar',locale:'mn_MN',lat:47.8864,lon:106.9057},
  KZ:{name:'Kazakhstan',flag:'🇰🇿',languages:['kk-KZ','kk','ru-RU','ru'],acceptLang:'kk-KZ,kk;q=0.9,ru-RU;q=0.8,ru;q=0.7',timezone:'Asia/Almaty',locale:'kk_KZ',lat:43.222,lon:76.8512},
  UZ:{name:'Uzbekistan',flag:'🇺🇿',languages:['uz-UZ','uz','ru-RU','ru'],acceptLang:'uz-UZ,uz;q=0.9,ru-RU;q=0.8,ru;q=0.7',timezone:'Asia/Tashkent',locale:'uz_UZ',lat:41.2995,lon:69.2401},
  AF:{name:'Afghanistan',flag:'🇦🇫',languages:['ps-AF','ps','en-US','en'],acceptLang:'ps-AF,ps;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'Asia/Kabul',locale:'ps_AF',lat:34.5553,lon:69.2075},
  // ── Middle East ──
  AE:{name:'UAE',flag:'🇦🇪',languages:['ar-AE','ar','en-AE','en'],acceptLang:'ar-AE,ar;q=0.9,en-AE;q=0.8,en;q=0.7',timezone:'Asia/Dubai',locale:'ar_AE',lat:25.2048,lon:55.2708},
  SA:{name:'Saudi Arabia',flag:'🇸🇦',languages:['ar-SA','ar','en-US','en'],acceptLang:'ar-SA,ar;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'Asia/Riyadh',locale:'ar_SA',lat:24.7136,lon:46.6753},
  IL:{name:'Israel',flag:'🇮🇱',languages:['he-IL','he','en-US','en'],acceptLang:'he-IL,he;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'Asia/Jerusalem',locale:'he_IL',lat:31.7683,lon:35.2137},
  TR:{name:'Turkey',flag:'🇹🇷',languages:['tr-TR','tr','en-US','en'],acceptLang:'tr-TR,tr;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'Europe/Istanbul',locale:'tr_TR',lat:41.0082,lon:28.9784},
  IR:{name:'Iran',flag:'🇮🇷',languages:['fa-IR','fa','en-US','en'],acceptLang:'fa-IR,fa;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'Asia/Tehran',locale:'fa_IR',lat:35.6892,lon:51.389},
  IQ:{name:'Iraq',flag:'🇮🇶',languages:['ar-IQ','ar','en-US','en'],acceptLang:'ar-IQ,ar;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'Asia/Baghdad',locale:'ar_IQ',lat:33.3152,lon:44.3661},
  JO:{name:'Jordan',flag:'🇯🇴',languages:['ar-JO','ar','en-US','en'],acceptLang:'ar-JO,ar;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'Asia/Amman',locale:'ar_JO',lat:31.9454,lon:35.9284},
  LB:{name:'Lebanon',flag:'🇱🇧',languages:['ar-LB','ar','fr-FR','fr','en-US','en'],acceptLang:'ar-LB,ar;q=0.9,fr-FR;q=0.8,fr;q=0.7',timezone:'Asia/Beirut',locale:'ar_LB',lat:33.8938,lon:35.5018},
  KW:{name:'Kuwait',flag:'🇰🇼',languages:['ar-KW','ar','en-US','en'],acceptLang:'ar-KW,ar;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'Asia/Kuwait',locale:'ar_KW',lat:29.3759,lon:47.9774},
  QA:{name:'Qatar',flag:'🇶🇦',languages:['ar-QA','ar','en-US','en'],acceptLang:'ar-QA,ar;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'Asia/Qatar',locale:'ar_QA',lat:25.2854,lon:51.531},
  BH:{name:'Bahrain',flag:'🇧🇭',languages:['ar-BH','ar','en-US','en'],acceptLang:'ar-BH,ar;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'Asia/Bahrain',locale:'ar_BH',lat:26.0667,lon:50.5577},
  OM:{name:'Oman',flag:'🇴🇲',languages:['ar-OM','ar','en-US','en'],acceptLang:'ar-OM,ar;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'Asia/Muscat',locale:'ar_OM',lat:23.5859,lon:58.4059},
  YE:{name:'Yemen',flag:'🇾🇪',languages:['ar-YE','ar','en-US','en'],acceptLang:'ar-YE,ar;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'Asia/Aden',locale:'ar_YE',lat:15.3694,lon:44.191},
  SY:{name:'Syria',flag:'🇸🇾',languages:['ar-SY','ar','en-US','en'],acceptLang:'ar-SY,ar;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'Asia/Damascus',locale:'ar_SY',lat:33.5138,lon:36.2765},
  PS:{name:'Palestine',flag:'🇵🇸',languages:['ar-PS','ar','en-US','en'],acceptLang:'ar-PS,ar;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'Asia/Gaza',locale:'ar_PS',lat:31.9474,lon:35.2272},
  // ── Europe ──
  GB:{name:'United Kingdom',flag:'🇬🇧',languages:['en-GB','en'],acceptLang:'en-GB,en;q=0.9',timezone:'Europe/London',locale:'en_GB',lat:51.5074,lon:-0.1278},
  DE:{name:'Germany',flag:'🇩🇪',languages:['de-DE','de','en-US','en'],acceptLang:'de-DE,de;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'Europe/Berlin',locale:'de_DE',lat:52.52,lon:13.405},
  FR:{name:'France',flag:'🇫🇷',languages:['fr-FR','fr','en-US','en'],acceptLang:'fr-FR,fr;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'Europe/Paris',locale:'fr_FR',lat:48.8566,lon:2.3522},
  NL:{name:'Netherlands',flag:'🇳🇱',languages:['nl-NL','nl','en-US','en'],acceptLang:'nl-NL,nl;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'Europe/Amsterdam',locale:'nl_NL',lat:52.3676,lon:4.9041},
  IT:{name:'Italy',flag:'🇮🇹',languages:['it-IT','it','en-US','en'],acceptLang:'it-IT,it;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'Europe/Rome',locale:'it_IT',lat:41.9028,lon:12.4964},
  ES:{name:'Spain',flag:'🇪🇸',languages:['es-ES','es','en-US','en'],acceptLang:'es-ES,es;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'Europe/Madrid',locale:'es_ES',lat:40.4168,lon:-3.7038},
  PT:{name:'Portugal',flag:'🇵🇹',languages:['pt-PT','pt','en-US','en'],acceptLang:'pt-PT,pt;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'Europe/Lisbon',locale:'pt_PT',lat:38.7223,lon:-9.1393},
  BE:{name:'Belgium',flag:'🇧🇪',languages:['nl-BE','nl','fr-BE','fr','en-US','en'],acceptLang:'nl-BE,nl;q=0.9,fr-BE;q=0.8,fr;q=0.7',timezone:'Europe/Brussels',locale:'nl_BE',lat:50.8503,lon:4.3517},
  CH:{name:'Switzerland',flag:'🇨🇭',languages:['de-CH','de','fr-CH','fr','it-CH','it'],acceptLang:'de-CH,de;q=0.9,fr-CH;q=0.8,fr;q=0.7',timezone:'Europe/Zurich',locale:'de_CH',lat:47.3769,lon:8.5417},
  AT:{name:'Austria',flag:'🇦🇹',languages:['de-AT','de','en-US','en'],acceptLang:'de-AT,de;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'Europe/Vienna',locale:'de_AT',lat:48.2082,lon:16.3738},
  SE:{name:'Sweden',flag:'🇸🇪',languages:['sv-SE','sv','en-US','en'],acceptLang:'sv-SE,sv;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'Europe/Stockholm',locale:'sv_SE',lat:59.3293,lon:18.0686},
  NO:{name:'Norway',flag:'🇳🇴',languages:['nb-NO','nb','en-US','en'],acceptLang:'nb-NO,nb;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'Europe/Oslo',locale:'nb_NO',lat:59.9139,lon:10.7522},
  DK:{name:'Denmark',flag:'🇩🇰',languages:['da-DK','da','en-US','en'],acceptLang:'da-DK,da;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'Europe/Copenhagen',locale:'da_DK',lat:55.6761,lon:12.5683},
  FI:{name:'Finland',flag:'🇫🇮',languages:['fi-FI','fi','en-US','en'],acceptLang:'fi-FI,fi;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'Europe/Helsinki',locale:'fi_FI',lat:60.1699,lon:24.9384},
  IS:{name:'Iceland',flag:'🇮🇸',languages:['is-IS','is','en-US','en'],acceptLang:'is-IS,is;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'Atlantic/Reykjavik',locale:'is_IS',lat:64.1466,lon:-21.9426},
  IE:{name:'Ireland',flag:'🇮🇪',languages:['en-IE','en','ga-IE','ga'],acceptLang:'en-IE,en;q=0.9,ga-IE;q=0.8',timezone:'Europe/Dublin',locale:'en_IE',lat:53.3498,lon:-6.2603},
  PL:{name:'Poland',flag:'🇵🇱',languages:['pl-PL','pl','en-US','en'],acceptLang:'pl-PL,pl;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'Europe/Warsaw',locale:'pl_PL',lat:52.2297,lon:21.0122},
  CZ:{name:'Czechia',flag:'🇨🇿',languages:['cs-CZ','cs','en-US','en'],acceptLang:'cs-CZ,cs;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'Europe/Prague',locale:'cs_CZ',lat:50.0755,lon:14.4378},
  SK:{name:'Slovakia',flag:'🇸🇰',languages:['sk-SK','sk','en-US','en'],acceptLang:'sk-SK,sk;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'Europe/Bratislava',locale:'sk_SK',lat:48.1486,lon:17.1077},
  HU:{name:'Hungary',flag:'🇭🇺',languages:['hu-HU','hu','en-US','en'],acceptLang:'hu-HU,hu;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'Europe/Budapest',locale:'hu_HU',lat:47.4979,lon:19.0402},
  RO:{name:'Romania',flag:'🇷🇴',languages:['ro-RO','ro','en-US','en'],acceptLang:'ro-RO,ro;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'Europe/Bucharest',locale:'ro_RO',lat:44.4268,lon:26.1025},
  BG:{name:'Bulgaria',flag:'🇧🇬',languages:['bg-BG','bg','en-US','en'],acceptLang:'bg-BG,bg;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'Europe/Sofia',locale:'bg_BG',lat:42.6977,lon:23.3219},
  GR:{name:'Greece',flag:'🇬🇷',languages:['el-GR','el','en-US','en'],acceptLang:'el-GR,el;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'Europe/Athens',locale:'el_GR',lat:37.9838,lon:23.7275},
  HR:{name:'Croatia',flag:'🇭🇷',languages:['hr-HR','hr','en-US','en'],acceptLang:'hr-HR,hr;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'Europe/Zagreb',locale:'hr_HR',lat:45.815,lon:15.9819},
  RS:{name:'Serbia',flag:'🇷🇸',languages:['sr-RS','sr','en-US','en'],acceptLang:'sr-RS,sr;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'Europe/Belgrade',locale:'sr_RS',lat:44.7866,lon:20.4489},
  UA:{name:'Ukraine',flag:'🇺🇦',languages:['uk-UA','uk','en-US','en'],acceptLang:'uk-UA,uk;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'Europe/Kyiv',locale:'uk_UA',lat:50.4501,lon:30.5234},
  RU:{name:'Russia',flag:'🇷🇺',languages:['ru-RU','ru','en-US','en'],acceptLang:'ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'Europe/Moscow',locale:'ru_RU',lat:55.7558,lon:37.6173},
  BY:{name:'Belarus',flag:'🇧🇾',languages:['be-BY','be','ru-RU','ru'],acceptLang:'be-BY,be;q=0.9,ru-RU;q=0.8,ru;q=0.7',timezone:'Europe/Minsk',locale:'be_BY',lat:53.9006,lon:27.559},
  LT:{name:'Lithuania',flag:'🇱🇹',languages:['lt-LT','lt','en-US','en'],acceptLang:'lt-LT,lt;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'Europe/Vilnius',locale:'lt_LT',lat:54.6872,lon:25.2797},
  LV:{name:'Latvia',flag:'🇱🇻',languages:['lv-LV','lv','en-US','en'],acceptLang:'lv-LV,lv;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'Europe/Riga',locale:'lv_LV',lat:56.9496,lon:24.1052},
  EE:{name:'Estonia',flag:'🇪🇪',languages:['et-EE','et','en-US','en'],acceptLang:'et-EE,et;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'Europe/Tallinn',locale:'et_EE',lat:59.437,lon:24.7536},
  SI:{name:'Slovenia',flag:'🇸🇮',languages:['sl-SI','sl','en-US','en'],acceptLang:'sl-SI,sl;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'Europe/Ljubljana',locale:'sl_SI',lat:46.0569,lon:14.5058},
  AL:{name:'Albania',flag:'🇦🇱',languages:['sq-AL','sq','en-US','en'],acceptLang:'sq-AL,sq;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'Europe/Tirane',locale:'sq_AL',lat:41.3275,lon:19.8187},
  BA:{name:'Bosnia',flag:'🇧🇦',languages:['bs-BA','bs','en-US','en'],acceptLang:'bs-BA,bs;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'Europe/Sarajevo',locale:'bs_BA',lat:43.8563,lon:18.4131},
  LU:{name:'Luxembourg',flag:'🇱🇺',languages:['fr-LU','fr','de-LU','de','lb-LU','lb'],acceptLang:'fr-LU,fr;q=0.9,de-LU;q=0.8,en-US;q=0.7',timezone:'Europe/Luxembourg',locale:'fr_LU',lat:49.6116,lon:6.1319},
  MT:{name:'Malta',flag:'🇲🇹',languages:['mt-MT','mt','en-MT','en'],acceptLang:'mt-MT,mt;q=0.9,en-MT;q=0.8,en;q=0.7',timezone:'Europe/Malta',locale:'mt_MT',lat:35.8989,lon:14.5146},
  CY:{name:'Cyprus',flag:'🇨🇾',languages:['el-CY','el','en-US','en'],acceptLang:'el-CY,el;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'Asia/Nicosia',locale:'el_CY',lat:35.1856,lon:33.3823},
  // ── Africa ──
  NG:{name:'Nigeria',flag:'🇳🇬',languages:['en-NG','en'],acceptLang:'en-NG,en;q=0.9',timezone:'Africa/Lagos',locale:'en_NG',lat:6.5244,lon:3.3792},
  ZA:{name:'South Africa',flag:'🇿🇦',languages:['en-ZA','en','af-ZA','af'],acceptLang:'en-ZA,en;q=0.9,af-ZA;q=0.8',timezone:'Africa/Johannesburg',locale:'en_ZA',lat:-26.2041,lon:28.0473},
  EG:{name:'Egypt',flag:'🇪🇬',languages:['ar-EG','ar','en-US','en'],acceptLang:'ar-EG,ar;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'Africa/Cairo',locale:'ar_EG',lat:30.0444,lon:31.2357},
  KE:{name:'Kenya',flag:'🇰🇪',languages:['en-KE','en','sw-KE','sw'],acceptLang:'en-KE,en;q=0.9,sw-KE;q=0.8',timezone:'Africa/Nairobi',locale:'en_KE',lat:-1.2921,lon:36.8219},
  MA:{name:'Morocco',flag:'🇲🇦',languages:['ar-MA','ar','fr-FR','fr','en-US','en'],acceptLang:'ar-MA,ar;q=0.9,fr-FR;q=0.8,fr;q=0.7',timezone:'Africa/Casablanca',locale:'ar_MA',lat:33.5731,lon:-7.5898},
  ET:{name:'Ethiopia',flag:'🇪🇹',languages:['am-ET','am','en-US','en'],acceptLang:'am-ET,am;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'Africa/Addis_Ababa',locale:'am_ET',lat:9.03,lon:38.74},
  GH:{name:'Ghana',flag:'🇬🇭',languages:['en-GH','en'],acceptLang:'en-GH,en;q=0.9',timezone:'Africa/Accra',locale:'en_GH',lat:5.6037,lon:-0.187},
  DZ:{name:'Algeria',flag:'🇩🇿',languages:['ar-DZ','ar','fr-FR','fr'],acceptLang:'ar-DZ,ar;q=0.9,fr-FR;q=0.8,fr;q=0.7',timezone:'Africa/Algiers',locale:'ar_DZ',lat:36.7538,lon:3.0588},
  TN:{name:'Tunisia',flag:'🇹🇳',languages:['ar-TN','ar','fr-FR','fr'],acceptLang:'ar-TN,ar;q=0.9,fr-FR;q=0.8,fr;q=0.7',timezone:'Africa/Tunis',locale:'ar_TN',lat:36.8065,lon:10.1815},
  UG:{name:'Uganda',flag:'🇺🇬',languages:['en-UG','en','sw-UG','sw'],acceptLang:'en-UG,en;q=0.9,sw-UG;q=0.8',timezone:'Africa/Kampala',locale:'en_UG',lat:0.3476,lon:32.5825},
  TZ:{name:'Tanzania',flag:'🇹🇿',languages:['sw-TZ','sw','en-TZ','en'],acceptLang:'sw-TZ,sw;q=0.9,en-TZ;q=0.8,en;q=0.7',timezone:'Africa/Dar_es_Salaam',locale:'sw_TZ',lat:-6.7924,lon:39.2083},
  SN:{name:'Senegal',flag:'🇸🇳',languages:['fr-SN','fr','en-US','en'],acceptLang:'fr-SN,fr;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'Africa/Dakar',locale:'fr_SN',lat:14.6928,lon:-17.4467},
  CI:{name:'Ivory Coast',flag:'🇨🇮',languages:['fr-CI','fr','en-US','en'],acceptLang:'fr-CI,fr;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'Africa/Abidjan',locale:'fr_CI',lat:5.36,lon:-4.0083},
  CM:{name:'Cameroon',flag:'🇨🇲',languages:['fr-CM','fr','en-CM','en'],acceptLang:'fr-CM,fr;q=0.9,en-CM;q=0.8,en;q=0.7',timezone:'Africa/Douala',locale:'fr_CM',lat:4.0511,lon:9.7679},
  AO:{name:'Angola',flag:'🇦🇴',languages:['pt-AO','pt','en-US','en'],acceptLang:'pt-AO,pt;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'Africa/Luanda',locale:'pt_AO',lat:-8.839,lon:13.2894},
  // ── Americas ──
  US:{name:'United States',flag:'🇺🇸',languages:['en-US','en'],acceptLang:'en-US,en;q=0.9',timezone:'America/New_York',locale:'en_US',lat:40.7128,lon:-74.006},
  CA:{name:'Canada',flag:'🇨🇦',languages:['en-CA','en','fr-CA','fr'],acceptLang:'en-CA,en;q=0.9,fr-CA;q=0.8,fr;q=0.7',timezone:'America/Toronto',locale:'en_CA',lat:43.6532,lon:-79.3832},
  MX:{name:'Mexico',flag:'🇲🇽',languages:['es-MX','es','en-US','en'],acceptLang:'es-MX,es;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'America/Mexico_City',locale:'es_MX',lat:19.4326,lon:-99.1332},
  BR:{name:'Brazil',flag:'🇧🇷',languages:['pt-BR','pt','en-US','en'],acceptLang:'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'America/Sao_Paulo',locale:'pt_BR',lat:-23.5505,lon:-46.6333},
  AR:{name:'Argentina',flag:'🇦🇷',languages:['es-AR','es','en-US','en'],acceptLang:'es-AR,es;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'America/Argentina/Buenos_Aires',locale:'es_AR',lat:-34.6037,lon:-58.3816},
  CL:{name:'Chile',flag:'🇨🇱',languages:['es-CL','es','en-US','en'],acceptLang:'es-CL,es;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'America/Santiago',locale:'es_CL',lat:-33.4489,lon:-70.6693},
  CO:{name:'Colombia',flag:'🇨🇴',languages:['es-CO','es','en-US','en'],acceptLang:'es-CO,es;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'America/Bogota',locale:'es_CO',lat:4.711,lon:-74.0721},
  PE:{name:'Peru',flag:'🇵🇪',languages:['es-PE','es','en-US','en'],acceptLang:'es-PE,es;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'America/Lima',locale:'es_PE',lat:-12.0464,lon:-77.0428},
  VE:{name:'Venezuela',flag:'🇻🇪',languages:['es-VE','es','en-US','en'],acceptLang:'es-VE,es;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'America/Caracas',locale:'es_VE',lat:10.4806,lon:-66.9036},
  EC:{name:'Ecuador',flag:'🇪🇨',languages:['es-EC','es','en-US','en'],acceptLang:'es-EC,es;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'America/Guayaquil',locale:'es_EC',lat:-0.1807,lon:-78.4678},
  BO:{name:'Bolivia',flag:'🇧🇴',languages:['es-BO','es','en-US','en'],acceptLang:'es-BO,es;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'America/La_Paz',locale:'es_BO',lat:-16.4897,lon:-68.1193},
  PY:{name:'Paraguay',flag:'🇵🇾',languages:['es-PY','es','en-US','en'],acceptLang:'es-PY,es;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'America/Asuncion',locale:'es_PY',lat:-25.2637,lon:-57.5759},
  UY:{name:'Uruguay',flag:'🇺🇾',languages:['es-UY','es','en-US','en'],acceptLang:'es-UY,es;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'America/Montevideo',locale:'es_UY',lat:-34.9011,lon:-56.1645},
  GT:{name:'Guatemala',flag:'🇬🇹',languages:['es-GT','es','en-US','en'],acceptLang:'es-GT,es;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'America/Guatemala',locale:'es_GT',lat:14.6349,lon:-90.5069},
  CR:{name:'Costa Rica',flag:'🇨🇷',languages:['es-CR','es','en-US','en'],acceptLang:'es-CR,es;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'America/Costa_Rica',locale:'es_CR',lat:9.9281,lon:-84.0907},
  PA:{name:'Panama',flag:'🇵🇦',languages:['es-PA','es','en-US','en'],acceptLang:'es-PA,es;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'America/Panama',locale:'es_PA',lat:8.9824,lon:-79.5199},
  DO:{name:'Dominican Rep.',flag:'🇩🇴',languages:['es-DO','es','en-US','en'],acceptLang:'es-DO,es;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'America/Santo_Domingo',locale:'es_DO',lat:18.4861,lon:-69.9312},
  CU:{name:'Cuba',flag:'🇨🇺',languages:['es-CU','es','en-US','en'],acceptLang:'es-CU,es;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'America/Havana',locale:'es_CU',lat:23.1136,lon:-82.3666},
  JM:{name:'Jamaica',flag:'🇯🇲',languages:['en-JM','en'],acceptLang:'en-JM,en;q=0.9',timezone:'America/Jamaica',locale:'en_JM',lat:17.9712,lon:-76.7928},
  HN:{name:'Honduras',flag:'🇭🇳',languages:['es-HN','es','en-US','en'],acceptLang:'es-HN,es;q=0.9,en-US;q=0.8,en;q=0.7',timezone:'America/Tegucigalpa',locale:'es_HN',lat:14.0723,lon:-87.1921},
  // ── Oceania ──
  AU:{name:'Australia',flag:'🇦🇺',languages:['en-AU','en'],acceptLang:'en-AU,en;q=0.9',timezone:'Australia/Sydney',locale:'en_AU',lat:-33.8688,lon:151.2093},
  NZ:{name:'New Zealand',flag:'🇳🇿',languages:['en-NZ','en'],acceptLang:'en-NZ,en;q=0.9',timezone:'Pacific/Auckland',locale:'en_NZ',lat:-36.8485,lon:174.7633},
  FJ:{name:'Fiji',flag:'🇫🇯',languages:['en-FJ','en'],acceptLang:'en-FJ,en;q=0.9',timezone:'Pacific/Fiji',locale:'en_FJ',lat:-18.1416,lon:178.4419},
  PG:{name:'Papua New Guinea',flag:'🇵🇬',languages:['en-PG','en'],acceptLang:'en-PG,en;q=0.9',timezone:'Pacific/Port_Moresby',locale:'en_PG',lat:-9.4438,lon:147.1803},
};

// ── USER AGENT POOLS BY OS ──────────────────────────────────────────
const _UA_WIN = [
  {ua:'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',platform:'Win32',platformStr:'Windows',platformVersion:'15.0.0',brands:[{brand:'Chromium',version:'124'},{brand:'Google Chrome',version:'124'},{brand:'Not-A.Brand',version:'99'}],fullVer:'124.0.6367.119',arch:'x86',bitness:'64',mobile:false,model:''},
  {ua:'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36',platform:'Win32',platformStr:'Windows',platformVersion:'15.0.0',brands:[{brand:'Chromium',version:'123'},{brand:'Google Chrome',version:'123'},{brand:'Not_A Brand',version:'8'}],fullVer:'123.0.6312.86',arch:'x86',bitness:'64',mobile:false,model:''},
  {ua:'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',platform:'Win32',platformStr:'Windows',platformVersion:'15.0.0',brands:[{brand:'Chromium',version:'122'},{brand:'Google Chrome',version:'122'},{brand:'Not_A Brand',version:'8'}],fullVer:'122.0.6261.112',arch:'x86',bitness:'64',mobile:false,model:''},
  {ua:'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 Edg/124.0.0.0',platform:'Win32',platformStr:'Windows',platformVersion:'15.0.0',brands:[{brand:'Chromium',version:'124'},{brand:'Microsoft Edge',version:'124'},{brand:'Not-A.Brand',version:'99'}],fullVer:'124.0.2478.51',arch:'x86',bitness:'64',mobile:false,model:''},
];
const _UA_ANDROID = [
  {ua:'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36',platform:'Linux armv81',platformStr:'Android',platformVersion:'14.0.0',brands:[{brand:'Chromium',version:'124'},{brand:'Google Chrome',version:'124'},{brand:'Not-A.Brand',version:'99'}],fullVer:'124.0.6367.82',arch:'arm',bitness:'64',mobile:true,model:'Pixel 8'},
  {ua:'Mozilla/5.0 (Linux; Android 14; SM-S928B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36',platform:'Linux armv81',platformStr:'Android',platformVersion:'14.0.0',brands:[{brand:'Chromium',version:'124'},{brand:'Google Chrome',version:'124'},{brand:'Not-A.Brand',version:'99'}],fullVer:'124.0.6367.82',arch:'arm',bitness:'64',mobile:true,model:'SM-S928B'},
  {ua:'Mozilla/5.0 (Linux; Android 13; SM-A536B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Mobile Safari/537.36',platform:'Linux armv81',platformStr:'Android',platformVersion:'13.0.0',brands:[{brand:'Chromium',version:'123'},{brand:'Google Chrome',version:'123'},{brand:'Not_A Brand',version:'8'}],fullVer:'123.0.6312.118',arch:'arm',bitness:'64',mobile:true,model:'SM-A536B'},
  {ua:'Mozilla/5.0 (Linux; Android 14; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Mobile Safari/537.36',platform:'Linux armv81',platformStr:'Android',platformVersion:'14.0.0',brands:[{brand:'Chromium',version:'123'},{brand:'Google Chrome',version:'123'},{brand:'Not_A Brand',version:'8'}],fullVer:'123.0.6312.118',arch:'arm',bitness:'64',mobile:true,model:'Pixel 7'},
];
const _UA_IPHONE = [
  {ua:'Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1',platform:'iPhone',platformStr:'iOS',platformVersion:'17.5.0',brands:[],fullVer:'17.5',arch:'',bitness:'64',mobile:true,model:'iPhone'},
  {ua:'Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1',platform:'iPhone',platformStr:'iOS',platformVersion:'17.4.0',brands:[],fullVer:'17.4',arch:'',bitness:'64',mobile:true,model:'iPhone'},
  {ua:'Mozilla/5.0 (iPhone; CPU iPhone OS 16_7_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1',platform:'iPhone',platformStr:'iOS',platformVersion:'16.7.2',brands:[],fullVer:'16.6',arch:'',bitness:'64',mobile:true,model:'iPhone'},
  {ua:'Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/124.0.6367.111 Mobile/15E148 Safari/604.1',platform:'iPhone',platformStr:'iOS',platformVersion:'17.5.0',brands:[],fullVer:'124.0.6367.111',arch:'',bitness:'64',mobile:true,model:'iPhone'},
];

// ── SCREEN PROFILES BY OS ───────────────────────────────────────────
const _SCR_DESKTOP = [
  {w:1920,h:1080,dpr:1},{w:1366,h:768,dpr:1},{w:1440,h:900,dpr:1},
  {w:1536,h:864,dpr:1},{w:1280,h:800,dpr:1},{w:2560,h:1440,dpr:2},
  {w:1600,h:900,dpr:1},{w:1280,h:1024,dpr:1}
];
const _SCR_ANDROID = [
  {w:412,h:915,dpr:2.625},{w:393,h:851,dpr:2.75},{w:360,h:780,dpr:3},
  {w:384,h:854,dpr:2.625},{w:412,h:892,dpr:2.625}
];
const _SCR_IPHONE = [
  {w:390,h:844,dpr:3},{w:375,h:812,dpr:3},{w:393,h:852,dpr:3},
  {w:430,h:932,dpr:3},{w:414,h:896,dpr:3}
];

function _pickUA(os, seed) {
  const list = os==='android' ? _UA_ANDROID : os==='iphone' ? _UA_IPHONE : _UA_WIN;
  return list[seed % list.length];
}
function _pickScr(os, seed) {
  const list = os==='android' ? _SCR_ANDROID : os==='iphone' ? _SCR_IPHONE : _SCR_DESKTOP;
  return list[seed % list.length];
}

function buildFingerprint(countryCode, seed, os) {
  os = os || 'windows';
  const p = _0x827fwn8a9[countryCode] || _0x827fwn8a9['US'];
  const uap = _pickUA(os, seed);
  const scr = _pickScr(os, seed);
  const jlat = (((seed*13)%200)-100)/50000;
  const jlon = (((seed*17)%200)-100)/50000;
  return {
    active:true, countryCode, countryName:p.name, seed, os,
    userAgent:uap.ua, platform:uap.platform, platformStr:uap.platformStr,
    platformVersion:uap.platformVersion, brands:uap.brands, fullVer:uap.fullVer,
    arch:uap.arch, bitness:uap.bitness, mobile:uap.mobile, model:uap.model||'',
    language:p.languages[0], languages:p.languages,
    acceptLang:p.acceptLang, timezone:p.timezone, locale:p.locale,
    lat:+(p.lat+jlat).toFixed(6), lon:+(p.lon+jlon).toFixed(6), accuracy:15+(seed%25),
    screenW:scr.w, screenH:scr.h, dpr:scr.dpr,
  };
}
chrome.runtime.onInstalled.addListener(()=>{
  chrome.storage.local.get(['proxies'],(d)=>{
    if(!d.proxies) chrome.storage.local.set({proxies:[],activeProxy:null,fingerprint:null});
  });
  setBadge('OFF','#ef4444');
});
chrome.runtime.onMessage.addListener((msg,sender,sendResponse)=>{
  if(msg.action==='setProxy'){applyProxy(msg.proxy);sendResponse({ok:true});}
  else if(msg.action==='clearProxy'){clearProxy();sendResponse({ok:true});}
  else if(msg.action==='checkProxy'){doCheck(msg.proxy).then(r=>sendResponse(r));return true;}
  else if(msg.action==='getFingerprint'){chrome.storage.local.get(['fingerprint'],(d)=>sendResponse(d.fingerprint||null));return true;}
  else if(msg.action==='checkSpoof'){sendResponse({ok:true,allowed:true,spoof_today:0});}
  else if(msg.action==='buildFP'){sendResponse(buildFingerprint(msg.countryCode,msg.seed||Math.floor(Math.random()*9999),msg.os));}
  else if(msg.action==='setFingerprint'){applyFingerprint(msg.fingerprint);sendResponse({ok:true});}
  else if(msg.action==='clearFingerprint'){clearFingerprint();sendResponse({ok:true});}
  else if(msg.action==='detectCountry'){detectCountryFromIP().then(r=>sendResponse(r));return true;}
  else if(msg.action==='listCountries'){sendResponse(Object.entries(_0x827fwn8a9).map(([code,p])=>({code,name:p.name,flag:p.flag||''})));}
  return true;
});
function applyProxy(proxy){
  if(!proxy){clearProxy();return;}
  const scheme=proxy.type==='socks5'?'socks5':proxy.type==='socks4'?'socks4':'http';
  chrome.proxy.settings.set({
    value:{mode:'fixed_servers',rules:{singleProxy:{scheme,host:proxy.host,port:parseInt(proxy.port)},bypassList:['localhost','127.0.0.1','::1']}},
    scope:'regular'
  },()=>{chrome.storage.local.set({activeProxy:proxy});setBadge('ON','#22c55e');});
}
function clearProxy(){
  chrome.proxy.settings.set({value:{mode:'direct'},scope:'regular'},()=>{
    chrome.storage.local.set({activeProxy:null});setBadge('OFF','#ef4444');
  });
}
chrome.webRequest.onAuthRequired.addListener(
  (details,callback)=>{
    chrome.storage.local.get(['activeProxy'],(d)=>{
      const p=d.activeProxy;
      callback(p&&p.user?{authCredentials:{username:p.user,password:p.pass||''}}:{});
    });
  },
  {urls:['<all_urls>']},['asyncBlocking']
);
const _0xd676dqow0=new Set();
function cdp(tabId,method,params={}){
  return new Promise(resolve=>{
    chrome.debugger.sendCommand({tabId},method,params,result=>{
      chrome.runtime.lastError;
      resolve(result||null);
    });
  });
}
async function attachTab(tabId){
  if(_0xd676dqow0.has(tabId)) return true;
  return new Promise(resolve=>{
    chrome.debugger.attach({tabId},'1.3',()=>{
      if(chrome.runtime.lastError){resolve(false);return;}
      _0xd676dqow0.add(tabId);resolve(true);
    });
  });
}
async function spoofTab(tabId,fp){
  if(!fp||!fp.active) return;
  const ok=await attachTab(tabId);
  if(!ok) return;
  await cdp(tabId,'Emulation.setTimezoneOverride',{timezoneId:fp.timezone});
  await cdp(tabId,'Emulation.setLocaleOverride',{locale:fp.locale});
  const meta = {
    brands: fp.brands||[],
    fullVersionList: (fp.brands||[]).map(b=>({brand:b.brand,version:fp.fullVer||(b.version+'.0.0.0')})),
    platform: fp.platformStr,
    platformVersion: fp.platformVersion,
    architecture: fp.arch,
    model: fp.model||'',
    mobile: !!fp.mobile,
    bitness: fp.bitness,
    wow64: false
  };
  await cdp(tabId,'Emulation.setUserAgentOverride',{
    userAgent:fp.userAgent,
    acceptLanguage:fp.acceptLang,
    platform:fp.platform,
    userAgentMetadata:meta
  });
  await cdp(tabId,'Emulation.setGeolocationOverride',{
    latitude:fp.lat,longitude:fp.lon,accuracy:fp.accuracy
  });
  await cdp(tabId,'Emulation.setTouchEmulationEnabled',{enabled:!!fp.mobile,maxTouchPoints:fp.mobile?5:0});
  if (fp.mobile) {
    // Mobile profiles need concrete dims so viewport/touch propagates correctly
    await cdp(tabId,'Emulation.setDeviceMetricsOverride',{
      width: fp.screenW || 390,
      height: fp.screenH || 844,
      deviceScaleFactor: fp.dpr || 3,
      mobile: true,
      screenWidth: fp.screenW || 390,
      screenHeight: fp.screenH || 844,
    });
  } else {
    // Desktop — keep 0/0 so user's actual window dims persist
    await cdp(tabId,'Emulation.setDeviceMetricsOverride',{
      width:0, height:0,
      deviceScaleFactor: fp.dpr || 1,
      mobile: false,
    });
  }
  await cdp(tabId,'Network.enable');
  await cdp(tabId,'Network.setExtraHTTPHeaders',{
    headers:{
      'Accept-Language':fp.acceptLang,
      'User-Agent':fp.userAgent
    }
  });
  await cdp(tabId,'Page.enable');
  const isMobile = !!fp.mobile;
  await cdp(tabId,'Page.addScriptToEvaluateOnNewDocument',{
    source:`
    try {
      Object.defineProperty(navigator,'maxTouchPoints',{get:()=>${isMobile?5:0},configurable:true});
      if(navigator.getBattery) {
        navigator.getBattery = () => Promise.resolve({
          charging:true, chargingTime:0, dischargingTime:Infinity, level:1.0,
          addEventListener:()=>{}, removeEventListener:()=>{}
        });
      }
      if(navigator.connection) {
        Object.defineProperty(navigator,'connection',{
          get:()=>({
            type:'${isMobile?"cellular":"ethernet"}', effectiveType:'4g',
            downlink:10, downlinkMax:Infinity,
            rtt:50, saveData:false,
            addEventListener:()=>{}, removeEventListener:()=>{}
          }),
          configurable:true
        });
      }
      Object.defineProperty(navigator,'hardwareConcurrency',{get:()=>${isMobile?6:8},configurable:true});
      Object.defineProperty(navigator,'deviceMemory',{get:()=>${isMobile?4:8},configurable:true});
      Object.defineProperty(navigator,'platform',{get:()=>'${fp.platform}',configurable:true});
      navigator.vibrate = ()=>false;
      const _0x87a76qphj = window.RTCPeerConnection || window.webkitRTCPeerConnection;
      if(_0x87a76qphj) {
        const _orig = _0x87a76qphj;
        window.RTCPeerConnection = function(config, ...args) {
          if(config && config.iceServers) { config.iceServers = []; }
          return new _orig(config, ...args);
        };
        window.RTCPeerConnection.prototype = _orig.prototype;
      }
      try {
        Object.defineProperty(screen,'width',{get:()=>${fp.screenW},configurable:true});
        Object.defineProperty(screen,'height',{get:()=>${fp.screenH},configurable:true});
        Object.defineProperty(screen,'availWidth',{get:()=>${fp.screenW},configurable:true});
        Object.defineProperty(screen,'availHeight',{get:()=>${fp.screenH}-40,configurable:true});
        Object.defineProperty(screen,'colorDepth',{get:()=>24,configurable:true});
        Object.defineProperty(screen,'pixelDepth',{get:()=>24,configurable:true});
      } catch(e){}
    } catch(e){}
    `
  });
}
async function detachTab(tabId){
  if(!_0xd676dqow0.has(tabId)) return;
  return new Promise(resolve=>{
    chrome.debugger.detach({tabId},()=>{
      _0xd676dqow0.delete(tabId);chrome.runtime.lastError;resolve();
    });
  });
}
chrome.tabs.onUpdated.addListener(async(tabId,changeInfo)=>{
  if(changeInfo.status!=='loading') return;
  const {fingerprint}=await new Promise(r=>chrome.storage.local.get(['fingerprint'],r));
  if(fingerprint&&fingerprint.active) spoofTab(tabId,fingerprint);
});
chrome.tabs.onRemoved.addListener(tabId=>_0xd676dqow0.delete(tabId));
chrome.debugger.onDetach.addListener(src=>{if(src.tabId)_0xd676dqow0.delete(src.tabId);});
function applyFingerprint(fp){
  chrome.storage.local.set({fingerprint:fp});
  updateDNRHeaders(fp);
  chrome.tabs.query({},(tabs)=>{
    tabs.forEach(tab=>{
      if(tab.id&&tab.url&&!tab.url.startsWith('chrome://')&&!tab.url.startsWith('about:'))
        spoofTab(tab.id,fp);
    });
  });
}
function clearFingerprint(){
  chrome.storage.local.set({fingerprint:{active:false}});
  chrome.declarativeNetRequest.updateDynamicRules({removeRuleIds:[1]});
  chrome.tabs.query({},(tabs)=>tabs.forEach(tab=>{if(tab.id)detachTab(tab.id);}));
}
function updateDNRHeaders(fp){
  const headers = [
    {header:'Accept-Language',operation:'set',value:fp.acceptLang},
    {header:'User-Agent',operation:'set',value:fp.userAgent},
  ];
  if (fp.brands && fp.brands.length) {
    headers.push({header:'Sec-CH-UA',operation:'set',value:fp.brands.map(b=>`"${b.brand}";v="${b.version}"`).join(', ')});
    headers.push({header:'Sec-CH-UA-Platform',operation:'set',value:`"${fp.platformStr}"`});
    headers.push({header:'Sec-CH-UA-Mobile',operation:'set',value: fp.mobile ? '?1' : '?0'});
  } else {
    // iPhone Safari — no Sec-CH-UA, remove if present
    headers.push({header:'Sec-CH-UA',operation:'remove'});
    headers.push({header:'Sec-CH-UA-Platform',operation:'remove'});
    headers.push({header:'Sec-CH-UA-Mobile',operation:'remove'});
  }
  chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds:[1],
    addRules:[{
      id:1,priority:1,
      action:{type:'modifyHeaders',requestHeaders:headers},
      condition:{urlFilter:'*',resourceTypes:['main_frame','sub_frame','xmlhttprequest','other','script','image','stylesheet','font','media']}
    }]
  });
}
async function detectCountryFromIP(){
  const apis=[
    {url:'https://ipapi.co/json/',code:j=>j.country_code},
    {url:'https://ip-api.com/json/?fields=countryCode',code:j=>j.countryCode},
    {url:'https://api.country.is/',code:j=>j.country},
  ];
  for(const api of apis){
    try{
      const r=await fetch(api.url,{cache:'no-store'});
      if(!r.ok) continue;
      const j=await r.json();
      const code=api.code(j);
      if(code&&code.length===2){const cc=code.toUpperCase();return{code:cc,name:_0x827fwn8a9[cc]?.name||cc};}
    }catch(_){}
  }
  return{code:'US',name:'United States'};
}
async function doCheck(proxy){
  const _0xb5a5jdigl=8000,ts=Date.now();
  try{
    const ctrl=new AbortController();
    const tid=setTimeout(()=>ctrl.abort(),_0xb5a5jdigl);
    await fetch(`http://${proxy.host}:${proxy.port}/`,{signal:ctrl.signal,cache:'no-store',mode:'no-cors'});
    clearTimeout(tid);
    return{success:true,latency:Date.now()-ts};
  }catch(e){
    if(e.name==='AbortError') return{success:false,latency:null};
    return{success:true,latency:Date.now()-ts};
  }
}
function setBadge(text,color){
  chrome.action.setBadgeText({text});
  chrome.action.setBadgeBackgroundColor({color});
}

const ZS_API = 'https://project--1963f468-1829-477a-aa1d-f73ff1aa69de-dev.lovable.app';

// ── NOTIFY / HITS / RECORD + STRIPE IFRAME FILL ────────────────────────
chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (msg.action === 'notify') {
    chrome.notifications.create({
      type:'basic', iconUrl:'icons/icon48.png',
      title: msg.title, message: msg.body,
    });
  }

  if (msg.action === 'recordSuccess') {
    fetch(`${ZS_API}/api/public/record-success`, {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({user_id:msg.user_id, card:msg.card, domain:msg.domain})
    }).catch(()=>{});
  }

  if (msg.action === 'checkHits') {
    fetch(`${ZS_API}/api/public/check-hits`, {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({user_id:msg.user_id})
    }).then(r=>r.json()).then(reply).catch(()=>reply({allowed:true}));
    return true;
  }

  if (msg.action === 'fillStripeIframe') {
    const tabId = sender?.tab?.id;
    if (!tabId || !msg.card) return;
    const card = msg.card;
    chrome.scripting.executeScript({
      target: { tabId, allFrames: true },
      func: function(cardData) {
        const host = window.location.host;
        const isStripe = host.includes('stripe.com') || host.includes('js.stripe.com');
        if (!isStripe && !document.querySelector('input[name="cardnumber"],input[data-elements-stable-field-name]')) return;
        const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;
        function fillInput(el, value) {
          if (!el) return false;
          try {
            el.focus();
            try {
              const dt = new DataTransfer();
              dt.setData('text/plain', value);
              el.dispatchEvent(new ClipboardEvent('paste', { bubbles: true, cancelable: true, clipboardData: dt }));
              if ((el.value || '').replace(/\s/g, '') === (value || '').replace(/\s/g, '')) {
                el.dispatchEvent(new Event('input', { bubbles: true }));
                el.dispatchEvent(new Event('change', { bubbles: true }));
                return true;
              }
            } catch(_) {}
            try {
              el.focus();
              document.execCommand('selectAll', false);
              document.execCommand('delete', false);
              const ok = document.execCommand('insertText', false, value);
              if (ok && el.value) {
                el.dispatchEvent(new Event('input', { bubbles: true }));
                el.dispatchEvent(new Event('change', { bubbles: true }));
                return true;
              }
            } catch(_) {}
            if (nativeSetter) nativeSetter.call(el, value);
            else el.value = value;
            ['input', 'change', 'keyup', 'blur'].forEach(e => el.dispatchEvent(new Event(e, { bubbles: true })));
            return true;
          } catch(e) { return false; }
        }
        function queryAll(...sels) {
          for (const s of sels) {
            try { const el = document.querySelector(s); if (el) return el; } catch(_) {}
          }
          return null;
        }
        const numEl = queryAll('input[name="cardnumber"]','input[data-elements-stable-field-name="cardNumber"]','input[autocomplete*="cc-number"]','input[placeholder*="1234" i]','input[class*="CardNumber"]');
        if (numEl) {
          const spaced = cardData.number.replace(/\D/g,'').replace(/(.{4})/g,'$1 ').trim();
          fillInput(numEl, spaced) || fillInput(numEl, cardData.number.replace(/\D/g,''));
        }
        const expEl = queryAll('input[name="exp-date"]','input[data-elements-stable-field-name="cardExpiry"]','input[autocomplete*="cc-exp"]','input[placeholder*="MM" i]','input[class*="Expiry"]');
        if (expEl) {
          fillInput(expEl, `${cardData.mm}/${cardData.yy}`) || fillInput(expEl, `${cardData.mm}${cardData.yy}`);
        } else {
          const mmEl = queryAll('input[name="exp-month"]','input[placeholder="MM"]','input[data-elements-stable-field-name="cardExpiryMonth"]');
          const yyEl = queryAll('input[name="exp-year"]','input[placeholder="YY"]','input[data-elements-stable-field-name="cardExpiryYear"]');
          if (mmEl) fillInput(mmEl, cardData.mm);
          if (yyEl) fillInput(yyEl, cardData.yy);
        }
        const cvvEl = queryAll('input[name="cvc"]','input[data-elements-stable-field-name="cardCvc"]','input[autocomplete*="cc-csc"]','input[placeholder*="CVC" i]','input[placeholder*="CVV" i]','input[class*="Cvc"]');
        if (cvvEl) fillInput(cvvEl, cardData.cvv);
        if (cardData.zip) {
          const zipEl = queryAll('input[name="postal"]','input[data-elements-stable-field-name="postalCode"]','input[autocomplete*="postal-code"]','input[name*="zip"]');
          if (zipEl) fillInput(zipEl, cardData.zip);
        }
      },
      args: [card],
    }).catch(() => {});
    return false;
  }
});
