// ── FULL TAB REDIRECT ────────────────────────────────────────────────
if (!location.search.includes('full=1')) {
  chrome.tabs.create({ url: chrome.runtime.getURL('popup/popup.html?full=1') });
  window.close();
}

// ── CONSTANTS ────────────────────────────────────────────────────────
const API_BASE = 'https://project--1963f468-1829-477a-aa1d-f73ff1aa69de-dev.lovable.app';
const _0x364as9sht = 'Zypher_Strikebot';
const _0x776d61lfz = {
  ID:'🇮🇩 Indonesia',SG:'🇸🇬 Singapore',MY:'🇲🇾 Malaysia',TH:'🇹🇭 Thailand',
  VN:'🇻🇳 Vietnam',PH:'🇵🇭 Philippines',JP:'🇯🇵 Japan',KR:'🇰🇷 South Korea',
  CN:'🇨🇳 China',HK:'🇭🇰 Hong Kong',TW:'🇹🇼 Taiwan',IN:'🇮🇳 India',
  US:'🇺🇸 United States',GB:'🇬🇧 United Kingdom',DE:'🇩🇪 Germany',
  FR:'🇫🇷 France',NL:'🇳🇱 Netherlands',BR:'🇧🇷 Brazil',RU:'🇷🇺 Russia',
  TR:'🇹🇷 Turkey',AE:'🇦🇪 UAE',AU:'🇦🇺 Australia'
};

let user = null;
let proxies = [], activeProxy = null, addType = 'http';
let _0xb5acicxo4 = {}, checkingSet = new Set();
let _0xba06bzoio = null;
let _gateData = [];
let _bulkBinRows = [];

const store = {
  get: k => new Promise(r => chrome.storage.local.get(k, r)),
  set: o => new Promise(r => chrome.storage.local.set(o, r)),
  remove: k => new Promise(r => chrome.storage.local.remove(k, r)),
};

// ── TOAST ────────────────────────────────────────────────────────────
let toastT;
function toast(msg, type='') {
  const el = document.getElementById('toast');
  el.textContent = msg; el.className = 'toast show ' + type;
  clearTimeout(toastT);
  toastT = setTimeout(() => el.className = 'toast', 2800);
}

// ── SIDEBAR NAV ──────────────────────────────────────────────────────
const PRO_PANELS = ['bulkbin','gatehealth','gatetester','cardfilter'];

document.querySelectorAll('.nav-item').forEach(item => {
  item.addEventListener('click', () => {
    const panel = item.dataset.panel;
    if (!user && panel !== 'account') {
      toast('⛔ Login first to access this feature', 'err'); return;
    }
    if (PRO_PANELS.includes(panel) && user && user.plan !== 'pro') {
      toast('⭐ PRO feature — Upgrade now!', 'err');
      switchNav('account'); showView('viewPay'); closeSidebar(); return;
    }
    switchNav(panel);
    if (panel === 'tempmail') refreshTempMailUsageUI();
    closeSidebar();
  });
});

// ── QUICK ACTIONS ────────────────────────────────────────────────────
document.querySelectorAll('.qa-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    const panel = btn.dataset.panel;
    if (!user && panel !== 'account') {
      toast('⛔ Login first to access this feature', 'err'); return;
    }
    if (PRO_PANELS.includes(panel) && user && user.plan !== 'pro') {
      toast('⭐ PRO feature — Upgrade now!', 'err');
      switchNav('account'); showView('viewPay'); closeSidebar(); return;
    }
    switchNav(panel);
    if (panel === 'tempmail') refreshTempMailUsageUI();
    closeSidebar();
  });
});

function switchNav(panel) {
  document.querySelectorAll('.nav-item').forEach(x => x.classList.remove('active'));
  document.querySelectorAll('.panel').forEach(x => x.classList.remove('active'));
  const ni = document.querySelector(`.nav-item[data-panel="${panel}"]`);
  const pi = document.getElementById(`panel-${panel}`);
  if (ni) ni.classList.add('active');
  if (pi) pi.classList.add('active');
}

// ── SIDEBAR DRAWER ────────────────────────────────────────────────────
function openSidebar() {
  document.getElementById('sidebar').classList.add('open');
  document.getElementById('sbOverlay').classList.add('active');
}
function closeSidebar() {
  const sb = document.getElementById('sidebar');
  const ov = document.getElementById('sbOverlay');
  if (sb) sb.classList.remove('open');
  if (ov) ov.classList.remove('active');
}
document.getElementById('btnMenu').addEventListener('click', openSidebar);
document.getElementById('sbClose').addEventListener('click', closeSidebar);
document.getElementById('sbOverlay').addEventListener('click', closeSidebar);

// ── VIEWS ─────────────────────────────────────────────────────────────
function showView(v) {
  ['viewLogin','viewMain','viewPay'].forEach(id =>
    document.getElementById(id).style.display = id===v ? 'block' : 'none'
  );
}

// ── ACCOUNT RENDER ────────────────────────────────────────────────────
function renderAccount() {
  const topBar = document.getElementById('topBar');
  if (!user) {
    showView('viewLogin');
    document.getElementById('sbUserSection').style.display = 'none';
    document.getElementById('btnLogout').style.display = 'none';
    const lo0 = document.getElementById('btnLogoutNav'); if(lo0) lo0.style.display='none';
    if (topBar) topBar.style.display = 'none';
    closeSidebar();
    return;
  }
  if (topBar) topBar.style.display = 'flex';
  const lo1 = document.getElementById('btnLogoutNav'); if(lo1) lo1.style.display='flex';
  const isPro = user.plan === 'pro';
  document.getElementById('sbUserSection').style.display = 'flex';
  document.getElementById('sbUsername').textContent = '@' + (user.username || 'user');
  const badge = document.getElementById('sbPlanBadge');
  badge.textContent = isPro ? '⭐ PRO' : 'FREE';
  badge.className = 'plan-badge ' + (isPro ? 'pro' : 'free');
  document.getElementById('btnLogout').style.display = 'block';
  document.getElementById('statSuccess').textContent = user.total_success || 0;

  // Unlimited hits for both FREE and PRO
  document.getElementById('statHits').textContent = '∞';
  document.getElementById('statHits').style.color = isPro ? '#f59e0b' : '#38bdf8';

  // Spoof: PRO unlimited, FREE shows count/5 today
  const statSpoofEl = document.getElementById('statSpoof');
  if (isPro) {
    statSpoofEl.textContent = '∞';
    statSpoofEl.style.color = '#f59e0b';
  } else {
    chrome.storage.local.get(['spoofUsage'], d => {
      const u = d.spoofUsage || {};
      const today = new Date().toISOString().slice(0,10);
      const count = u.date === today ? (u.count||0) : 0;
      statSpoofEl.textContent = `${count}/${FREE_SPOOF_DAILY}`;
      statSpoofEl.style.color = count >= FREE_SPOOF_DAILY ? '#f87171' : '#38bdf8';
    });
  }

  // Only show upgrade banner for FREE users
  document.getElementById('upBanner').style.display = isPro ? 'none' : 'block';
  showView('viewMain');
}

// ── LOGIN ─────────────────────────────────────────────────────────────
document.getElementById('btnOpenTg').addEventListener('click', () => {
  chrome.tabs.create({ url: `https://t.me/${_0x364as9sht}?start=login_ext` });
});

document.getElementById('btnVerify').addEventListener('click', async () => {
  const otp = document.getElementById('otpInput').value.trim();
  if (otp.length !== 6) { toast('Enter a 6-digit OTP', 'err'); return; }
  const btn = document.getElementById('btnVerify');
  btn.textContent = '...'; btn.disabled = true;
  try {
    const r = await fetch(`${API_BASE}/api/public/verify-otp`, {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({otp})
    });
    const res = await r.json();
    if (res.ok) {
      user = res;
      await store.set({ zs_user:user, zs_token:res.session_token||'', zs_uid:String(res.user_id||'') });
      toast('✅ Login successful!', 'ok');
      renderAccount();
    } else { toast(res.error || 'Invalid OTP', 'err'); }
  } catch(e) { toast('Connection error', 'err'); }
  btn.textContent = 'Verify'; btn.disabled = false;
});

document.getElementById('otpInput').addEventListener('keydown', e => {
  if (e.key === 'Enter') document.getElementById('btnVerify').click();
});

document.getElementById('btnRefresh').addEventListener('click', async () => {
  if (!user) return;
  try {
    const r = await fetch(`${API_BASE}/api/public/get-user`, {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({user_id: user.user_id})
    });
    const res = await r.json();
    if (res.ok) {
      user = {...user,...res};
      await store.set({zs_user:user, zs_token:res.session_token||user.session_token||'', zs_uid:String(res.user_id||user.user_id||'')});
      renderAccount();
      toast('✅ Refreshed', 'ok');
    }
  } catch(e) { toast('Connection error', 'err'); }
});

function doLogout() {
  store.remove(['zs_user','zs_token','zs_uid']);
  user = null; renderAccount();
  toast('Logged out', 'ok');
}
document.getElementById('btnLogout').addEventListener('click', doLogout);
document.getElementById('btnLogoutMobile').addEventListener('click', doLogout);
document.getElementById('btnLogoutNav').addEventListener('click', doLogout);

document.getElementById('btnUpgrade').addEventListener('click', () => showView('viewPay'));
document.getElementById('btnBackPay').addEventListener('click', () => showView('viewMain'));

document.querySelectorAll('.pay-copy').forEach(btn => {
  btn.addEventListener('click', () => {
    navigator.clipboard.writeText(btn.dataset.addr).then(() => {
      btn.textContent = '✅ Copied!';
      setTimeout(() => btn.textContent = '📋 Copy', 2000);
    });
  });
});

document.getElementById('btnSubmitTx').addEventListener('click', async () => {
  const tx = document.getElementById('txInput').value.trim();
  if (!tx || tx.length < 20) { toast('Enter a valid TX hash', 'err'); return; }
  if (!user) { toast('Login first', 'err'); return; }
  const btn = document.getElementById('btnSubmitTx');
  btn.disabled = true; btn.textContent = '⏳ Submitting...';
  try {
    const hdrs = await getAuthHeaders();
    const r = await fetch(`${API_BASE}/api/public/submit-tx`, {
      method:'POST', headers: hdrs,
      body: JSON.stringify({user_id: user.user_id, tx_hash: tx})
    });
    const res = await r.json();
    if (res && res.ok) {
      toast('✅ Submitted! Admin notified on Telegram.', 'ok');
      document.getElementById('txInput').value = '';
      setTimeout(() => showView('viewMain'), 2200);
    } else {
      toast('❌ ' + (res?.error || 'Submission failed. Re-login & retry.'), 'err');
    }
  } catch(e) { toast('Network error. Try again.', 'err'); }
  btn.disabled = false; btn.textContent = '✅ Submit Payment';
});

// ── PROXY ─────────────────────────────────────────────────────────────
function renderProxies() {
  const list = document.getElementById('proxyList');
  if (!proxies.length) {
    list.innerHTML = '<div style="text-align:center;color:#475569;font-size:11px;padding:16px">No proxies saved</div>';
    return;
  }
  list.innerHTML = proxies.map((p,i) => {
    const key = p.host+':'+p.port;
    const cr = _0xb5acicxo4[key];
    const isActive = activeProxy && activeProxy.host===p.host && activeProxy.port===p.port;
    let latHtml = '';
    if (cr) {
      latHtml = cr.ok
        ? `<span class="latency ok">${cr.ms}ms</span>${cr.exitIP ? ` <span class="latency ok" style="font-size:9px">${cr.emoji} ${cr.country}</span>` : ''}`
        : `<span class="latency fail">✗ Dead</span>`;
    }
    return `<div class="proxy-item">
      <div class="proxy-info">
        <span class="proxy-badge ${p.type}">${p.type.toUpperCase()}</span>
        ${p.host}:${p.port}${p.user?' 🔐':''} ${latHtml}
      </div>
      <div class="proxy-acts">
        <button class="px-btn check" data-action="check" data-id="${i}">⚡</button>
        <button class="px-btn conn ${isActive?'active':''}" data-action="connect" data-id="${i}">${isActive?'ON':'Use'}</button>
        <button class="px-btn rm" data-action="remove" data-id="${i}">✕</button>
      </div>
    </div>`;
  }).join('');
}

function updateProxyStatus() {
  const dot = document.getElementById('proxyDot');
  const status = document.getElementById('proxyStatus');
  if (activeProxy) {
    dot.className = 'dot on';
    status.textContent = `${activeProxy.type.toUpperCase()} ${activeProxy.host}:${activeProxy.port}`;
    status.style.color = '#86efac';
  } else {
    dot.className = 'dot off';
    status.textContent = 'No proxy';
    status.style.color = '#94a3b8';
  }
}

document.querySelectorAll('.tbtn').forEach(b => {
  b.addEventListener('click', () => {
    document.querySelectorAll('.tbtn').forEach(x => x.classList.remove('active'));
    b.classList.add('active'); addType = b.dataset.type;
  });
});

document.getElementById('btnAdd').addEventListener('click', async () => {
  if (!user) { toast('⛔ Login first', 'err'); return; }
  const host = document.getElementById('inpHost').value.trim();
  const port = document.getElementById('inpPort').value.trim();
  const u2 = document.getElementById('inpUser').value.trim();
  const pass = document.getElementById('inpPass').value.trim();
  if (!host || !port) { toast('Host and port are required', 'err'); return; }
  proxies.push({type:addType, host, port:parseInt(port), user:u2, pass});
  chrome.storage.local.set({proxies});
  renderProxies();
  ['inpHost','inpPort','inpUser','inpPass'].forEach(id => document.getElementById(id).value = '');
  toast('✅ Proxy added', 'ok');
});

document.getElementById('btnImport').addEventListener('click', () => {
  if (!user) { toast('⛔ Login first', 'err'); return; }
  const lines = document.getElementById('bulkTa').value.trim().split('\n');
  let added = 0;
  lines.forEach(line => {
    line = line.trim(); if (!line) return;
    let type = 'http', host, port, usr='', pass='';
    if (line.startsWith('socks5://')) { type='socks5'; line=line.slice(9); }
    else if (line.startsWith('socks4://')) { type='socks4'; line=line.slice(9); }
    else if (line.startsWith('http://')) { line=line.slice(7); }
    const parts = line.split(':');
    if (parts.length >= 2) {
      host=parts[0]; port=parseInt(parts[1]);
      if (parts[2]) usr=parts[2]; if (parts[3]) pass=parts[3];
      proxies.push({type,host,port,user:usr,pass}); added++;
    }
  });
  chrome.storage.local.set({proxies});
  renderProxies();
  document.getElementById('bulkTa').value = '';
  toast(`✅ ${added} proxies imported`, 'ok');
});

document.getElementById('btnCut').addEventListener('click', () => {
  chrome.runtime.sendMessage({action:'clearProxy'});
  activeProxy = null; chrome.storage.local.set({activeProxy:null});
  updateProxyStatus(); renderProxies(); toast('Proxy disconnected');
});

document.getElementById('btnClearAll').addEventListener('click', () => {
  proxies = []; chrome.storage.local.set({proxies}); renderProxies(); toast('Cleared');
});

document.getElementById('btnCheckAll').addEventListener('click', () => {
  proxies.forEach((_,i) => checkOne(i));
});

document.getElementById('proxyList').addEventListener('click', e => {
  const btn = e.target.closest('[data-action]'); if (!btn) return;
  const id = Number(btn.dataset.id);
  if (btn.dataset.action === 'check') checkOne(id);
  else if (btn.dataset.action === 'connect') connectProxy(id);
  else if (btn.dataset.action === 'remove') {
    proxies.splice(id,1); chrome.storage.local.set({proxies}); renderProxies();
  }
});

function connectProxy(i) {
  const p = proxies[i];
  chrome.runtime.sendMessage({action:'setProxy', proxy:p}, () => {
    activeProxy = p; chrome.storage.local.set({activeProxy:p});
    updateProxyStatus(); renderProxies();
    toast(`✅ Connected: ${p.host}:${p.port}`, 'ok');
  });
}

async function checkOne(i) {
  const p = proxies[i];
  const key = p.host+':'+p.port;
  checkingSet.add(key);
  toast('⏳ Checking...', '');
  const res = await new Promise(r => chrome.runtime.sendMessage({action:'checkProxy',proxy:p}, r));
  checkingSet.delete(key);
  if (res && res.success) {
    try {
      const r = await fetch('http://ip-api.com/json/?fields=query,countryCode,proxy,hosting,isp');
      const d = await r.json();
      const exitIP = d.query||p.host, country = d.countryCode||'?';
      const isProxy = d.proxy||d.hosting;
      _0xb5acicxo4[key] = {ok:true,ms:res.latency,exitIP,country,emoji:isProxy?'🔴':'🟢'};
      toast(`${isProxy?'🔴':'🟢'} ${exitIP} | ${country} | ${res.latency}ms`, 'ok');
    } catch(e) {
      _0xb5acicxo4[key] = {ok:true,ms:res.latency};
      toast(`✅ ${res.latency}ms`, 'ok');
    }
  } else {
    _0xb5acicxo4[key] = {ok:false};
    toast('❌ Proxy dead', 'err');
  }
  renderProxies();
}

document.getElementById('btnMyIP').addEventListener('click', async () => {
  const el = document.getElementById('myIPResult');
  el.textContent = '⏳ Checking...';
  try {
    const r = await fetch('http://ip-api.com/json/?fields=query,country,countryCode,proxy,hosting,isp,org');
    const d = await r.json();
    const ip = d.query||'?', country = d.countryCode||'?', isp = d.isp||d.org||'';
    const isProxy = d.proxy||d.hosting;
    el.innerHTML = `${isProxy?'🔴':'🟢'} <b>${ip}</b> | ${country} | ${isProxy?'⚠️ Proxy/VPN':'✅ Clean'}<br><span style="font-size:9px;opacity:0.6">${isp}</span>`;
    el.style.color = isProxy ? '#f87171' : '#86efac';
  } catch(e) { el.textContent = '❌ Failed'; }
});

// ── SPOOF ──────────────────────────────────────────────────────────────
const FREE_SPOOF_DAILY = 5;
const FREE_TEMPMAIL_DAILY = 5;

function _todayKey(){ return new Date().toISOString().slice(0,10); }

function getTempMailUsage(){
 return new Promise(r => chrome.storage.local.get(['tempMailUsage'], d => {
  const u = d.tempMailUsage || {};
  if (u.date !== _todayKey()) r({date:_todayKey(), count:0});
  else r({date:u.date, count:u.count||0});
 }));
}
async function bumpTempMailUsage(){
 const cur = await getTempMailUsage();
 const next = {date:cur.date, count:cur.count+1};
 return new Promise(r => chrome.storage.local.set({tempMailUsage: next}, () => r(next)));
}
async function refreshTempMailUsageUI(){
 const el = document.getElementById('tmUsageText');
 if (!el) return;
 const isPro = user && user.plan === 'pro';
 if (isPro) {
  el.textContent = '∞ (PRO)';
  el.style.color = '#f59e0b';
 } else {
  const u = await getTempMailUsage();
  el.textContent = `${u.count} / ${FREE_TEMPMAIL_DAILY}`;
  el.style.color = u.count >= FREE_TEMPMAIL_DAILY ? '#f87171' : '#38bdf8';
 }
}
let _spoofCountries = []; // populated from background
let _selectedOS = 'windows';

function populateCountries() {
  const sel = document.getElementById('countrySelect');
  sel.innerHTML = '';
  chrome.runtime.sendMessage({action:'listCountries'}, list => {
    _spoofCountries = (list && list.length) ? list : Object.entries(_0x776d61lfz).map(([code,name])=>({code,name,flag:''}));
    // Sort alphabetically by name for easy scanning
    _spoofCountries.sort((a,b) => a.name.localeCompare(b.name));
    _spoofCountries.forEach(c => {
      const opt = document.createElement('option');
      opt.value = c.code;
      opt.textContent = `${c.flag||''} ${c.name}`.trim();
      sel.appendChild(opt);
    });
  });
}

function todayStr() { return new Date().toISOString().slice(0,10); }

async function getSpoofUsage() {
  return new Promise(r => chrome.storage.local.get(['spoofUsage'], d => {
    const u = d.spoofUsage || {};
    if (u.date !== todayStr()) r({date: todayStr(), count: 0});
    else r(u);
  }));
}
async function bumpSpoofUsage() {
  const u = await getSpoofUsage();
  const next = {date: todayStr(), count: (u.count||0) + 1};
  return new Promise(r => chrome.storage.local.set({spoofUsage: next}, () => r(next)));
}
async function refreshSpoofUsageUI() {
  const u = await getSpoofUsage();
  const isPro = user && user.plan === 'pro';
  const el = document.getElementById('spoofUsageText');
  if (!el) return;
  if (isPro) {
    el.textContent = '∞ Unlimited (PRO)';
    el.style.color = '#f59e0b';
  } else {
    el.textContent = `${u.count} / ${FREE_SPOOF_DAILY}`;
    el.style.color = u.count >= FREE_SPOOF_DAILY ? '#f87171' : '#38bdf8';
  }
}

function updateFPUI() {
  const info = document.getElementById('fpInfo');
  if (_0xba06bzoio && _0xba06bzoio.active) {
    const osIcon = _0xba06bzoio.os === 'android' ? '🤖' : _0xba06bzoio.os === 'iphone' ? '📱' : '🖥️';
    info.textContent = `🎭 ${osIcon} ${_0xba06bzoio.countryName}`;
    info.style.color = '#c4b5fd';
  } else {
    info.textContent = 'No spoofing active';
    info.style.color = '#64748b';
  }
  refreshSpoofUsageUI();
}

// OS picker
document.querySelectorAll('.os-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.os-btn').forEach(b => {
      b.classList.remove('active');
      b.style.background = '#0f172a';
      b.style.color = '#94a3b8';
    });
    btn.classList.add('active');
    btn.style.background = 'rgba(56,189,248,.1)';
    btn.style.color = '#38bdf8';
    _selectedOS = btn.dataset.os;
  });
});

document.getElementById('btnDetect').addEventListener('click', () => {
  toast('Detecting...');
  chrome.runtime.sendMessage({action:'detectCountry'}, res => {
    if (res && res.code) {
      const sel = document.getElementById('countrySelect');
      // Only set if option exists in our list
      if ([...sel.options].some(o => o.value === res.code)) {
        sel.value = res.code;
        toast(`📍 Detected: ${res.name}`, 'ok');
      } else {
        toast(`Detected ${res.code} but not in list — using US`, 'err');
      }
    } else { toast('Detection failed', 'err'); }
  });
});

async function applySpoofWithLimit(code, label) {
  if (!user) { toast('⛔ Login first', 'err'); return false; }
  const isPro = user.plan === 'pro';
  if (!isPro) {
    const u = await getSpoofUsage();
    if (u.count >= FREE_SPOOF_DAILY) {
      toast(`⛔ FREE limit: ${FREE_SPOOF_DAILY}/day reached. Upgrade to PRO for unlimited.`, 'err');
      return false;
    }
  }
  return new Promise(resolve => {
    chrome.runtime.sendMessage({action:'buildFP', countryCode: code, os: _selectedOS}, fp => {
      if (!fp) { toast('Failed to build fingerprint', 'err'); resolve(false); return; }
      chrome.runtime.sendMessage({action:'setFingerprint', fingerprint: fp}, async () => {
        _0xba06bzoio = fp;
        if (!isPro) await bumpSpoofUsage();
        updateFPUI();
        const osLabel = _selectedOS === 'android' ? '🤖 Android' : _selectedOS === 'iphone' ? '📱 iPhone' : '🖥️ Windows';
        toast(`${label} ${osLabel} · ${fp.countryName}`, 'ok');
        resolve(true);
      });
    });
  });
}

document.getElementById('btnApplyFp').addEventListener('click', async () => {
  const code = document.getElementById('countrySelect').value;
  await applySpoofWithLimit(code, '✅ Spoofing as');
});

document.getElementById('btnRandFp').addEventListener('click', async () => {
  if (!_spoofCountries.length) { toast('Country list still loading…', 'err'); return; }
  const c = _spoofCountries[Math.floor(Math.random()*_spoofCountries.length)];
  document.getElementById('countrySelect').value = c.code;
  await applySpoofWithLimit(c.code, '🎲 Random');
});

document.getElementById('btnClearFp').addEventListener('click', () => {
  chrome.runtime.sendMessage({action:'clearFingerprint'}, () => {
    _0xba06bzoio = null; updateFPUI(); toast('Fingerprint cleared');
  });
});
document.getElementById('btnFpCut').addEventListener('click', () => document.getElementById('btnClearFp').click());

// ── BIN LOOKUP ──────────────────────────────────────────────────────────
function binBrandClass(scheme) {
  const s = (scheme||'').toLowerCase();
  if (s === 'visa') return 'visa';
  if (s === 'mastercard') return 'mastercard';
  if (s === 'amex' || s === 'american express') return 'amex';
  if (s === 'discover') return 'discover';
  return 'other';
}

// Cache to avoid repeated lookups
const _binCache = {};

// Multi-API BIN lookup with fallback chain
async function lookupBinMulti(rawBin) {
  const full = rawBin.replace(/\D/g,'').slice(0, 10);
  if (full.length < 6) throw new Error('Need at least 6 digits');
  if (_binCache[full]) return _binCache[full];

  // Try the full input (6-10 digits) first; APIs handle prefix matching
  const tryLengths = full.length > 6 ? [full, full.slice(0, 6)] : [full];

  for (const bin of tryLengths) {
    const result = await _tryBinSources(bin);
    if (result) { _binCache[full] = result; return result; }
  }
  throw new Error('BIN not found in any database');
}

async function _tryBinSources(bin) {
  const sources = [
    // 1) bins.antipublic.cc — best free, no rate limit
    async () => {
      const r = await fetch(`https://bins.antipublic.cc/bins/${bin}`);
      if (!r.ok) throw new Error('antipublic fail');
      const d = await r.json();
      if (!d.brand && !d.bank) throw new Error('empty');
      return {
        bin, scheme: d.brand || 'Unknown',
        bank: d.bank || 'Unknown',
        country_name: d.country_name || '',
        country_flag: d.country_flag || '',
        country_code: d.country || '',
        type: d.type || '—',
        level: d.level || '—',
        phone: '—', source: 'antipublic'
      };
    },
    // 2) data.handyapi.com — strong fallback
    async () => {
      const r = await fetch(`https://data.handyapi.com/bin/${bin}`);
      if (!r.ok) throw new Error('handyapi fail');
      const d = await r.json();
      if (d.Status !== 'SUCCESS' || !d.Scheme) throw new Error('empty');
      return {
        bin, scheme: d.Scheme,
        bank: d.Issuer || 'Unknown',
        country_name: d.Country?.Name || '',
        country_flag: '', country_code: d.Country?.A2 || '',
        type: d.Type || '—',
        level: d.CardTier || '—',
        phone: '—', source: 'handyapi'
      };
    },
    // 3) binlist.net — last resort
    async () => {
      const r = await fetch(`https://lookup.binlist.net/${bin}`, {
        headers: { 'Accept-Version': '3' }
      });
      if (!r.ok) throw new Error('binlist fail');
      const d = await r.json();
      if (!d.scheme && !d.bank) throw new Error('empty');
      return {
        bin, scheme: d.scheme || d.brand || 'Unknown',
        bank: d.bank?.name || 'Unknown',
        country_name: d.country?.name || '',
        country_flag: d.country?.emoji || '',
        country_code: d.country?.alpha2 || '',
        type: d.type || '—',
        level: d.brand || '—',
        phone: d.bank?.phone || '—', source: 'binlist'
      };
    }
  ];

  for (const fn of sources) {
    try { return await fn(); } catch(e) { /* try next source */ }
  }
  return null;
}

let _lastBinResult = null;

document.getElementById('btnBinLookup').addEventListener('click', async () => {
  if (!user) { toast('⛔ Login first', 'err'); return; }
  const raw = document.getElementById('binLookupInput').value.trim().replace(/\D/g,'');
  if (raw.length < 6) { toast('Enter at least 6 digits', 'err'); return; }
  const btn = document.getElementById('btnBinLookup');
  btn.textContent = '⏳'; btn.disabled = true;
  try {
    const d = await lookupBinMulti(raw);
    _lastBinResult = d;
    const bc = binBrandClass(d.scheme);
    document.getElementById('blBrand').textContent = (d.scheme||'?').toUpperCase();
    document.getElementById('blBrand').className = `bin-brand-badge ${bc}`;
    document.getElementById('blBinNum').textContent = d.bin;
    document.getElementById('blBank').textContent = d.bank;
    document.getElementById('blCountry').textContent = (d.country_flag || d.country_code) ? `${d.country_flag} ${d.country_name || d.country_code}`.trim() : '—';
    document.getElementById('blType').textContent = d.type ? String(d.type).charAt(0).toUpperCase()+String(d.type).slice(1).toLowerCase() : '—';
    document.getElementById('blLevel').textContent = d.level || '—';
    document.getElementById('blPrepaid').textContent = `Source: ${d.source}`;
    document.getElementById('blPhone').textContent = d.phone || '—';
    document.getElementById('binLookupResult').style.display = 'block';
    toast(`✅ BIN found (${d.source})`, 'ok');
  } catch(e) {
    toast('❌ BIN not found in any database', 'err');
  }
  btn.textContent = 'Lookup'; btn.disabled = false;
});

document.getElementById('binLookupInput').addEventListener('keydown', e => {
  if (e.key === 'Enter') document.getElementById('btnBinLookup').click();
});

// Copy/Download for BIN Lookup result
document.getElementById('btnCopyBinLookup')?.addEventListener('click', () => {
  if (!_lastBinResult) { toast('No data to copy', 'err'); return; }
  const d = _lastBinResult;
  const txt = `BIN: ${d.bin}\nBrand: ${d.scheme}\nBank: ${d.bank}\nCountry: ${d.country_flag} ${d.country_name} (${d.country_code})\nType: ${d.type}\nLevel: ${d.level}\nPhone: ${d.phone}`;
  navigator.clipboard.writeText(txt).then(() => toast('✅ Copied!', 'ok'));
});

// ── IP FRAUD SCORE ───────────────────────────────────────────────────────
function getRiskColor(score) {
  if (score < 30) return '#22c55e';
  if (score < 60) return '#f59e0b';
  return '#ef4444';
}

function getRiskLabel(score, isProxy, isHosting, isTor) {
  if (isTor) return { text:'🔴 TOR EXIT — Block Recommended', color:'#ef4444' };
  if (score < 20 && !isProxy && !isHosting) return { text:'✅ Clean — Low Risk', color:'#22c55e' };
  if (score < 50) return { text:'⚠️ Medium Risk', color:'#f59e0b' };
  return { text:'🔴 High Risk — Suspicious', color:'#ef4444' };
}

document.getElementById('btnDetectIP').addEventListener('click', async () => {
  const btn = document.getElementById('btnDetectIP');
  btn.textContent = '...'; btn.disabled = true;
  try {
    const r = await fetch('http://ip-api.com/json/?fields=query');
    const d = await r.json();
    document.getElementById('ipFraudInput').value = d.query || '';
  } catch(e) { toast('Failed to detect IP', 'err'); }
  btn.textContent = '🌐 My IP'; btn.disabled = false;
});

let _lastIpResult = null;

document.getElementById('btnCheckIP').addEventListener('click', async () => {
  if (!user) { toast('⛔ Login first', 'err'); return; }
  const ip = document.getElementById('ipFraudInput').value.trim();
  if (!ip) { toast('Enter an IP address', 'err'); return; }
  const btn = document.getElementById('btnCheckIP');
  btn.textContent = '...'; btn.disabled = true;
  toast('⏳ Checking IP...', '');
  try {
    // Source 1: ip-api (geo + ISP + proxy/hosting flags)
    const r1 = await fetch(`http://ip-api.com/json/${ip}?fields=status,message,country,countryCode,regionName,city,isp,org,as,proxy,hosting,query`);
    const d = await r1.json();
    if (d.status === 'fail') { toast('Invalid IP: ' + (d.message||'?'), 'err'); btn.textContent = 'Check'; btn.disabled = false; return; }

    // Source 2: proxycheck.io (Tor + abuse risk score 0-100)
    let isTor = false, pcType = '', abuseRisk = -1;
    try {
      const r2 = await fetch(`https://proxycheck.io/v2/${ip}?vpn=1&risk=1`);
      const d2 = await r2.json();
      const ipd = d2[ip] || d2[d.query];
      if (ipd) {
        pcType = ipd.type || '';
        isTor = pcType.toUpperCase() === 'TOR';
        if (typeof ipd.risk !== 'undefined') abuseRisk = parseInt(ipd.risk);
      }
    } catch(e) { /* proxycheck optional */ }

    const isProxy = d.proxy || false;
    const isHosting = d.hosting || false;
    const isVPN = pcType === 'VPN';

    // Combined score: prefer proxycheck risk if available, else heuristic
    let score;
    if (abuseRisk >= 0) {
      score = abuseRisk;
      if (isTor) score = Math.max(score, 95);
    } else {
      score = 0;
      if (isProxy) score += 45;
      if (isHosting) score += 35;
      if (isTor) score = 99;
      if (d.isp && /amazon|google|microsoft|digitalocean|vultr|linode|ovh|hetzner/i.test(d.isp)) score += 20;
    }
    score = Math.min(Math.max(score, 0), 99);

    const color = getRiskColor(score);
    const lbl = getRiskLabel(score, isProxy || isVPN, isHosting, isTor);

    const scoreEl = document.getElementById('ipRiskScore');
    scoreEl.textContent = score;
    scoreEl.style.color = color;

    const lblEl = document.getElementById('ipRiskLabel');
    lblEl.textContent = lbl.text;
    lblEl.style.color = lbl.color;

    document.getElementById('ipGaugeThumb').style.left = score + '%';

    // Flags: VPN/Proxy, Tor, Datacenter, Abuse
    const flagsEl = document.getElementById('ipRiskFlags');
    const flags = [];
    flags.push({ label: (isProxy || isVPN) ? '🔴 VPN/Proxy' : '✅ No VPN/Proxy', bad: isProxy || isVPN });
    flags.push({ label: isTor ? '🔴 TOR Exit Node' : '✅ Not Tor', bad: isTor });
    flags.push({ label: isHosting ? '🔴 Datacenter/Hosting' : '✅ Residential', bad: isHosting });
    if (abuseRisk >= 0) {
      flags.push({ label: abuseRisk >= 67 ? `🔴 Abuse: ${abuseRisk}/100` : abuseRisk >= 34 ? `🟡 Abuse: ${abuseRisk}/100` : `✅ Abuse: ${abuseRisk}/100`, bad: abuseRisk >= 34 });
    }
    flagsEl.innerHTML = flags.map(f =>
      `<span class="risk-flag ${f.bad?'bad':'good'}">${f.label}</span>`
    ).join('');

    document.getElementById('ipAddr').textContent = d.query || ip;
    document.getElementById('ipCountry').textContent = d.country ? `${d.countryCode} — ${d.country}` : '—';
    document.getElementById('ipISP').textContent = d.isp || '—';
    document.getElementById('ipOrg').textContent = d.org || d.as || '—';

    _lastIpResult = { ip:d.query||ip, country:d.country, countryCode:d.countryCode, isp:d.isp, org:d.org||d.as, score, isProxy:isProxy||isVPN, isHosting, isTor, abuseRisk, pcType, label:lbl.text };
    document.getElementById('ipFraudResult').style.display = 'block';
    toast(`Score: ${score}/99 — ${isTor?'🔴 TOR':isProxy||isVPN?'⚠️ Proxy':'✅ Clean'}`, score > 40 ? 'err' : 'ok');
  } catch(e) { toast('IP check failed', 'err'); }
  btn.textContent = 'Check'; btn.disabled = false;
});

document.getElementById('ipFraudInput').addEventListener('keydown', e => {
  if (e.key === 'Enter') document.getElementById('btnCheckIP').click();
});

document.getElementById('btnCopyIPFraud')?.addEventListener('click', () => {
  if (!_lastIpResult) { toast('No data to copy', 'err'); return; }
  const r = _lastIpResult;
  const txt = `IP Fraud Report\n────────────────\nIP: ${r.ip}\nRisk Score: ${r.score}/99\nStatus: ${r.label}\nCountry: ${r.countryCode} — ${r.country}\nISP: ${r.isp}\nOrg: ${r.org}\nVPN/Proxy: ${r.isProxy?'YES':'NO'}\nTOR Exit: ${r.isTor?'YES':'NO'}\nDatacenter/Hosting: ${r.isHosting?'YES':'NO'}\nAbuse Score: ${r.abuseRisk>=0?r.abuseRisk+'/100':'N/A'}\nDetected Type: ${r.pcType||'-'}`;
  navigator.clipboard.writeText(txt).then(() => toast('✅ Report copied!', 'ok'));
});

// ── BIN GENERATOR ──────────────────────────────────────────────────────
function luhnCheck(num) {
  let sum = 0, odd = true;
  for (let i = num.length - 1; i >= 0; i--) {
    let d = parseInt(num[i]);
    if (odd) { d *= 2; if (d > 9) d -= 9; }
    sum += d; odd = !odd;
  }
  return sum % 10 === 0;
}

function luhnComplete(partial) {
  for (let d = 0; d <= 9; d++) {
    const full = partial + d;
    if (luhnCheck(full)) return full;
  }
  return null;
}

function detectCardType(prefix) {
  const p = prefix.replace(/\D/g,'');
  if (p.startsWith('34') || p.startsWith('37')) return { type:'AMEX', len:15, cvvLen:4 };
  if (p.startsWith('4')) return { type:'VISA', len:16, cvvLen:3 };
  if (p.startsWith('5')) return { type:'Mastercard', len:16, cvvLen:3 };
  if (p.startsWith('6')) return { type:'Discover', len:16, cvvLen:3 };
  if (p.startsWith('3')) return { type:'AMEX', len:15, cvvLen:4 };
  return { type:'VISA', len:16, cvvLen:3 };
}

function rnd(min, max) { return Math.floor(Math.random() * (max - min + 1)) + min; }

function generateOneCard(prefix, cardLen, cvvLen, expM, expY) {
  const fill = cardLen - prefix.length - 1;
  let partial = prefix;
  for (let i = 0; i < fill; i++) partial += Math.floor(Math.random() * 10);
  const num = luhnComplete(partial);
  if (!num) return null;
  const mm = expM === 'rand' ? String(rnd(1,12)).padStart(2,'0') : expM;
  const yy = expY === 'rand' ? String(rnd(new Date().getFullYear()+1, new Date().getFullYear()+5)).slice(-2) : expY;
  const cvv = Array.from({length:cvvLen}, () => Math.floor(Math.random()*10)).join('');
  return `${num}|${mm}/${yy}|${cvv}`;
}

(function() {
  const selM = document.getElementById('binExpM');
  const selY = document.getElementById('binExpY');
  for (let m = 1; m <= 12; m++) {
    const o = document.createElement('option');
    o.value = String(m).padStart(2,'0');
    o.textContent = String(m).padStart(2,'0');
    selM.appendChild(o);
  }
  const yr = new Date().getFullYear();
  for (let y = yr+1; y <= yr+6; y++) {
    const o = document.createElement('option');
    o.value = String(y).slice(-2);
    o.textContent = y;
    selY.appendChild(o);
  }
})();

document.getElementById('btnGenerate').addEventListener('click', () => {
  if (!user) { toast('⛔ Login first', 'err'); return; }
  if (user.plan !== 'pro') { toast('⭐ PRO feature — Upgrade now!', 'err'); switchNav('account'); showView('viewPay'); return; }
  const prefix = document.getElementById('binPrefix').value.trim().replace(/\D/g,'');
  const qty = Math.min(parseInt(document.getElementById('binQty').value)||50, 500);
  const expM = document.getElementById('binExpM').value;
  const expY = document.getElementById('binExpY').value;
  const cvvType = document.getElementById('binCvvType').value;
  if (prefix.length < 6) { toast('BIN prefix must be at least 6 digits', 'err'); return; }
  const card = detectCardType(prefix);
  let cvvLen = card.cvvLen;
  if (cvvType === 'rand3') cvvLen = 3;
  else if (cvvType === 'rand4') cvvLen = 4;
  const cards = []; const seen = new Set(); let attempts = 0;
  while (cards.length < qty && attempts < qty * 10) {
    attempts++;
    const c = generateOneCard(prefix, card.len, cvvLen, expM, expY);
    if (c && !seen.has(c.split('|')[0])) { seen.add(c.split('|')[0]); cards.push(c); }
  }
  document.getElementById('binGenCount').textContent = cards.length;
  document.getElementById('binGenBin').textContent = prefix;
  document.getElementById('binGenType').textContent = card.type;
  document.getElementById('binGenLen').textContent = card.len + ' digits';
  document.getElementById('binOutput').value = cards.join('\n');
  document.getElementById('binResultArea').style.display = 'block';
  toast(`✅ ${cards.length} cards generated`, 'ok');
});

document.getElementById('btnCopyBin').addEventListener('click', () => {
  const txt = document.getElementById('binOutput').value;
  if (!txt) { toast('No output', 'err'); return; }
  navigator.clipboard.writeText(txt).then(() => toast('✅ Copied!', 'ok'));
});
document.getElementById('btnDlBin').addEventListener('click', () => {
  const txt = document.getElementById('binOutput').value;
  if (!txt) { toast('No output', 'err'); return; }
  dlText(txt, `zs_bin_${document.getElementById('binPrefix').value.trim()||'cards'}.txt`);
  toast('💾 Downloaded!', 'ok');
});
document.getElementById('btnClearBin').addEventListener('click', () => {
  document.getElementById('binOutput').value = '';
  document.getElementById('binResultArea').style.display = 'none';
  document.getElementById('binPrefix').value = '';
});

// ── BULK BIN LOOKUP ──────────────────────────────────────────────────────
document.getElementById('btnBulkLookup').addEventListener('click', async () => {
  if (!user) { toast('⛔ Login first', 'err'); return; }
  if (user.plan !== 'pro') { toast('⭐ PRO feature — Upgrade now!', 'err'); switchNav('account'); showView('viewPay'); return; }
  const lines = document.getElementById('bulkBinInput').value.trim().split('\n')
    .map(l => l.trim().replace(/\D/g,'')).filter(l => l.length >= 6).slice(0, 50);
  if (!lines.length) { toast('Enter at least one BIN (6+ digits)', 'err'); return; }
  const btn = document.getElementById('btnBulkLookup');
  btn.textContent = '⏳ Looking up...'; btn.disabled = true;
  toast(`⏳ Looking up ${lines.length} BINs...`, '');
  _bulkBinRows = [];
  const tbody = document.getElementById('bulkBinTbody');
  tbody.innerHTML = '';
  document.getElementById('bulkBinResult').style.display = 'block';
  document.getElementById('bulkBinCount').textContent = lines.length;

  let okCount = 0;
  for (let i = 0; i < lines.length; i++) {
    const bin = lines[i];
    try {
      // Small delay to avoid hammering APIs
      if (i > 0) await new Promise(r => setTimeout(r, 250));
      const d = await lookupBinMulti(bin);
      const row = {
        bin: d.bin,
        brand: d.scheme,
        bank: d.bank,
        country: (d.country_flag || d.country_code) ? `${d.country_flag} ${d.country_code}`.trim() : '—',
        type: d.type,
        level: d.level,
        ok: true
      };
      _bulkBinRows.push(row);
      okCount++;
      // Safe DOM construction (no innerHTML for untrusted API data — prevents XSS)
      const tr = document.createElement('tr');
      const tdBin = document.createElement('td'); tdBin.textContent = bin;
      const tdBrand = document.createElement('td');
      const brandSpan = document.createElement('span');
      brandSpan.className = `bin-brand-badge ${binBrandClass(row.brand)}`;
      brandSpan.style.cssText = 'padding:2px 8px;font-size:10px';
      brandSpan.textContent = (row.brand||'?').toString().toUpperCase();
      tdBrand.appendChild(brandSpan);
      const tdBank = document.createElement('td'); tdBank.style.color='#94a3b8'; tdBank.textContent = row.bank;
      const tdCountry = document.createElement('td'); tdCountry.textContent = row.country;
      const tdType = document.createElement('td'); tdType.style.textTransform='capitalize'; tdType.textContent = row.type;
      const tdLevel = document.createElement('td'); tdLevel.style.color='var(--muted)'; tdLevel.textContent = row.level;
      tr.append(tdBin, tdBrand, tdBank, tdCountry, tdType, tdLevel);
      tbody.appendChild(tr);
    } catch(e) {
      _bulkBinRows.push({bin, brand:'—', bank:'Not found', country:'—', type:'—', level:'—', ok:false});
      const tr = document.createElement('tr');
      const cells = [bin, '—', 'Not found', '—', '—', '—'];
      cells.forEach((val, idx) => {
        const td = document.createElement('td');
        td.textContent = val;
        if (idx === 2) td.style.color = 'var(--red)';
        tr.appendChild(td);
      });
      tbody.appendChild(tr);
    }
    document.getElementById('bulkBinCount').textContent = `${okCount}/${lines.length}`;
  }
  toast(`✅ ${okCount}/${lines.length} BINs found`, 'ok');
  btn.textContent = '🔍 Lookup All'; btn.disabled = false;
});

document.getElementById('btnClearBulkBin').addEventListener('click', () => {
  document.getElementById('bulkBinInput').value = '';
  document.getElementById('bulkBinResult').style.display = 'none';
  _bulkBinRows = [];
});

document.getElementById('btnCopyBulkBin').addEventListener('click', () => {
  if (!_bulkBinRows.length) { toast('No data to copy', 'err'); return; }
  const txt = 'BIN\tBrand\tBank\tCountry\tType\tLevel\n' +
    _bulkBinRows.map(r => `${r.bin}\t${r.brand}\t${r.bank}\t${r.country}\t${r.type}\t${r.level}`).join('\n');
  navigator.clipboard.writeText(txt).then(() => toast('✅ Table copied!', 'ok'));
});

document.getElementById('btnDlBulkBin').addEventListener('click', () => {
  if (!_bulkBinRows.length) { toast('No data', 'err'); return; }
  const txt = 'BIN | Brand | Bank | Country | Type | Level\n' +
    _bulkBinRows.map(r => `${r.bin} | ${r.brand} | ${r.bank} | ${r.country} | ${r.type} | ${r.level}`).join('\n');
  dlText(txt, 'zs_bulk_bin.txt');
  toast('💾 Downloaded!', 'ok');
});

// ── GATE HEALTH ─────────────────────────────────────────────────────────
async function fetchGateHealth() {
  try {
    const hdrs = await getAuthHeaders();
    const r = await fetch(`${API_BASE}/api/public/gate-health`, { method:'GET', headers:hdrs });
    const d = await r.json();
    if (d.ok) { _gateData = d.gates || []; renderGateTable(); }
    else { toast('Gate health error: ' + (d.error||'?'), 'err'); }
  } catch(e) { toast('Failed to load gate health', 'err'); }
}

function timeAgo(ts) {
  if (!ts) return 'Never';
  const diff = Math.floor((Date.now()/1000) - ts);
  if (diff < 60) return diff + 's ago';
  if (diff < 3600) return Math.floor(diff/60) + 'm ago';
  if (diff < 86400) return Math.floor(diff/3600) + 'h ago';
  return Math.floor(diff/86400) + 'd ago';
}

function gateHotness(ts) {
  if (!ts) return 'cold';
  const diff = (Date.now()/1000) - ts;
  if (diff < 3600) return 'hot';
  if (diff < 86400) return 'warm';
  return 'cold';
}

function gwTagClass(gw) {
  const g = (gw||'').toLowerCase();
  if (g.includes('stripe')) return 'stripe';
  if (g.includes('paypal')) return 'paypal';
  if (g.includes('braintree')) return 'braintree';
  return 'other';
}

function renderGateTable() {
  const wrap = document.getElementById('gateTableWrap');
  if (!_gateData.length) {
    wrap.innerHTML = '<div class="empty-state"><div class="ico">🏥</div><p>No gate data yet.<br>Successful hits will appear here in real-time.</p></div>';
    return;
  }
  const rows = _gateData.map(g => {
    const hot = gateHotness(g.last_hit);
    const tc = gwTagClass(g.gateway);
    return `<tr>
      <td><span class="hit-dot ${hot}"></span>${g.domain}</td>
      <td><span class="gw-tag ${tc}">${g.gateway||'Unknown'}</span></td>
      <td style="font-weight:700;color:var(--accent)">${g.count}</td>
      <td>${g.amount_display || g.amount_formatted || (g.amount ? (g.currency_symbol||'')+g.amount+(g.currency?' '+g.currency:'') : '-')}</td>
      <td style="color:var(--muted);font-size:11px">${timeAgo(g.last_hit)}</td>
    </tr>`;
  }).join('');
  wrap.innerHTML = `<table class="gate-table">
    <thead><tr><th>Domain</th><th>Gateway</th><th>Hits</th><th>Amount</th><th>Last Hit</th></tr></thead>
    <tbody>${rows}</tbody>
  </table>`;
}

document.getElementById('btnRefreshGate').addEventListener('click', async () => {
  if (!user || user.plan !== 'pro') { toast('⭐ PRO feature', 'err'); return; }
  toast('⏳ Loading...', '');
  await fetchGateHealth();
  toast('✅ Gate health updated', 'ok');
});

// ── GATE TESTER ──────────────────────────────────────────────────────────
document.getElementById('btnTestGate').addEventListener('click', async () => {
  if (!user) { toast('⛔ Login first', 'err'); return; }
  if (user.plan !== 'pro') { toast('⭐ PRO feature — Upgrade now!', 'err'); switchNav('account'); showView('viewPay'); return; }
  let input = document.getElementById('gateTestUrl').value.trim();
  if (!input) { toast('Enter a URL or domain', 'err'); return; }
  try { input = new URL(input.includes('://') ? input : 'https://'+input).hostname; } catch(e) {}
  input = input.replace(/^www\./,'').replace(/^pay\./,'').replace(/^checkout\./,'').replace(/^buy\./,'');
  toast('⏳ Checking...', '');
  if (!_gateData.length) {
    try {
      const hdrs = await getAuthHeaders();
      const r = await fetch(`${API_BASE}/api/public/gate-health`, {method:'GET',headers:hdrs});
      const d = await r.json();
      if (d.ok) _gateData = d.gates || [];
    } catch(e) {}
  }
  const match = _gateData.find(g => g.domain.includes(input) || input.includes(g.domain));
  const resultEl = document.getElementById('testResult');
  document.getElementById('trDomain').textContent = input;
  if (match) {
    const hot = gateHotness(match.last_hit);
    const statusText = hot==='hot' ? '🟢 HOT — Hit just happened!' : hot==='warm' ? '🟡 WARM — Hit within 24 hours' : '🔴 COLD — No hit in over 24 hours';
    document.getElementById('trGateway').textContent = match.gateway || 'Unknown';
    document.getElementById('trHits').textContent = match.count + ' hits';
    document.getElementById('trLastHit').textContent = timeAgo(match.last_hit);
    document.getElementById('trAmount').textContent = match.amount_display ? match.amount_display + (match.currency?' '+match.currency:'') : (match.amount_formatted ? match.amount_formatted+(match.currency?' '+match.currency:'') : (match.amount ? (match.currency_symbol||'')+match.amount+' '+(match.currency||'USD') : '-'));
    document.getElementById('trStatus').textContent = statusText;
  } else {
    document.getElementById('trGateway').textContent = 'No data';
    document.getElementById('trHits').textContent = '0 hits';
    document.getElementById('trLastHit').textContent = 'Never';
    document.getElementById('trAmount').textContent = '-';
    document.getElementById('trStatus').textContent = '⚪ NO DATA — Try autofilling on this site first';
  }
  resultEl.classList.add('show');
  toast(match ? '✅ Data found' : 'ℹ️ No data for this domain', match ? 'ok' : '');
});

// ── CARD FILTER ──────────────────────────────────────────────────────────
function parseExpiry(exp) {
  exp = exp.trim();
  let mm, yy;
  if (exp.includes('/')) { [mm, yy] = exp.split('/'); }
  else if (exp.length === 4) { mm = exp.slice(0,2); yy = exp.slice(2,4); }
  else if (exp.length === 6) { mm = exp.slice(0,2); yy = exp.slice(4,6); }
  else { return null; }
  mm = parseInt(mm); yy = parseInt(yy);
  if (yy < 100) yy += 2000;
  if (mm < 1 || mm > 12) return null;
  return new Date(yy, mm - 1, 1);
}

function validateCardLine(line) {
  const parts = line.split('|');
  if (parts.length < 2) return { valid:false };
  const num = parts[0].replace(/\D/g,'');
  if (num.length < 13 || num.length > 19) return { valid:false };
  if (!luhnCheck(num)) return { valid:false };
  const expDate = parseExpiry(parts[1]);
  if (!expDate) return { valid:false };
  const now = new Date(); now.setDate(1); now.setHours(0,0,0,0);
  if (expDate < now) return { valid:false };
  return { valid:true };
}

document.getElementById('btnFilter').addEventListener('click', () => {
  if (!user) { toast('⛔ Login first', 'err'); return; }
  if (user.plan !== 'pro') { toast('⭐ PRO feature — Upgrade now!', 'err'); switchNav('account'); showView('viewPay'); return; }
  const lines = document.getElementById('filterInput').value.trim().split('\n').filter(l => l.trim());
  if (!lines.length) { toast('Paste cards first', 'err'); return; }
  const valid = [], invalid = [];
  lines.forEach(line => {
    const r = validateCardLine(line.trim());
    if (r.valid) valid.push(line.trim());
    else invalid.push(line.trim());
  });
  document.getElementById('fTotal').textContent = lines.length;
  document.getElementById('fValid').textContent = valid.length;
  document.getElementById('fInvalid').textContent = invalid.length;
  document.getElementById('filterOutput').value = valid.join('\n');
  document.getElementById('filterResultArea').style.display = 'block';
  toast(`✅ ${valid.length} valid of ${lines.length} cards`, 'ok');
});

document.getElementById('btnClearFilter').addEventListener('click', () => {
  document.getElementById('filterInput').value = '';
  document.getElementById('filterResultArea').style.display = 'none';
});
document.getElementById('btnCopyFilter').addEventListener('click', () => {
  const txt = document.getElementById('filterOutput').value;
  if (!txt) { toast('No valid cards', 'err'); return; }
  navigator.clipboard.writeText(txt).then(() => toast('✅ Copied!', 'ok'));
});
document.getElementById('btnDlFilter').addEventListener('click', () => {
  const txt = document.getElementById('filterOutput').value;
  if (!txt) { toast('No valid cards', 'err'); return; }
  dlText(txt, 'zs_valid_cards.txt');
  toast('💾 Downloaded!', 'ok');
});

// ── TEMP MAIL (Mail.tm) ──────────────────────────────────────────────────
const TM_API = 'https://api.mail.tm';
let _tmState = null; // {address, password, token, accountId, createdAt}
let _tmAutoTimer = null;
let _tmMessages = []; // cached list of {id, subject, from, date, intro}
let _tmCurrentMsgId = null;

function tmRandStr(n) {
  const c = 'abcdefghijklmnopqrstuvwxyz0123456789';
  return Array.from({length:n}, () => c[Math.floor(Math.random()*c.length)]).join('');
}

async function tmFetchDomains() {
  const r = await fetch(`${TM_API}/domains?page=1`);
  const j = await r.json();
  const list = j['hydra:member'] || j.member || [];
  return list.filter(d => d.isActive !== false).map(d => d.domain);
}

async function tmCreateAccount() {
  const domains = await tmFetchDomains();
  if (!domains.length) throw new Error('No active Mail.tm domains');
  const domain = domains[0];
  const localpart = 'zs' + tmRandStr(10);
  const address = `${localpart}@${domain}`;
  const password = tmRandStr(16) + 'A1!';

  const c = await fetch(`${TM_API}/accounts`, {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({address, password}),
  });
  if (!c.ok) {
    const txt = await c.text();
    throw new Error('Account create failed: ' + txt.slice(0,80));
  }
  const acc = await c.json();

  const t = await fetch(`${TM_API}/token`, {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({address, password}),
  });
  if (!t.ok) throw new Error('Token request failed');
  const tj = await t.json();

  return {address, password, token: tj.token, accountId: acc.id, createdAt: Date.now()};
}

async function tmListMessages() {
  if (!_tmState) return [];
  const r = await fetch(`${TM_API}/messages?page=1`, {
    headers: {'Authorization': 'Bearer ' + _tmState.token},
  });
  if (!r.ok) {
    if (r.status === 401) throw new Error('Token expired');
    throw new Error('Inbox fetch failed');
  }
  const j = await r.json();
  return (j['hydra:member'] || j.member || []).map(m => ({
    id: m.id,
    subject: m.subject || '(no subject)',
    from: m.from?.address || (m.from?.name) || '?',
    fromName: m.from?.name || '',
    date: m.createdAt || m.intro || '',
    intro: m.intro || '',
    seen: m.seen || false,
  }));
}

async function tmReadMessage(id) {
  const r = await fetch(`${TM_API}/messages/${id}`, {
    headers: {'Authorization': 'Bearer ' + _tmState.token},
  });
  if (!r.ok) throw new Error('Message read failed');
  return r.json();
}

function tmExtractCode(text) {
  if (!text) return null;
  let scrub = String(text);
  scrub = scrub.replace(/\b(?:19|20)\d{2}\b/g, ' ');
  scrub = scrub.replace(/\b(?:0?[1-9]|1[0-2])[\/\-:](?:0?[1-9]|[12]\d|3[01])(?:[\/\-:]\d{2,4})?\b/g, ' ');
  scrub = scrub.replace(/\b\d{1,2}:\d{2}(?::\d{2})?\s*(?:am|pm|utc|gmt)?\b/gi, ' ');
  scrub = scrub.replace(/\b(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec|january|february|march|april|june|july|august|september|october|november|december)\s+\d{1,2}(?:[, ]+\d{2,4})?\b/gi, ' ');
  scrub = scrub.replace(/\b(?:at|on|since|by|until|expires?(?:\s+at|\s+on)?)\s+\d{4,}/gi, ' ');
  const isYear = (n) => { const v = parseInt(n, 10); return v >= 1900 && v <= 2099; };
  const patterns = [
    /(?:code|otp|pin|verification|verify|c[oó]digo|confirm|access)[\s\S]{0,30}?[:\s]\s*(\d{4,8})\b/i,
    /\b(\d{6})\b/,
    /\b(\d{8})\b/,
    /\b(\d{5})\b/,
    /\b(\d{7})\b/,
    /\b(\d{4})\b/,
  ];
  for (const re of patterns) {
    const m = scrub.match(re);
    if (m && m[1] && !(m[1].length === 4 && isYear(m[1]))) return m[1];
  }
  return null;
}

function tmExtractMagicLink(html, text) {
  const KW = /(sign[\s\-]?in|log[\s\-]?in|verify|confirm|activate|reset[\s\-]?password|magic|click[\s\-]?(?:here|to)|continue|access[\s\-]?your|finish[\s\-]?(?:up|signing)|complete[\s\-]?(?:your)?[\s\-]?(?:registration|sign|signup))/i;
  const SKIP = /(unsubscribe|privacy|terms|help|support|preferences|update[\s\-]?email|contact[\s\-]?us|view[\s\-]?(?:in|online)|@)/i;
  const candidates = [];
  if (html) {
    const tmp = document.createElement('div');
    tmp.innerHTML = String(html);
    tmp.querySelectorAll('a[href]').forEach(a => {
      const href = a.getAttribute('href') || '';
      const lbl = (a.textContent || '').trim();
      if (!/^https?:\/\//i.test(href)) return;
      if (SKIP.test(href) || SKIP.test(lbl)) return;
      let score = 0;
      if (KW.test(lbl)) score += 3;
      if (KW.test(href)) score += 2;
      if (/token|magic|verify|confirm|activate|signin|login|auth/i.test(href)) score += 2;
      if (lbl.length > 3 && lbl.length < 80) score += 1;
      candidates.push({href, lbl: lbl || href, score});
    });
  }
  if (text) {
    const urlRe = /https?:\/\/[^\s<>"'()]+/g;
    let m;
    while ((m = urlRe.exec(text)) !== null) {
      const href = m[0].replace(/[.,;:)>\]]+$/, '');
      if (SKIP.test(href)) continue;
      let score = 0;
      if (/token|magic|verify|confirm|activate|signin|login|auth/i.test(href)) score += 2;
      if (!candidates.some(c => c.href === href)) candidates.push({href, lbl: href, score});
    }
  }
  if (!candidates.length) return null;
  candidates.sort((a, b) => b.score - a.score);
  if (candidates[0].score < 2) {
    if (text && KW.test(text)) return candidates[0];
    return null;
  }
  return candidates[0];
}

function tmStripHtml(html) {
  if (!html) return '';
  const div = document.createElement('div');
  div.innerHTML = html;
  return (div.textContent || div.innerText || '').replace(/\s+/g, ' ').trim();
}

function tmRenderInbox() {
  const list = document.getElementById('tmInboxList');
  const cnt = document.getElementById('tmInboxCount');
  cnt.textContent = `(${_tmMessages.length})`;
  if (!_tmMessages.length) {
    list.innerHTML = '';
    const empty = document.createElement('div');
    empty.style.cssText = 'padding:30px 14px;text-align:center;color:#475569;font-size:12px;background:#0b1220;border-radius:8px';
    empty.textContent = '📭 No messages yet — check back in a few seconds';
    list.appendChild(empty);
    return;
  }
  list.innerHTML = '';
  _tmMessages.forEach(m => {
    const row = document.createElement('div');
    row.style.cssText = 'padding:10px 12px;background:#0b1220;border:1px solid #1e293b;border-radius:8px;cursor:pointer;transition:border-color .15s';
    row.onmouseenter = () => row.style.borderColor = '#38bdf8';
    row.onmouseleave = () => row.style.borderColor = '#1e293b';

    const top = document.createElement('div');
    top.style.cssText = 'display:flex;justify-content:space-between;gap:8px;align-items:center';
    const subj = document.createElement('div');
    subj.style.cssText = 'font-weight:600;font-size:12px;color:#f1f5f9;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap';
    subj.textContent = m.subject;
    const code = tmExtractCode(m.subject + ' ' + m.intro);
    const badge = document.createElement('span');
    if (code) {
      badge.textContent = '🔑 ' + code;
      badge.style.cssText = 'font-family:var(--mono);font-size:11px;color:#86efac;background:rgba(34,197,94,0.15);padding:2px 8px;border-radius:6px;flex-shrink:0';
    }
    top.appendChild(subj);
    if (code) top.appendChild(badge);

    const from = document.createElement('div');
    from.style.cssText = 'font-size:10px;color:#64748b;margin-top:4px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap';
    from.textContent = `From: ${m.fromName ? m.fromName + ' · ' : ''}${m.from}`;

    const intro = document.createElement('div');
    intro.style.cssText = 'font-size:11px;color:#94a3b8;margin-top:6px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap';
    intro.textContent = m.intro;

    row.append(top, from, intro);
    row.addEventListener('click', () => tmShowMessage(m.id));
    list.appendChild(row);
  });
}

async function tmShowMessage(id) {
  _tmCurrentMsgId = id;
  document.getElementById('tmInboxArea').style.display = 'none';
  document.getElementById('tmMsgArea').style.display = 'block';
  document.getElementById('tmMsgSubject').textContent = '⏳ Loading...';
  document.getElementById('tmMsgFrom').textContent = '';
  document.getElementById('tmMsgBody').textContent = '';
  document.getElementById('tmMsgCodeBox').style.display = 'none';
  const linkBox = document.getElementById('tmMsgLinkBox');
  if (linkBox) linkBox.style.display = 'none';
  try {
    const msg = await tmReadMessage(id);
    document.getElementById('tmMsgSubject').textContent = msg.subject || '(no subject)';
    document.getElementById('tmMsgFrom').textContent = `From: ${msg.from?.name ? msg.from.name + ' · ' : ''}${msg.from?.address || '?'}`;
    const htmlRaw = Array.isArray(msg.html) ? msg.html.join(' ') : (msg.html || '');
    const bodyText = (msg.text && msg.text.trim()) || tmStripHtml(htmlRaw);
    document.getElementById('tmMsgBody').textContent = bodyText || '(empty body)';
    const code = tmExtractCode((msg.subject || '') + ' ' + bodyText);
    if (code) {
      document.getElementById('tmMsgCode').textContent = code;
      document.getElementById('tmMsgCodeBox').style.display = 'block';
    } else {
      const link = tmExtractMagicLink(htmlRaw, bodyText);
      if (link && linkBox) {
        const urlEl = document.getElementById('tmMsgLinkUrl');
        const btn = document.getElementById('btnTmOpenLink');
        const lblEl = document.getElementById('tmMsgLinkLbl');
        urlEl.textContent = link.href;
        urlEl.title = link.href;
        if (lblEl) lblEl.textContent = link.lbl && link.lbl !== link.href ? link.lbl : 'Sign-in / verification link';
        btn.onclick = () => {
          try { chrome.tabs.create({url: link.href}); }
          catch(_) { window.open(link.href, '_blank'); }
        };
        const copyBtn = document.getElementById('btnTmCopyLink');
        if (copyBtn) copyBtn.onclick = () => {
          navigator.clipboard?.writeText(link.href);
          toast('Link copied', 'ok');
        };
        linkBox.style.display = 'block';
      }
    }
  } catch(e) {
    document.getElementById('tmMsgSubject').textContent = '❌ Failed to load message';
    document.getElementById('tmMsgBody').textContent = e.message || '';
  }
}

async function tmRefreshInbox(silent) {
  if (!_tmState) return;
  const statusEl = document.getElementById('tmStatus');
  if (statusEl) statusEl.textContent = '⏳ checking...';
  try {
    const msgs = await tmListMessages();
    const newOnes = msgs.length - _tmMessages.length;
    _tmMessages = msgs;
    tmRenderInbox();
    if (statusEl) statusEl.textContent = '✓ updated ' + new Date().toLocaleTimeString();
    if (newOnes > 0 && silent) toast(`📬 ${newOnes} new message${newOnes>1?'s':''}`, 'ok');
  } catch(e) {
    if (statusEl) statusEl.textContent = '❌ ' + (e.message || 'error');
    if (!silent) toast('Inbox error: ' + e.message, 'err');
  }
}

function tmStartAuto() {
  tmStopAuto();
  if (!_tmState) return;
  document.getElementById('tmAutoRow').style.display = 'flex';
  if (!document.getElementById('tmAutoChk').checked) return;
  _tmAutoTimer = setInterval(() => tmRefreshInbox(true), 10000);
}
function tmStopAuto() {
  if (_tmAutoTimer) { clearInterval(_tmAutoTimer); _tmAutoTimer = null; }
}

function tmRenderAddress() {
  const addrEl = document.getElementById('tmAddress');
  const copyBtn = document.getElementById('btnTmCopy');
  const refBtn = document.getElementById('btnTmRefresh');
  if (_tmState && _tmState.address) {
    addrEl.textContent = _tmState.address;
    addrEl.style.color = '#86efac';
    copyBtn.disabled = false;
    refBtn.disabled = false;
    document.getElementById('tmInboxArea').style.display = 'block';
    document.getElementById('tmAutoRow').style.display = 'flex';
  } else {
    addrEl.textContent = '— Click Generate to start —';
    addrEl.style.color = '#64748b';
    copyBtn.disabled = true;
    refBtn.disabled = true;
    document.getElementById('tmInboxArea').style.display = 'none';
    document.getElementById('tmAutoRow').style.display = 'none';
  }
}

document.getElementById('btnTmNew').addEventListener('click', async () => {
  const btn = document.getElementById('btnTmNew');
  const isPro = user && user.plan === 'pro';
  if (!isPro) {
    const u = await getTempMailUsage();
    if (u.count >= FREE_TEMPMAIL_DAILY) {
      toast(`⛔ FREE limit: ${FREE_TEMPMAIL_DAILY} email/day reached. Upgrade to PRO for unlimited.`, 'err');
      return;
    }
  }
  btn.disabled = true; btn.textContent = '⏳ Generating...';
  try {
    _tmState = await tmCreateAccount();
    await store.set({tempMail: _tmState});
    _tmMessages = [];
    if (!isPro) await bumpTempMailUsage();
    await refreshTempMailUsageUI();
    tmRenderAddress();
    tmRenderInbox();
    tmStartAuto();
    toast('✅ Temp email ready', 'ok');
  } catch(e) {
    toast('❌ ' + (e.message || 'Failed to create temp email'), 'err');
  }
  btn.disabled = false; btn.textContent = '⚡ Generate New';
});

document.getElementById('btnTmRefresh').addEventListener('click', () => tmRefreshInbox(false));

document.getElementById('btnTmCopy').addEventListener('click', () => {
  if (!_tmState) return;
  navigator.clipboard.writeText(_tmState.address).then(() => {
    toast('📋 Email copied!', 'ok');
  });
});

document.getElementById('btnTmBack').addEventListener('click', () => {
  document.getElementById('tmMsgArea').style.display = 'none';
  document.getElementById('tmInboxArea').style.display = 'block';
  _tmCurrentMsgId = null;
});

document.getElementById('btnTmCopyCode').addEventListener('click', () => {
  const code = document.getElementById('tmMsgCode').textContent;
  if (!code || code === '—') return;
  navigator.clipboard.writeText(code).then(() => toast('📋 Code copied: ' + code, 'ok'));
});

document.getElementById('tmAutoChk').addEventListener('change', () => {
  if (document.getElementById('tmAutoChk').checked) tmStartAuto();
  else tmStopAuto();
});

// ── HELPERS ───────────────────────────────────────────────────────────────
async function getAuthHeaders() {
  return new Promise(r => chrome.storage.local.get(['zs_token','zs_uid'], d => r({
    'Content-Type':'application/json',
    'X-ZS-Token': d.zs_token||'', 'X-ZS-UID': String(d.zs_uid||'')
  })));
}

function dlText(content, filename) {
  const blob = new Blob([content], {type:'text/plain'});
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  a.click();
  URL.revokeObjectURL(a.href);
}

// ── INIT ──────────────────────────────────────────────────────────────────
async function init() {
  const d = await store.get(['zs_user','proxies','activeProxy','fingerprint','tempMail']);
  user = d.zs_user || null;
  proxies = d.proxies || [];
  activeProxy = d.activeProxy || null;
  _0xba06bzoio = d.fingerprint || null;
  _tmState = d.tempMail || null;

  if (user) {
    try {
      const r = await fetch(`${API_BASE}/api/public/get-user`, {
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({user_id: user.user_id})
      });
      const res = await r.json();
      if (res.ok) { user = {...user,...res}; await store.set({zs_user:user}); }
    } catch(e) {}
    if (user.plan === 'pro') { fetchGateHealth().catch(()=>{}); }
  }

  populateCountries();
  renderAccount();
  renderProxies();
  updateProxyStatus();
  updateFPUI();
  refreshSpoofUsageUI();

  // Restore temp mail state if exists
  tmRenderAddress();
  refreshTempMailUsageUI();
  if (_tmState && _tmState.token) {
    tmRefreshInbox(true).catch(() => {});
    tmStartAuto();
  }
}

init();
